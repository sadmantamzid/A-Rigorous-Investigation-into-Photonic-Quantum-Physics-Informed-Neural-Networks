# QPINN Architecture Documentation

## Quantum Physics-Informed Neural Network (QPINN) Components

Technical specifications for QPINN.

### 1. Photonic Quantum Circuit Block

#### Circuit Construction (MerLin/Perceval)

```
Input Features (dim n_features_in)
↓
Fourier Transform Layer (dim n_fourier_features)
↓
┌─────────────────────────────────────┐
│  Phase Encoding (Feature → Phase)   │  Modes: 0 to n_modes-1
│  Input to n_fourier_features modes  │
└─────────────────────────────────────┘
↓
┌─────────────────────────────────────┐
│  Entangling Layer                   │  Mach-Zehnder interferometers
│  All-to-all or nearest-neighbor     │  Trainable phases
│  Connectivity: tunable              │
└─────────────────────────────────────┘
↓
┌─────────────────────────────────────┐
│  Parametrized Unitaries (depth q_d) │  For d = 1 to q_depth:
│  Each layer: single-qubit rotations  │    BS (50/50)
│              + controlled phases     │    Trainable phase shifters
└─────────────────────────────────────┘
↓
┌─────────────────────────────────────┐
│  Measurement Projection              │  Partial measurement on first n_modes
│  Output modes: mapped to             │  modes (photon number basis)
│  probability vector (dim 2^n_modes)  │
└─────────────────────────────────────┘
↓
Readout Linear Layer: (2^n_modes) → output_dim
↓
Output Predictions: ŷ = W * p + b
```

#### Parameters

| Parameter | Type | Range | Description |
|-----------|------|-------|-------------|
| `n_modes` | int | 3–16 | Total number of optical modes |
| `n_photons` | int | 1–(n_modes-1) | Number of photons in circuit |
| `q_depth` | int | 1–5 | Number of parametrized unitary layers |
| `n_fourier_features` | int | 2–n_modes | Fourier basis dimension |
| `subset_combinations` | bool | True/False | Enumerate all photon distributions |
| `input_encoding` | str | "identity" or "arccos" | Feature → phase mapping |

#### Trainable Parameters

Total parameters per block:
- **Phase shifters (input encoding)**: n_fourier_features
- **Entangling layer**: ~n_modes²/2 (all-to-all) or n_modes (nearest-neighbor)
- **Parametrized unitaries**: n_modes × (3 × q_depth) [RX-RZ-RX per layer]
- **Readout linear layer**: (2^n_modes + 1) × 1

**Typical count**: ~100–1000 parameters depending on configuration

### 2. Classical Baseline Architecture

For fair comparison, classical architecture mirrors QPINN structure:

```
Input Features (dim n_features_in)
↓
Fourier Transform Layer (dim n_fourier_features)
↓
┌─────────────────────────────────────┐
│  Dense Layer (parametrized block)   │  Hidden units chosen to match
│  ReLU activation                    │  photonic parameter count
│  (equiv. ~photonic param count)     │
└─────────────────────────────────────┘
↓
┌─────────────────────────────────────┐
│  Output Linear Layer                │
└─────────────────────────────────────┘
↓
Predictions: ŷ = W_out * h + b_out
```

**Design**: Parameter-matched comparison
- Same number of trainable parameters as photonic block
- Fourier feature preprocessing (identical to photonic case)
- Skip connections and residual structure
- Combined Adam + L-BFGS optimization

### 3. PDE Problem Setup

#### Heat Equation
- **Domain**: x ∈ [0, 1], t ∈ [0, 1]
- **PDE**: ∂u/∂t = ∂²u/∂x²
- **Boundary conditions**: u(0,t) = 0, u(1,t) = 0
- **Initial condition**: u(x,0) = sin(πx)
- **Collocation points**: n_f random samples in (x, t) × (0, 1)²
- **Loss**: L = λ_pde × MSE_collocation + λ_bc × MSE_boundary

#### Schrodinger Equation
- **Domain**: x ∈ [-5, 5], t ∈ [0, π]
- **PDE**: i ∂ψ/∂t = -∂²ψ/∂x² (free particle, V=0)
- **Initial condition**: Gaussian wavepacket centered at x=0
- **Target**: |ψ(x,t)|² (probability density)
- **Collocation strategy**: Phase-based encoding for quantum wavefunction
- **Challenge**: Complex-valued field, requires special handling

#### Burgers' Equation
- **Domain**: x ∈ [-1, 1], t ∈ [0, 1]
- **PDE**: ∂u/∂t + u∂u/∂x = ν∂²u/∂x², where ν = 0.01/π
- **Initial condition**: -sin(πx)
- **Boundary conditions**: Periodic (or Dirichlet with matching values)
- **Challenge**: Shock formation, high gradient regions
- **Collocation points**: Adaptive sampling with shock refinement

### 4. Training Strategy

#### Stage 1: Adam Pretraining
- **Optimizer**: Adam (β₁ = 0.9, β₂ = 0.999, ε = 1e-8)
- **Learning rate**: 1e-3 (adaptive with exponential decay)
- **Epochs**: 10,000 (early stopping patience: 1000)
- **Batch size**: 32 collocation points per batch
- **Loss**: Weighted sum of PDE residual and boundary loss

#### Stage 2: L-BFGS Fine-tuning
- **Optimizer**: L-BFGS (line search, Hessian approximation)
- **Steps**: 100 (full batch)
- **Learning rate**: 1.0 (auto-tuned via line search)
- **Convergence**: Tolerance = 1e-7
- **Purpose**: High-precision local refinement

#### Loss Function Components

```
L_total = λ_pde * L_pde + λ_bc * L_bc + λ_reg * L_reg

where:
L_pde = MSE of PDE residuals at collocation points
L_bc = MSE of boundary condition enforcement
L_reg = L2 regularization on parameters (optional)
  
λ_pde = 1.0 (primary objective)
λ_bc = 10.0 (strict boundary satisfaction)
λ_reg = 1e-6 (light regularization)
```

### 5. Measurement & Readout (Photonic)

#### Partial Measurement Strategy

1. **Measurement basis**: Fock basis (photon number per mode)
2. **Partial measurement**: Measure first n_modes modes (data register D)
3. **Post-selection**: Condition on total photon count = n_photons
4. **Outcome space**: All valid (m_0, m_1, ..., m_n) with Σm_i = n_photons
- Outcome dimension: C(n_modes + n_photons - 1, n_photons)
- Example: (5 modes, 2 photons) → 15 outcomes

#### Probability Extraction

For each measurement outcome j:
```
p_j = |<outcome_j | ψ_out >|²

Output = Linear(p_1, p_2, ..., p_m)  [m = outcome dimension]
```

#### Hidden State Propagation

Unmeasured modes (hidden register H) conditioned on measurement outcome:
```
ρ_H^(j) = Tr_D[ |outcome_j><outcome_j| ⊗ I_H · ρ_full ]

Next time step: use reduced density matrix ρ_H as input
```

### 6. Gradient Computation

#### Autodiff Through Quantum Circuit

MerLin/Perceval provides automatic differentiation:
- **Parameter shift rule** for quantum gates (optional fallback)
- **Direct backpropagation** through statevector simulation
- **Memory**: O(2^n_modes) state vector storage

#### Gradient Stability

- Use `float64` for numerics (quantum simulation is ill-conditioned)
- Gradient clipping: max norm = 1.0
- L-BFGS stabilization in fine-tuning phase

### 7. Configuration Templates

#### Small (Fast Testing)
```python
{
"n_modes": 3,
"n_photons": 1,
"q_depth": 1,
"n_fourier_features": 2,
"batch_size": 32,
"epochs_pretrain": 1000,  # Fast
"lbfgs_steps": 10,
}
```

#### Medium (Benchmark)
```python
{
"n_modes": 5,
"n_photons": 2,
"q_depth": 1,
"n_fourier_features": 4,
"batch_size": 32,
"epochs_pretrain": 10000,
"lbfgs_steps": 100,
}
```

#### Large (Research)
```python
{
"n_modes": 10,
"n_photons": 5,
"q_depth": 2,
"n_fourier_features": 6,
"batch_size": 16,  # Smaller batch due to simulator overhead
"epochs_pretrain": 20000,
"lbfgs_steps": 200,
}
```

### 8. Implementation Details

#### Automatic Differentiation

PyTorch integration:
```python
# Circuit encapsulated as custom torch.nn.Module
class PhotonicQPINNBlock(torch.nn.Module):
def forward(self, x):
# Build Perceval circuit
# Execute statevector simulation
# Extract measurement probabilities
# Return readout layer output (differentiable)
```

#### Batching Strategy

- **Collocation points**: Batched (standard PyTorch)
- **Photonic circuit**: Sequential per sample (branching overhead)
- **Gradient aggregation**: Accumulated over batch

#### Hardware Considerations

- **CPU**: Statevector simulation feasible up to ~12 modes
- **GPU**: Limited by memory; Perceval GPU support (cuQuantum backend) experimental
- **Typical runtime**: 1–10 minutes per seed (heat eq, 10k Adam epochs)

---

**Last updated**: May 2024

