# QPINN Repository Manifest & Navigation Guide

## Overview

**Quantum Physics-Informed Neural Networks (QPINN)** — A comprehensive benchmark comparing photonic quantum and classical neural network approaches to solving PDEs using physics-informed learning.

**Finding**: Classical networks remain competitive; photonic advantage at 12+ modes (unvalidated).

---

## Documentation (Start Here)

| Document | Purpose | Audience |
|----------|---------|----------|
| **[README.md](README.md)** | Project overview, results summary, installation | Everyone |
| **[QUICKSTART.md](QUICKSTART.md)** | First-run guide, common tasks, troubleshooting | New users |
| **[ARCHITECTURE.md](ARCHITECTURE.md)** | Technical details, circuit diagrams, parameters | Developers |
| **[RESULTS.md](RESULTS.md)** | Comprehensive results breakdown, analysis | Researchers |
| **[requirements.txt](requirements.txt)** | Python dependencies | DevOps |

### Reading Suggestions

**First time here?**
1. Read [README.md](README.md) (5 min)
2. Follow [QUICKSTART.md](QUICKSTART.md) setup (10 min)
3. Run example notebook (15 min)

**Reproducing results?**
1. Review [RESULTS.md](RESULTS.md) for expected outputs
2. Follow [README.md](README.md) "Running Experiments" section
3. Check [ARCHITECTURE.md](ARCHITECTURE.md) for parameter meanings

**Modifying code?**
1. Study [ARCHITECTURE.md](ARCHITECTURE.md) for circuit design
2. Review specific experiment script (e.g., `exp1_photon_scaling.py`)
3. Check notebook `merlin_dv_qpinn.ipynb` for training loop

---

## Experiments

### Core Experiments (Ordered by Recommended Execution)

| # | Experiment | Duration | Purpose | Output Files |
|---|-----------|----------|---------|--------------|
| 1 | [exp1_photon_scaling.py](exp1_photon_scaling.py) | ~10 min | Mode/photon scaling benchmark | `exp1_photon_scaling.json/.png` |
| 2 | [exp2_schrodinger.py](exp2_schrodinger.py) | ~5 min | Quantum PDE (free-particle wavepacket) | `exp2_schrodinger.json/.png` |
| 3 | [exp3_burgers.py](exp3_burgers.py) | ~5 min | Nonlinear shock equation | `exp3_burgers.json/.png` |
| 4 | [exp4_sample_efficiency.py](exp4_sample_efficiency.py) | ~3 min | Data complexity dependence | `exp4_sample_efficiency.json/.png` |

### Ablation & Benchmark Experiments

| Experiment | Purpose | Duration | Output |
|-----------|---------|----------|--------|
| [ablation_photonic_vs_classical.py](ablation_photonic_vs_classical.py) | Frozen vs trained, architecture variants | ~5 min | `ablation_photonic_results.json/.png` |
| [benchmark_qpinn_vs_pinn.py](benchmark_qpinn_vs_pinn.py) | Full PINN baseline comparison | ~10 min | `benchmark_results.json/.png` |

### Notebooks (Interactive)

| Notebook | Purpose | Best For |
|----------|---------|----------|
| [merlin_dv_qpinn.ipynb](merlin_dv_qpinn.ipynb) | Main QPINN development | Learning, debugging |
| [mlp_pinn_heat_equation.ipynb](mlp_pinn_heat_equation.ipynb) | Classical baseline | Comparison, understanding |
| [merlin_dv_qpinn_ablations.ipynb](merlin_dv_qpinn_ablations.ipynb) | Ablation study details | Analysis |
| [merlin_dv_qpinn_paper_baseline.ipynb](merlin_dv_qpinn_paper_baseline.ipynb) | Original paper reproduction | Validation |

---

## Results Files

### Experiment Results (JSON + PNG)

```
Results organized by experiment:

exp1_photon_scaling.json        → RMSE data for 3 circuit sizes
exp1_photon_scaling.png         → Bar plots + solution visualizations
│
exp2_schrodinger.json           → Schrodinger equation results
exp2_schrodinger.png            → Wavefunction comparison plots
│
exp3_burgers.json               → Burgers' shock equation results
exp3_burgers.png                → Shock profiles + error analysis
│
exp4_sample_efficiency.json     → Sample count sweep results
exp4_sample_efficiency.png      → RMSE vs n_f curves
│
ablation_photonic_results.json  → Frozen/trained/variant comparison
ablation_photonic.png           → Ablation visualization
│
benchmark_results.json          → Full QPINN vs PINN benchmark
benchmark_summary.png           → Comprehensive comparison
```

### Aggregated Results

```
consolidated_summary.txt        → Text report of all experiments
consolidated_summary.png        → Multi-panel figure (all results)
photon_count_accuracy_sweep.csv → Tabular detailed results
```

### Logs

```
exp1_run.log, exp2_run.log, exp3_run.log, exp4_run.log
```

---

## Quick Reference Commands

### Installation & Setup

```bash
# Clone and setup
git clone <repo>
cd qpinn
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Verify
python -c "import torch; import perceval; print('OK')"
```

### Run Experiments

```bash
# Single experiment (fast)
python exp1_photon_scaling.py

# All experiments sequentially
for exp in exp{1..4}_*.py ablation_photonic_vs_classical.py; do
python $exp
done

# Aggregate results
python consolidated_summary.py

# Interactive notebook
jupyter notebook merlin_dv_qpinn.ipynb
```

### Analyze Results

```bash
# View JSON results
python -c "import json; print(json.dumps(json.load(open('exp1_photon_scaling.json')), indent=2)[:500])"

# Display images
python -c "from PIL import Image; Image.open('exp1_photon_scaling.png').show()"

# Parse CSV
python -c "import pandas as pd; print(pd.read_csv('photon_count_accuracy_sweep.csv').head())"
```

### Custom Run

```bash
# Modify EPOCHS in exp1_photon_scaling.py from 10000 → 1000 for quick test
# Then run:
python exp1_photon_scaling.py
```

---

## File Structure

```
qpinn/
│
├─ Documentation/
│  ├─ README.md                        ← Project overview [START HERE]
│  ├─ QUICKSTART.md                    ← First-time setup guide
│  ├─ ARCHITECTURE.md                  ← Technical deep-dive
│  ├─ RESULTS.md                       ← Experimental results analysis
│  └─ MANIFEST.md                      ← This file
│
├─ Experiments/
│  ├─ exp1_photon_scaling.py           ← Mode/photon scaling benchmark
│  ├─ exp2_schrodinger.py              ← Quantum PDE
│  ├─ exp3_burgers.py                  ← Nonlinear shock
│  ├─ exp4_sample_efficiency.py        ← Sample complexity
│  ├─ benchmark_qpinn_vs_pinn.py       ← Full PINN benchmark
│  └─ ablation_photonic_vs_classical.py ← Ablation suite
│
├─ Notebooks/
│  ├─ merlin_dv_qpinn.ipynb            ← Main QPINN notebook
│  ├─ mlp_pinn_heat_equation.ipynb     ← Classical baseline
│  ├─ merlin_dv_qpinn_ablations.ipynb  ← Ablation details
│  └─ merlin_dv_qpinn_paper_baseline.ipynb ← Paper reproduction
│
├─ Utilities/
│  ├─ consolidated_summary.py          ← Aggregate all results
│  ├─ summarize_exp1.py                ← Exp1-specific analysis
│  └─ requirements.txt                 ← Dependencies
│
├─ Results/
│  ├─ exp1_photon_scaling.{json,png}
│  ├─ exp2_schrodinger.{json,png}
│  ├─ exp3_burgers.{json,png}
│  ├─ exp4_sample_efficiency.{json,png}
│  ├─ benchmark_results.{json,png}
│  ├─ ablation_photonic_results.{json,png}
│  ├─ consolidated_summary.{txt,png}
│  ├─ photon_count_accuracy_sweep.csv
│  └─ {exp1..4}_run.log, benchmark_run.log, ablation_run.log
│
└─ References/
├─ 2503.12244v2.pdf
├─ 2601.08068v1.pdf
└─ Quandela_ETH_Hackathon_Challenge.pdf
```

---

## Results Summary

### Headline Finding

| Experiment | Photonic RMSE | Classical RMSE | Winner | Margin |
|------------|--------------|----------------|--------|--------|
| Heat eq (5m, 2p) | 2.556e-04 | 2.537e-04 | Classical |  1% |
| Heat eq (8m, 3p) | 2.457e-04 | 2.743e-04 | **Photonic** |  11% |
| Heat eq (10m, 5p) | 4.553e-04 | 2.552e-04 | Photonic |  44% |
| Schrodinger eq | 4.772e-03 | 3.893e-03 | Classical |  18% |
| Burgers eq | 1.545e-01 | 1.139e-01 | Classical |  26% |
| Sample efficiency | 2.470e-04 | 2.472e-04 | Tie | ~ <1% |

**Interpretation**: 
- Classical networks win on standard PDEs
- Photonic advantage emerges at larger circuit scales (10+ modes)
- Simulator overhead prevents validation at very large scales

---

## ️ Configuration Parameters

### Quick Parameter Reference

```python
# Typical configurations
SMALL_CONFIG = {
"n_modes": 3,
"n_photons": 1,
"q_depth": 1,
"n_fourier_features": 2,
}

MEDIUM_CONFIG = {
"n_modes": 5,
"n_photons": 2,
"q_depth": 1,
"n_fourier_features": 4,
}

LARGE_CONFIG = {
"n_modes": 10,
"n_photons": 5,
"q_depth": 2,
"n_fourier_features": 6,
}
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for complete parameter guide.

---

## Development & Extension

### Modifying an Experiment

```python
# In exp1_photon_scaling.py, modify:

# 1. Change circuit parameters
CONFIGS = [
(3, 1, 1),  # (n_modes, n_photons, q_depth)
# Add new config here
]

# 2. Change PDE
# Find pde_residual() function and modify the equation

# 3. Change training parameters
EPOCHS = 5000  # Faster testing
LBFGS_STEPS = 50
```

### Creating New Experiment

```python
# Copy exp1_photon_scaling.py and modify:
# 1. Problem setup (PDE definition)
# 2. Configuration sweep (CONFIGS list)
# 3. Results aggregation (save/plot logic)

# Template structure:
import json
import torch

# Define problem
def pde_residual(model, x_c, t_c):
# Compute your PDE residual here
pass

# Run sweep
results = {}
for config in CONFIGS:
for seed in SEEDS:
# Train model
# Compute metrics
# Store results
pass

# Save and plot
with open('new_exp.json', 'w') as f:
json.dump(results, f)
```

---

## Support & Contributing

### Troubleshooting

| Issue | Solution |
|-------|----------|
| `ImportError: No module named 'perceval'` | `pip install --upgrade perceval` |
| Out-of-memory | Reduce `n_modes` or use smaller `batch_size` |
| Training diverges | Use `dtype="float64"`, increase LBFGS steps |
| Slow circuit eval | Reduce `q_depth` or `n_modes` |

### Asking Questions

1. Check [QUICKSTART.md](QUICKSTART.md) troubleshooting
2. Review [ARCHITECTURE.md](ARCHITECTURE.md) for technical details
3. Look at notebook cells for implementation examples
4. Check GitHub issues or create new issue

### Contributing

- Fix bugs: submit PR with test case
- Add experiment: create new script following experiment template
- Improve docs: submit updates to `.md` files
- Report results: open issue with comparison findings

---

## Reference Papers & Links

**Core Papers**:
- Physics-Informed Neural Networks (PINNs): [Raissi et al., 2019](https://arxiv.org/abs/1711.10566)
- Quantum Machine Learning: [Schuld & Killoran, 2019](https://arxiv.org/abs/1902.10673)

**Quantum Platforms**:
- Perceval: [perceval.quandela.net](https://perceval.quandela.net)
- MerLin: [GitHub/merlinquantum](https://github.com/merlinquantum)
- Quandela: [quandela.com](https://quandela.com)

**This Project**:
- Challenge: [Quandela ETH Hackathon](https://quandela.com/hackathon)
- Related papers: See `/References` folder

---

## Checklist for First Run

- [ ] Clone repository
- [ ] Create virtual environment (`python -m venv .venv`)
- [ ] Activate venv (`source .venv/bin/activate`)
- [ ] Install dependencies (`pip install -r requirements.txt`)
- [ ] Verify imports (`python -c "import torch; import perceval; print('OK')"`)
- [ ] Run notebook (`jupyter notebook merlin_dv_qpinn.ipynb`)
- [ ] Run quick experiment (`python exp1_photon_scaling.py`)
- [ ] Check outputs (`ls exp1_photon_scaling.*`)
- [ ] Read results (`python consolidated_summary.py`)

---

## Contact

**Maintainer**: QPINN Reproduction Project  
**Last Updated**: May 2024  
**License**: See LICENSE file

---

**Next Steps**:
-  **New user?** → Read [README.md](README.md) then [QUICKSTART.md](QUICKSTART.md)
-  **Want details?** → Check [ARCHITECTURE.md](ARCHITECTURE.md)
-  **Need results?** → See [RESULTS.md](RESULTS.md)
-  **Ready to run?** → Follow [README.md](README.md) "Running Experiments"

