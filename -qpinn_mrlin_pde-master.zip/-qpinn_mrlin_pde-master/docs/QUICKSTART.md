# Quick Start Guide

## Installation

### Step 1: Clone and Setup

```bash
git clone <your-repo-url>
cd qpinn

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Verify Installation

```bash
# Test imports
python -c "import torch; import perceval; import merlin; print('All imports OK!')"

# Quick sanity check (should run in ~1 minute)
python exp1_photon_scaling.py --help  # If script supports --help
```

---

## Quick Start Options

### Option 1: Notebook (Interactive)

```bash
jupyter notebook merlin_dv_qpinn.ipynb
```

Walks through circuit construction, training, visualization, debugging.

### Option 2: Single Experiment

```bash
# Small heat equation test (2 modes, 1 photon, ~30 sec)
python exp1_photon_scaling.py 2>/dev/null | head -20

# Or full medium-scale exp1 (~10 min)
python exp1_photon_scaling.py
```

### Option 3: Full Benchmark

```bash
# Sequential runs (total ~1–2 hours)
python exp1_photon_scaling.py
python exp2_schrodinger.py
python exp3_burgers.py
python exp4_sample_efficiency.py
python consolidated_summary.py
```

### Option 4: Reproduce Results

```bash
# Exact reproduction (seed 42, 3 seeds each)
python benchmark_qpinn_vs_pinn.py
```

---

## Expected Output

### After Running `exp1_photon_scaling.py`:

```
Exp1: Photon/Mode Scaling on Heat Equation
=========================================
Config 1: (5m, 2p, d1, fs4)
Seed 0: RMSE_photonic=2.556e-04, RMSE_classical=2.537e-04 (time: 12.3s)
Seed 1: RMSE_photonic=2.543e-04, RMSE_classical=2.521e-04 (time: 12.1s)
Seed 2: RMSE_photonic=2.551e-04, RMSE_classical=2.550e-04 (time: 12.5s)
Mean RMSE_photonic: 2.550e-04 ± 0.006e-04
Mean RMSE_classical: 2.536e-04 ± 0.015e-04
Ratio: 0.995x

Config 2: (8m, 3p, d2, fs4)
[... similar output ...]

Config 3: (10m, 5p, d2, fs6)
[... similar output ...]

Plots saved to: exp1_photon_scaling.png
Results saved to: exp1_photon_scaling.json
```

### Generated Files:

- **`exp1_photon_scaling.json`** — Structured results (metrics, parameters, times)
- **`exp1_photon_scaling.png`** — Bar plots + solution predictions
- **`exp1_run.log`** — Detailed execution log

---

## Common Tasks

### View Results from Previous Run

```python
import json

# Load results
with open('exp1_photon_scaling.json', 'r') as f:
results = json.load(f)

# Print summary
for config, data in results.items():
print(f"{config}: photonic={data['rmse_q']:.2e}, classical={data['rmse_c']:.2e}")
```

### Create Custom Configuration

```python
# Create a new experiment config
custom_config = {
"equation": "heat",
"n_modes": 6,
"n_photons": 2,
"q_depth": 1,
"n_fourier_features": 3,
"batch_size": 32,
"epochs_pretrain": 5000,
"lbfgs_steps": 50,
"dtype": "float64",
"device": "cpu",
}

# Save and run
import json
with open('my_config.json', 'w') as f:
json.dump(custom_config, f, indent=2)

# Then adapt an experiment script to use my_config.json
```

### Analyze Single Seed

```bash
# Add verbosity to experiment script to trace single run
# Edit exp script to set SEEDS = [42] and EPOCHS = 1000 for quick test
```

---

## Troubleshooting

### ImportError: No module named 'perceval'

```bash
# Reinstall Perceval
pip install --upgrade perceval
pip install --upgrade merlin
```

### OutOfMemory Error

**OutOfMemory**: Photonic simulation requires O(2^n_modes) memory
- Reduce `n_modes` (5 vs 10)
- CPU-only mode (default)
- Lower batch size

### Training Not Converging

Try:
- Increase `lbfgs_steps` (default 100 → 500)
- Use `dtype="float64"` (more stable than float32)
- Check boundary condition weight `λ_bc` is non-zero
- Reduce initial learning rate for Adam

### Slow Photonic Circuit Evaluation

Expected: Classical >100x faster than photonic at same scale

Workarounds:
- Reduce `q_depth` (1 or 2 layers usually sufficient)
- Smaller `n_modes` for prototyping
- Consider GPU-accelerated Perceval (experimental)

---

## Next: Deeper Exploration

Once basic runs work, try:

1. **Modify PDE** — Edit `exp1_photon_scaling.py` to solve Poisson equation, wave equation, etc.
2. **Custom circuit** — Design own photonic ansatz in `merlin_dv_qpinn.ipynb`
3. **Hyperparameter sweep** — Use `optuna` for Bayesian optimization
4. **Hybrid architecture** — Combine photonic + classical blocks
5. **Noise modeling** — Add realistic photonic errors and retrain

---

## File Structure Reference

```
qpinn/
├── README.md                          ← Overview (you are here)
├── ARCHITECTURE.md                    ← Technical details
├── RESULTS.md                         ← Comprehensive results summary
├── requirements.txt                   ← Dependencies
│
├── merlin_dv_qpinn.ipynb              ← Main notebook (START HERE)
├── mlp_pinn_heat_equation.ipynb       ← Classical baseline notebook
│
├── exp1_photon_scaling.py             ← Mode/photon scaling
├── exp2_schrodinger.py                ← Schrodinger equation
├── exp3_burgers.py                    ← Burgers' equation
├── exp4_sample_efficiency.py          ← Sample efficiency sweep
├── benchmark_qpinn_vs_pinn.py         ← Full PINN benchmark
├── ablation_photonic_vs_classical.py  ← Ablation study
│
├── consolidated_summary.py            ← Aggregate results script
├── summarize_exp1.py                  ← Exp1-specific analysis
│
└── [outputs]/ (generated)
├── exp1_photon_scaling.json/.png
├── exp2_schrodinger.json/.png
├── exp3_burgers.json/.png
├── exp4_sample_efficiency.json/.png
├── benchmark_results.json/.png
├── ablation_photonic_results.json/.png
└── consolidated_summary.*
```

---

## Performance Expectations

### Single Seed Training Time

| Experiment | Circuit Size | Approx. Time | Notes |
|------------|--------------|--------------|-------|
| Heat eq (5m, 2p) | Small | ~10s | Per seed; 3 seeds ~ 30s |
| Heat eq (8m, 3p) | Medium | ~30s | Measurement outcome enumeration starts to dominate |
| Heat eq (10m, 5p) | Large | ~120s | ~30 measurement outcomes; simulation overhead significant |
| Schrodinger | Medium | ~20s | Complex-valued field; more collocation points |
| Burgers | Medium | ~25s | Shock refinement adds collocation samples |
| Sample efficiency sweep | Variable | ~60s | 5 sweep points × 3 seeds each |

### Full Benchmark Suite

- **Sequential execution**: ~5–10 hours (4 experiments + ablations)
- **Outputs**: ~50 MB total (JSON + PNG plots)
- **Disk space required**: ~100 MB (including logs)

---

### Common Questions

**Q: Why is photonic slower?**
A: Perceval simulator must:
1. Build circuit symbolically
2. Compute statevector (2^n_modes amplitudes)
3. Compute measurement probabilities
4. Backpropagate through all operations

Classical MLP is just forward-pass through dense layers.

**Q: Can I run on GPU?**
A: Perceval GPU support is experimental. PyTorch autodiff runs on GPU, but Perceval simulation typically CPU-only.

**Q: How do I modify the problem?**
A: Edit PDE definition in experiment scripts (e.g., in `exp1_photon_scaling.py`, find `def pde_residual()` and modify the equation).

---

## References & Further Reading

- **PINN paper**: [Raissi et al., 2019](https://www.sciencedirect.com/science/article/pii/S0021999118307125)
- **Perceval docs**: [perceval.quandela.net](https://perceval.quandela.net/)
- **MerLin framework**: [GitHub/merlinquantum](https://github.com/merlinquantum)
- **Quantum ML**: [Schuld & Killoran, 2019](https://arxiv.org/abs/1902.10673)

---

**Last updated**: May 2024
