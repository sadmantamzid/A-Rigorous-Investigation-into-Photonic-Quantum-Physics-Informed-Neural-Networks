# Are Quantum PINNs Actually Doing Anything?

**Quandela Challenge, ETH Quantum Hackathon 2026** <br>
**Team Quaternion:** Vanshaj Bindal, Iyan Zhang, MD Sadman Tamzid Hossain, Giacomo Lorelli <br>
**Framework:** MerLin 0.3.2 (Quandela), SLOS simulator (CPU)

---

## 1. The Problem

Physics-Informed Neural Networks (PINNs) solve partial differential equations by training a neural network to satisfy the governing physics directly. Instead of learning from labelled data, the network is penalised for violating the differential equation at randomly sampled collocation points. This works well when data is scarce, handles irregular domains naturally, and scales to inverse problems.

The natural question is whether quantum circuits can do this better. Quantum circuits operate in exponentially large Hilbert spaces and could, in principle, represent function classes that would require exponentially large classical networks. The reference paper by Panichi, Corli & Prati (arXiv:2503.12244) proposes a Quantum PINN (QPINN) architecture where a quantum circuit replaces part of the classical network, and reports competitive or superior results on benchmark PDEs.

However, the paper uses continuous-variable (CV) photonic circuits in Strawberry Fields, while Quandela's MerLin framework implements discrete-variable (DV) photonic circuits: single photons propagating through beam splitters and phase shifters. These are fundamentally different architectures. Our investigation is therefore a DV surrogate study of the same scientific question on Quandela's native hardware platform.

### The benchmark

We solve the 1D heat equation, the simplest non-trivial PDE with a known analytical solution:

$$\partial_t u = 0.1 \, \partial_{xx} u, \quad x \in [0,1], \; t \in [0,1]$$

with initial condition $u(x,0) = \sin(\pi x)$ and zero Dirichlet boundary conditions. The exact solution is $u(x,t) = e^{-0.1\pi^2 t} \sin(\pi x)$. Our primary metric is the relative L² error on a 50 x 50 evaluation grid. If a QPINN cannot solve this well, no stronger claim about harder problems is credible.

### The architecture

The QPINN is a hybrid model: a classical encoder (2 inputs to 4 features), a MerLin `QuantumLayer.simple()` photonic circuit (5 optical modes, 3 photons, 40 trainable phase angles), and a classical decoder (4 features to 2 outputs, where the second output is an auxiliary derivative estimate used by the consistency loss trick from the reference paper). Total: 270 trainable parameters.

The reference paper also introduces a "consistency loss trick" that avoids computing second derivatives through the quantum circuit by having the network output an auxiliary first-derivative estimate. Whether this trick is essential or merely convenient is one of the central questions of our investigation.

## 2. Experimental Design

Three principles governed every experiment.

**Parameter budget matching.** Every quantum-vs-classical comparison uses models with nearly identical parameter counts. The default classical PINN (2274 parameters) is 8.4x larger than the QPINN (270 parameters); comparing them directly is meaningless. We built a matched classical baseline with 282 parameters.

**Statistical robustness.** Every key result reports mean and standard deviation across 5 independent random seeds (42, 137, 256, 512, 1024). PINN training exhibits strong seed-to-seed variability, and single-seed results are unreliable.

**Identical conditions.** Same optimiser (Adam, lr=0.01), same training budget (300 epochs), same collocation points (64 interior, 32 boundary), same evaluation grid.

We organised 17 experiments across five phases:

**Phase 1 (Reproduction)** establishes baselines. We train the classical PINN, the QPINN, and a parameter-matched classical PINN, then compare accuracy, training speed, and scaling with circuit depth.

**Phase 2A (Ablations)** isolates the quantum layer's contribution through four targeted experiments: replacing the quantum layer with a classical linear layer, freezing the quantum parameters, removing the consistency loss trick and computing second derivatives directly, and sweeping the loss weight hyperparameter.

**Phase 2B (Simulability)** determines whether the circuit is genuinely quantum. We introspect the Perceval circuit to count modes and photons, measure simulation time scaling (polynomial vs exponential), estimate effective dimension via Jacobian SVD, and design deeper circuits using `CircuitBuilder`.

**Phase 2C (Generalisation and Noise)** tests whether the models have learned physics or merely memorised the training distribution. We train on half the time domain and evaluate extrapolation, perturb boundary conditions, and simulate hardware-realistic photon loss at Quandela X8 transmittance levels.

**Creative Extensions** introduce two novel contributions: a quantitative "Quantum Score" metric that measures how quantum a circuit actually is, and an energetic cost analysis using the Soret et al. (2026) framework comparing energy-per-accuracy for classical vs photonic computation.

## 3. Key Experiments and Results

### E1: The QPINN does not outperform classical at matched budgets

At matched parameter budgets (270 vs 282), the QPINN (L² = 0.0367) and the classical PINN (L² = 0.0451) are within 1 standard deviation of each other. The difference is not statistically significant. At optimal hyperparameters (lambda_i = 1 for both), the classical PINN wins decisively: L² = 0.0050 vs 0.0242, a 4.8x gap. The QPINN is also 30.8x slower to train due to photonic simulation overhead.

### E2.1-2.2: The quantum layer stabilises training

Replacing the quantum layer with a classical linear layer worsens mean accuracy by 80% and triples the standard deviation. Freezing the 40 quantum parameters causes catastrophic convergence failure on 1 in 5 seeds (L² = 0.2984 on seed 137, while other seeds remain below 0.053). The quantum layer is not a performance booster; it is a training stabiliser that prevents failure modes the classical replacement cannot avoid.

### E2.3: Removing the consistency trick improves accuracy 3.8x

This was the most surprising finding. Computing second derivatives directly via nested autodiff, without the auxiliary derivative output, improves QPINN accuracy from L² = 0.0367 to L² = 0.0097. This is the only configuration where the QPINN outperforms the parameter-matched classical baseline (0.0097 vs 0.0115). The consistency trick introduces a competing multi-objective optimisation that actively degrades the solution at this circuit size and training budget. The trick, presented as essential in the reference paper, is in fact harmful.

### E3: The circuit is classically simulable

The `simple()` circuit uses 5 optical modes with 3 photons, producing a Hilbert space of dimension 10 (smaller than a 4-qubit system). Simulation time scales polynomially as n^2.16, not exponentially. The MPS bond dimension is capped at 4 regardless of circuit depth. The effective dimension (Jacobian SVD proxy) is 1 for the QPINN vs 3 for the classical PINN. By every measure, this circuit is trivially classically simulable.

However, our Quantum Score metric (Q = 0.508) reveals that the circuit sits at the boundary of the genuinely quantum regime: it has substantial entangling structure (Q_ent = 0.532, with 50 out of 94 gates being beam splitters) and the optimiser relies heavily on the quantum parameters (Q_dep = 0.702), but simulation hardness remains the bottleneck (Q_hard = 0.290).

### E4.1: The QPINN extrapolates more consistently

Training on t in [0, 0.5] and evaluating on t in [0.5, 1.0], the QPINN degrades by 577% while the classical PINN degrades by 1712% (single seed; multi-seed validation is needed to confirm this finding). The quantum layer's limited expressibility acts as an implicit regulariser that prevents overfitting to the training domain. The classical PINN memorises the training region more tightly, which helps in-distribution but hurts extrapolation.

### E4.3: The QPINN is fragile to hardware noise

At the Quandela X8's operating transmittance (T = 0.68), photon loss causes 7.3x L² degradation compared to the noiseless baseline. At T = 0.50, degradation reaches 13.7x. The classical encoder and decoder were trained with a noiseless quantum layer and cannot compensate when noise corrupts the quantum output at inference time. Any practical deployment would require noise-aware training (injecting noise during forward passes), not just post-hoc evaluation.

### E5: The Quantum Score and energetic overhead

We propose a three-component Quantum Score Q in [0, 1] measuring how quantum a circuit actually is, computed from entangling gate fraction (Q_ent), simulation hardness (Q_hard), and gradient dependence on quantum parameters (Q_dep). All three components are measured from the circuit, not hardcoded. The `simple()` circuit scores Q = 0.508.

Using the Soret et al. (2026) Metric-Noise-Resource framework, the QPINN is approximately 18,000x more energy-expensive per forward pass and 7,600x worse on energy-per-accuracy. The cryogenic cooling alone (1.4 kW for the cryostat) dwarfs the computation. The energetic crossover requires approximately 15 idealised photons, the same threshold where classical simulation becomes exponentially hard. Both advantages are simultaneously out of reach at our circuit size.

## 4. Conclusions

The MerLin DV-photonic QPINN in its `QuantumLayer.simple()` configuration does not outperform a parameter-matched classical PINN in accuracy, speed, or expressibility. The circuit operates at the boundary of classical simulability (Q = 0.508), with polynomial simulation cost but high entangling structure and gradient dependence.

The quantum layer's genuine contribution is training stability and extrapolation consistency, not accuracy. It acts as an implicit regulariser: its limited expressibility prevents the catastrophic overfitting and convergence failures that plague the classical replacement. This is a real and measurable effect, but it comes at 30x training overhead and 18,000x energetic cost.

The consistency loss trick from the reference paper is harmful at this circuit size. Removing it produces the QPINN's best results and the only configuration where the QPINN outperforms classical baselines.

The QPINN is fragile to hardware noise. At the X8's operating transmittance, accuracy degrades by 7.3x, and noise-aware training would be required for any practical deployment.

The path to genuine quantum advantage is concrete: n >= 20 photons in m >= 40 modes with circuit depth >= 8, noise-aware training, and the consistency trick removed. These parameters correspond to near-term hardware targets (51-mode interferometers and 24-photon sources exist in principle) and represent engineering challenges rather than fundamental obstacles.

The honest answer to "are quantum PINNs actually doing anything?" is: yes, but not what you might expect, and not yet enough to justify the cost.
