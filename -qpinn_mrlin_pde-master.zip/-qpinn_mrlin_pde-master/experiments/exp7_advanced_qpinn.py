"""
exp7_advanced_qpinn.py
----------------------
Advanced photonic QPINN exploiting four non-trivial circuit properties:

  1. Entangled Input States
     Two QuantumLayer blocks start from different spread Fock states:
       Q_init : input_state = [1,1,1,0,0,0]  (photons in first 3 modes)
       Q_loop : input_state = [1,0,1,0,1,0]  (alternating modes)
     Different spread → different Hong-Ou-Mandel interference → decorrelated
     feature maps at every loop iteration.

  2. Photon Re-injection
     After Q_init produces measurements q₀, a classical gate computes:
       g  = sigmoid(W_gate · q₀)
       z₁ = z₀ + g ⊙ tanh(W_reinj · q₀)
     The gate signal g "re-injects" which features survive into Q_loop.
     Physically: measuring mode 0..2 and feeding result back into the
     encoding of modes 0..3 is equivalent to re-introducing photons at
     new positions conditioned on measurement outcomes.

  3. Photon Loops (quantum RNN)
     Q_loop is called L_loops times sharing weights.  Each iteration:
       q_l   = Q_loop(z_cur)
       z_cur = z₁ + tanh(W_loop · q_l)    # residual
     This is a quantum recurrent unit: same photons traverse the same
     interferometer multiple times with updated phase encodings.

  4. Hybrid Feedforward-Feedback
     The final readout combines measurements from both the initial block
     (feedforward path) and the last loop iteration (feedback path):
       u = readout( cat(q₀, q_L) )
     Early measurements q₀ thus influence the final output directly
     (feedback) while also shaping the inputs of subsequent loop stages.

Architecture diagram
--------------------
xt ─→ FF(trainable) ─→ proj ─→ z₀ ─────────────────────────────────→ ╮
                                 │                                       │
                         Q_init [1,1,1,0,0,0] ─→ q₀                  │
                                 │        │                             │
                             reinject     └──→ gate g                  │
                                 ▼                                       │
                              z₁ = z₀ + g⊙tanh(W·q₀)                 │
                                 │                                       │
                        ┌── LOOP × L ──────────────────┐              │
                        │  Q_loop [1,0,1,0,1,0]         │              │
                        │  z_cur → q_l → residual update │              │
                        └──────────────────────────────┘              │
                                 │ q_L                                  │
                                 ▼                                       │
                         readout( cat(q₀, q_L) ) ◄─────────────────╯
                                 │
                           cos(x) · u   [hard BC]

Comparison baselines
--------------------
  1. ClassicalMLP       — standard MLP + fixed Fourier features
  2. DataReuploadQPINN  — data-reuploading (no loops, no re-injection)
  3. ClassicalAdvanced  — same loop architecture, Q blocks → matched MLPs
  4. AdvancedQPINN      — full architecture described above

PDE: heat equation  u_t = u_xx  on [0,1]×[0,1]
     u₀(x) = sin(πx),  u(x,t) = exp(-π²t) sin(πx)  (analytic solution)

Training: IC supervised + FD-based PDE collocation (no 2nd-order autodiff)
Metrics:  RMSE on 80×80 grid,  seed-averaged mean ± std (3 seeds)
"""

import math, time, json, os, sys
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ── MerLin import ─────────────────────────────────────────────────────────────
try:
    import perceval as _pcvl  # noqa: F401 — must precede merlin to avoid openblas race
    import merlin as ML
    from merlin.core.components import BeamSplitter, Rotation, ParameterRole
    MERLIN_AVAILABLE = bool(hasattr(ML, "CircuitBuilder"))
    print(f"MerLin {getattr(ML, '__version__', '?')}  CircuitBuilder={MERLIN_AVAILABLE}")
except (ImportError, Exception) as _e:
    MERLIN_AVAILABLE = False
    print(f"MerLin not available ({_e}) — quantum blocks replaced by MLPs")

dtype = torch.float32
torch.set_default_dtype(dtype)

_here = os.path.abspath(os.path.dirname(__file__))
for _c in [os.path.join(_here, "..", "results"), "/cluster/home/lazhang/qpinn/results"]:
    if os.path.isdir(_c):
        RESULTS = os.path.abspath(_c)
        break
print(f"Results dir: {RESULTS}")

# ══════════════════════════════════════════════════════════════════════════════
# 1.  HEAT EQUATION SETUP  (x ∈ [0,1], t ∈ [0,1])
# ══════════════════════════════════════════════════════════════════════════════

def u_exact(x, t):
    """Analytical solution u(x,t) = exp(-π²t) sin(πx)."""
    if isinstance(x, torch.Tensor):
        return torch.exp(-math.pi**2 * t) * torch.sin(math.pi * x)
    return np.exp(-math.pi**2 * t) * np.sin(math.pi * x)

def u_ic_torch(x):
    return torch.sin(math.pi * x)

def hard_bc(x, u):
    """Enforce u(0,t)=u(1,t)=0 by multiplying by x*(1-x)."""
    return x * (1.0 - x) * u

def pde_residual_fd(model, xt, eps=1e-3):
    """FD residual of u_t = u_xx.  5 forward passes, no 2nd-order autodiff."""
    u     = model(xt)
    xt_xp = xt.detach().clone(); xt_xp[:, 0] = xt[:, 0].detach() + eps
    xt_xm = xt.detach().clone(); xt_xm[:, 0] = xt[:, 0].detach() - eps
    xt_tp = xt.detach().clone(); xt_tp[:, 1] = xt[:, 1].detach() + eps
    xt_tm = xt.detach().clone(); xt_tm[:, 1] = xt[:, 1].detach() - eps
    u_xx  = (model(xt_xp) - 2*u + model(xt_xm)) / eps**2
    u_t   = (model(xt_tp) - model(xt_tm)) / (2*eps)
    return u_t - u_xx    # α=1 for unit diffusivity

def paper_metrics(model, nx=80, nt=80):
    """RMSE on full grid against analytical solution."""
    xs = np.linspace(0, 1, nx)
    ts = np.linspace(0, 1, nt)
    X, T = np.meshgrid(xs, ts, indexing="ij")
    xt = torch.tensor(np.stack([X.ravel(), T.ravel()], 1), dtype=dtype)
    with torch.no_grad():
        pred = model(xt).detach().cpu().numpy().reshape(nx, nt)
    truth = u_exact(X, T)
    err = pred - truth
    return dict(
        rmse=float(np.sqrt(np.mean(err**2))),
        nmse=float(np.sum(err**2) / np.sum(truth**2)),
        max_err=float(np.abs(err).max()),
    )

def n_params(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)

# Collocation sampler
from scipy.stats import qmc as _qmc
_sobol = _qmc.Sobol(d=2, scramble=True, seed=0)

def _reset_sobol(s):
    global _sobol; _sobol = _qmc.Sobol(d=2, scramble=True, seed=int(s))

def sobol_xt(n):
    p = _sobol.random(n)
    return torch.tensor(p[:, :2], dtype=dtype)  # both dims already in [0,1]

def sobol_x_only(n):
    return torch.tensor(_sobol.random(n)[:, 0:1], dtype=dtype)


# ══════════════════════════════════════════════════════════════════════════════
# 2.  BUILDING BLOCKS
# ══════════════════════════════════════════════════════════════════════════════

class LearnableFF(nn.Module):
    """Trainable random Fourier features with learnable frequency matrix."""
    def __init__(self, in_dim=2, num_freqs=12, sigma_init=3.0, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        B = torch.randn(in_dim, num_freqs, generator=g) * sigma_init
        self.B = nn.Parameter(B)

    def forward(self, x):
        z = x @ self.B * (2 * math.pi)
        return torch.cat([torch.sin(z), torch.cos(z)], -1)


def _add_haar_scrambler(builder, n_modes, seed):
    """Brick-wall Haar-random interferometer as fixed scrambler."""
    rng = np.random.default_rng(int(seed))
    for col in range(n_modes - 1):
        start = col % 2
        for row in range(start, n_modes - 1, 2):
            builder.circuit.add(BeamSplitter(
                targets=(row, row + 1),
                theta_role=ParameterRole.FIXED,
                theta_value=float(rng.uniform(0, math.pi)),
                phi_role=ParameterRole.FIXED,
                phi_value=float(rng.uniform(0, 2 * math.pi)),
            ))
    for m in range(n_modes):
        builder.circuit.add(Rotation(
            target=m, role=ParameterRole.FIXED,
            value=float(rng.uniform(0, 2 * math.pi)), axis="z",
        ))


def _make_quantum_layer(n_modes, n_photons, feature_size, input_state,
                         q_depth=1, scramble_seed=None):
    """Build a QuantumLayer with optional Haar scrambler."""
    if not MERLIN_AVAILABLE:
        return None
    builder = ML.CircuitBuilder(n_modes=n_modes)
    for d in range(q_depth):
        builder.add_angle_encoding(
            modes=list(range(feature_size)),
            name=f"enc_{d}", subset_combinations=False)
        builder.add_entangling_layer(trainable=True, name=f"ent_{d}")
        if scramble_seed is not None:
            _add_haar_scrambler(builder, n_modes, seed=scramble_seed + d * 997)
    ql = ML.QuantumLayer(
        input_size=feature_size * q_depth,
        input_state=input_state,
        n_photons=n_photons,
        builder=builder,
        measurement_strategy=ML.MeasurementStrategy.PROBABILITIES,
        computation_space=ML.ComputationSpace.UNBUNCHED,
    )
    # Identity initialisation (Grant et al. 2019): zero trainable phases
    with torch.no_grad():
        for p in ql.parameters():
            p.fill_(0.0)
    return ql


def _mlp_fallback(in_dim, out_dim, hidden):
    """MLP used when MerLin is unavailable."""
    return nn.Sequential(
        nn.Linear(in_dim, hidden), nn.Tanh(),
        nn.Linear(hidden, out_dim), nn.Tanh(),
    )


# ══════════════════════════════════════════════════════════════════════════════
# 3.  MODELS
# ══════════════════════════════════════════════════════════════════════════════

# ── 3a. Classical MLP (vanilla baseline) ─────────────────────────────────────
class ClassicalMLP(nn.Module):
    """Standard PINN: fixed Fourier features + 3-layer MLP."""
    def __init__(self, num_freqs=12, sigma=3.0, hidden=64, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        B = torch.randn(2, num_freqs, generator=g) * sigma
        self.register_buffer("B", B)
        self.net = nn.Sequential(
            nn.Linear(2 * num_freqs, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden),         nn.Tanh(),
            nn.Linear(hidden, hidden),         nn.Tanh(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xt):
        z = 2 * math.pi * (xt @ self.B)
        phi = torch.cat([torch.sin(z), torch.cos(z)], -1)
        return hard_bc(xt[:, 0:1], self.net(phi))


# ── 3b. DataReuploadQPINN (standard baseline from exp5/6) ────────────────────
class DataReuploadQPINN(nn.Module):
    """Standard data-reuploading QPINN (no loops, no re-injection)."""
    def __init__(self, n_modes=5, n_photons=2, q_depth=2,
                 feature_size=4, num_freqs=12, sigma_init=3.0, hidden=24):
        super().__init__()
        self.q_depth = q_depth
        self.feature_size = feature_size
        self.ff   = LearnableFF(2, num_freqs, sigma_init)
        self.proj = nn.Linear(2 * num_freqs, feature_size)
        # Baseline input state: photons evenly spaced
        state = [0] * n_modes
        step  = n_modes // n_photons
        for i in range(n_photons):
            state[i * step] = 1
        self.quantum = _make_quantum_layer(
            n_modes, n_photons, feature_size, state,
            q_depth=q_depth, scramble_seed=42)
        if self.quantum is None:
            self.quantum = _mlp_fallback(feature_size * q_depth, 10, hidden)
            q_out = 10
        else:
            q_out = self.quantum.output_size
        self.readout = nn.Sequential(
            nn.Linear(q_out, hidden), nn.Tanh(), nn.Linear(hidden, 1))

    def forward(self, xt):
        z = torch.tanh(self.proj(self.ff(xt))).repeat(1, self.q_depth)
        return hard_bc(xt[:, 0:1], self.readout(self.quantum(z)))


# ── 3c. ClassicalAdvanced (matched loop architecture, no quantum) ─────────────
class ClassicalAdvanced(nn.Module):
    """
    Matched classical ablation of AdvancedQPINN: identical architecture but
    quantum blocks replaced by parameter-matched MLPs.  If AdvancedQPINN wins,
    the improvement is attributable to quantum processing, not architecture.
    """
    def __init__(self, feature_size=4, num_freqs=12, sigma_init=3.0,
                 q_out=20, hidden=32, n_loops=3):
        super().__init__()
        self.n_loops      = n_loops
        self.feature_size = feature_size
        self.ff   = LearnableFF(2, num_freqs, sigma_init)
        self.proj = nn.Linear(2 * num_freqs, feature_size)
        # Initial block (mirrors Q_init with q_depth=2 → input is f*2)
        self.mlp_init = _mlp_fallback(feature_size * 2, q_out, hidden)
        # Re-injection gate (same as AdvancedQPINN)
        self.reinj_gate = nn.Sequential(nn.Linear(q_out, feature_size), nn.Sigmoid())
        self.reinj_proj = nn.Linear(q_out, feature_size)
        # Loop block (mirrors Q_loop with q_depth=n_loops tiling)
        self.mlp_loop = _mlp_fallback(feature_size * n_loops, q_out, hidden)
        # Readout
        self.readout = nn.Sequential(
            nn.Linear(2 * q_out, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden),    nn.Tanh(),
            nn.Linear(hidden, 1))

    def forward(self, xt):
        x  = xt[:, 0:1]
        z0 = torch.tanh(self.proj(self.ff(xt)))               # (B, f)
        q0 = self.mlp_init(z0.repeat(1, 2))                   # (B, q_out)
        g  = self.reinj_gate(q0)
        z1 = z0 + g * torch.tanh(self.reinj_proj(q0))
        z_tiled = z1.repeat(1, self.n_loops)                  # (B, f*n_loops)
        q_L = self.mlp_loop(z_tiled)                          # (B, q_out)
        return hard_bc(x, self.readout(torch.cat([q0, q_L], -1)))


# ── 3d. AdvancedQPINN  ────────────────────────────────────────────────────────
class AdvancedQPINN(nn.Module):
    """
    Four-property advanced QPINN.

    1. Entangled Input States
       Q_init: input_state = [1,1,1,0,0,0] (photons in first 3 modes)
       Q_loop: input_state = [1,0,1,0,1,0] (alternating modes)
       Different photon spreads → different Hong-Ou-Mandel interference
       patterns → decorrelated feature maps between blocks.

    2. Photon Re-injection
       q₀ = Q_init(z₀) → classical gate g = σ(W·q₀)
       z₁ = z₀ + g ⊙ tanh(W_r·q₀)
       Measurements from Q_init gate which features flow into Q_loop,
       equivalent to photons being re-introduced at new mode positions
       conditioned on partial measurement outcomes.

    3. Photon Loops (via data reuploading with q_depth=n_loops)
       Q_loop uses q_depth=n_loops: the same features z₁ are encoded
       n_loops times into successive circuit layers (data reuploading),
       which is mathematically equivalent to photons traversing the
       interferometer n_loops times.  |Ω|_loop = 2·n_loops·n_photons+1.
       Critically: this costs ONE quantum call (not n_loops calls), so
       backward cost is O(1) regardless of loop count.

    4. Hybrid Feedforward-Feedback
       readout(cat(q₀, q_L)) — initial block measurement q₀ (early
       feedforward path) and final loop measurement q_L are combined.
       q₀ captures global structure; q_L refines local features after
       re-injection.  Early measurements thus influence the output
       directly (feedback) while also shaping loop inputs (feedforward).

    Cost: exactly 2 quantum forward+backward calls per training step,
    independent of n_loops.
    """
    def __init__(self, n_modes=6, n_photons=3,
                 feature_size=4, num_freqs=12, sigma_init=3.0,
                 hidden=32, n_loops=3):
        super().__init__()
        self.n_loops      = n_loops
        self.feature_size = feature_size

        self.ff   = LearnableFF(2, num_freqs, sigma_init)
        self.proj = nn.Linear(2 * num_freqs, feature_size)

        self.q_init_depth = 2   # q_depth=2: fast backward (JIT-compiled path)

        # ── Q_init: entangled input (q_depth=2, photons in first n_p modes) ──────
        # q_depth=2 activates the efficient compiled backward path in MerLin
        # (q_depth=1 triggers a slower fallback path, ~10× slower backward).
        init_state = [0] * n_modes
        for i in range(n_photons):
            init_state[i] = 1                             # e.g. [1,1,1,0,0,0]
        self.Q_init = _make_quantum_layer(
            n_modes, n_photons, feature_size, init_state,
            q_depth=self.q_init_depth, scramble_seed=7)
        if self.Q_init is None:
            self.Q_init = _mlp_fallback(feature_size * self.q_init_depth, 20, hidden)
            q_out = 20
        else:
            q_out = self.Q_init.output_size              # C(n_modes, n_photons)

        # ── Re-injection gate (classical) ────────────────────────────────────────
        self.reinj_gate = nn.Sequential(nn.Linear(q_out, feature_size), nn.Sigmoid())
        self.reinj_proj = nn.Linear(q_out, feature_size)

        # ── Q_loop: photon loop via data reuploading (q_depth = n_loops) ─────────
        # input_state uses alternating spread [1,0,1,0,1,0] for maximal
        # Hong-Ou-Mandel contrast with Q_init's consecutive spread.
        loop_state = [0] * n_modes
        step = n_modes // n_photons
        for i in range(n_photons):
            loop_state[i * step] = 1                     # e.g. [1,0,1,0,1,0]
        self.Q_loop = _make_quantum_layer(
            n_modes, n_photons, feature_size, loop_state,
            q_depth=n_loops, scramble_seed=13)           # reuploading = loop
        if self.Q_loop is None:
            self.Q_loop = _mlp_fallback(feature_size * n_loops, q_out, hidden)
            loop_out = q_out
        else:
            loop_out = self.Q_loop.output_size

        # ── Hybrid readout: initial + loop measurements ──────────────────────────
        self.readout = nn.Sequential(
            nn.Linear(q_out + loop_out, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden),            nn.Tanh(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xt):
        x  = xt[:, 0:1]
        z0 = torch.tanh(self.proj(self.ff(xt)))              # (B, feature_size)

        # ── Initial block (entangled input, q_depth=q_init_depth) ──────────────────
        z0_tiled = z0.repeat(1, self.q_init_depth)            # (B, f*q_init_depth)
        q0 = self.Q_init(z0_tiled)                            # (B, q_out)

        # ── Re-injection: gate q₀ to modify loop encoding ────────────────────────
        g  = self.reinj_gate(q0)                              # (B, feature_size)
        z1 = z0 + g * torch.tanh(self.reinj_proj(q0))         # (B, feature_size)

        # ── Photon loop (data reuploading, q_depth=n_loops) ──────────────────────
        # Tile z₁ n_loops times → photon re-encodes features n_loops times
        z_tiled = z1.repeat(1, self.n_loops)                  # (B, f * n_loops)
        q_L = self.Q_loop(z_tiled)                            # (B, loop_out)

        # ── Hybrid feedforward-feedback readout ───────────────────────────────────
        return hard_bc(x, self.readout(torch.cat([q0, q_L], dim=-1)))


# ══════════════════════════════════════════════════════════════════════════════
# 4.  TRAINING
# ══════════════════════════════════════════════════════════════════════════════

def train(model, *, n_ic=64, n_pde=128, epochs=600, lr=3e-3,
          lbfgs_steps=40, seed=0, verbose=False):
    """
    Curriculum training to avoid the trivial-solution attractor (u=0 satisfies
    PDE+BCs but not the IC).

    IC weight warmup schedule (prevents PDE from swamping IC signal at the start):
      epochs 0   … 20%  : w_ic = 100   (IC phase — establish non-trivial solution)
      epochs 20% … 40%  : w_ic = 50
      epochs 40% … 60%  : w_ic = 20
      epochs 60% … end  : w_ic = 10

    Phase 2 (L-BFGS): joint IC + PDE fine-tune with w_ic=10.
    """
    _reset_sobol(seed)
    mse = nn.MSELoss()
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)

    loss_history = []
    e20, e40, e60 = int(0.2 * epochs), int(0.4 * epochs), int(0.6 * epochs)
    for ep in range(epochs):
        opt.zero_grad()
        # IC loss
        x_ic  = sobol_x_only(n_ic)
        xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], 1)
        li = mse(model(xt_ic), u_ic_torch(x_ic))
        # PDE collocation loss (FD)
        xt_f = sobol_xt(n_pde)
        xt_f[:, 0] = xt_f[:, 0].clamp(0.005, 0.995)
        xt_f[:, 1] = xt_f[:, 1].clamp(0.005, 0.995)
        lp = mse(pde_residual_fd(model, xt_f), torch.zeros(n_pde, 1))
        # Curriculum IC weight
        if ep < e20:
            w_ic = 100.0
        elif ep < e40:
            w_ic = 50.0
        elif ep < e60:
            w_ic = 20.0
        else:
            w_ic = 10.0
        loss = w_ic * li + lp
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        loss_history.append(float(li.item() + lp.item()))
        if verbose and ep % 100 == 0:
            print(f"  ep={ep:4d}  w_ic={w_ic:.0f}  IC={li.item():.3e}  PDE={lp.item():.3e}")

    # L-BFGS fine-tune: joint IC+PDE with w_ic=10
    if lbfgs_steps > 0:
        opt2 = torch.optim.LBFGS(model.parameters(), lr=0.2,
                                  max_iter=lbfgs_steps, history_size=20)
        _reset_sobol(seed + 100)
        def _cl():
            opt2.zero_grad()
            x_ic  = sobol_x_only(n_ic * 2)
            xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], 1)
            li2   = mse(model(xt_ic), u_ic_torch(x_ic))
            xt_f2 = sobol_xt(n_pde * 2)
            xt_f2[:, 0] = xt_f2[:, 0].clamp(0.005, 0.995)
            xt_f2[:, 1] = xt_f2[:, 1].clamp(0.005, 0.995)
            lp2 = mse(pde_residual_fd(model, xt_f2), torch.zeros(n_pde * 2, 1))
            l = 10.0 * li2 + lp2; l.backward()
            return l
        opt2.step(_cl)
    return loss_history


# ══════════════════════════════════════════════════════════════════════════════
# 5.  EXPERIMENT
# ══════════════════════════════════════════════════════════════════════════════

MODEL_CFGS = [
    ("ClassicalMLP",       lambda: ClassicalMLP(num_freqs=12, hidden=64)),
    ("DataReuploadQPINN",  lambda: DataReuploadQPINN(num_freqs=12)),
    ("ClassicalAdvanced",  lambda: ClassicalAdvanced(num_freqs=12, n_loops=3)),
    ("AdvancedQPINN",      lambda: AdvancedQPINN(num_freqs=12, n_loops=3)),
]


def run_experiment(seeds=(0, 1, 2), epochs=500, n_ic=64, n_pde=64,
                   lbfgs_steps=40, verbose=False):
    """
    Train all four models on 3 seeds and collect RMSE statistics.
    """
    print("\n" + "=" * 72)
    print("Experiment: Advanced QPINN vs Baselines")
    print(f"  Seeds={list(seeds)}  epochs={epochs}  n_ic={n_ic}  n_pde={n_pde}")
    if not MERLIN_AVAILABLE:
        print("  [WARNING] MerLin unavailable — quantum blocks replaced by MLPs")
    print("=" * 72)

    # Print parameter counts
    for label, m_fn in MODEL_CFGS:
        m = m_fn()
        print(f"  {label:22s}  params={n_params(m):5d}")
    print()

    all_metrics = {label: [] for label, _ in MODEL_CFGS}
    all_histories = {label: [] for label, _ in MODEL_CFGS}

    for seed in seeds:
        for label, m_fn in MODEL_CFGS:
            torch.manual_seed(seed); np.random.seed(seed)
            m = m_fn()
            t0 = time.perf_counter()
            history = train(m, n_ic=n_ic, n_pde=n_pde, epochs=epochs,
                            lbfgs_steps=lbfgs_steps, seed=seed, verbose=verbose)
            elapsed = time.perf_counter() - t0
            met = paper_metrics(m)
            all_metrics[label].append(met)
            all_histories[label].append(history)
            print(f"  seed={seed}  {label:22s}  "
                  f"RMSE={met['rmse']:.4e}  maxErr={met['max_err']:.4e}  "
                  f"t={elapsed:.0f}s")

    # ── Summary table ──────────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("SUMMARY  (mean ± std over seeds)")
    print("=" * 72)
    print(f"{'Model':25s}  {'RMSE mean':>12s}  {'RMSE std':>10s}  "
          f"{'Max err mean':>13s}  {'vs ClassicalMLP':>16s}")
    print("─" * 72)
    base_rmse = None
    summary = {}
    for label, _ in MODEL_CFGS:
        rmses   = [m["rmse"]    for m in all_metrics[label]]
        maxerrs = [m["max_err"] for m in all_metrics[label]]
        mu_r, sd_r = np.mean(rmses), np.std(rmses)
        mu_m       = np.mean(maxerrs)
        if base_rmse is None:
            base_rmse = mu_r
        ratio = base_rmse / mu_r
        star = "★" if ratio > 1.05 else ("" if ratio > 0.95 else "")
        print(f"  {label:23s}  {mu_r:>12.4e}  {sd_r:>10.4e}  "
              f"{mu_m:>13.4e}  {ratio:>14.3f}× {star}")
        summary[label] = dict(rmse_mean=mu_r, rmse_std=sd_r,
                               max_err_mean=mu_m, ratio_vs_classical=ratio)
    print()
    print("★ = >5% improvement over ClassicalMLP baseline")

    # ── Save JSON ──────────────────────────────────────────────────────────────
    out = os.path.join(RESULTS, "exp7_advanced_qpinn.json")
    with open(out, "w") as f:
        json.dump({k: {kk: float(vv) for kk, vv in v.items()}
                   for k, v in summary.items()}, f, indent=2)
    print(f"\nResults saved: {out}")

    return all_metrics, all_histories, summary


def plot_results(all_metrics, all_histories, summary):
    """Three-panel figure: RMSE box plots, loss curves, parameter efficiency."""
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    labels    = [l for l, _ in MODEL_CFGS]
    colors    = ["#555555", "#C44E52", "#2ca02c", "#4C72B0"]

    # ── Panel 1: RMSE box plot ─────────────────────────────────────────────────
    ax = axes[0]
    rmse_data = [[m["rmse"] for m in all_metrics[l]] for l in labels]
    bp = ax.boxplot(rmse_data, patch_artist=True, widths=0.5,
                    medianprops=dict(color="black", lw=2))
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color); patch.set_alpha(0.75)
    ax.set_yscale("log")
    ax.set_xticks(range(1, len(labels) + 1))
    ax.set_xticklabels([l.replace("QPINN", "Q").replace("Advanced", "Adv")
                        for l in labels], rotation=20, fontsize=8)
    ax.set_ylabel("RMSE (log scale)")
    ax.set_title("Accuracy (3 seeds)\nlower is better")

    # ── Panel 2: loss convergence curves ──────────────────────────────────────
    ax = axes[1]
    for (label, _), color in zip(MODEL_CFGS, colors):
        histories = all_histories[label]
        arr = np.array(histories)  # (seeds, epochs)
        mu  = arr.mean(0)
        sd  = arr.std(0)
        xs  = np.arange(len(mu))
        ax.semilogy(xs, mu, color=color, label=label.replace("QPINN","Q"), lw=1.5)
        ax.fill_between(xs, mu - sd, (mu + sd).clip(1e-12),
                        color=color, alpha=0.15)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Loss (log)")
    ax.set_title("Convergence curves\nmean ± std over seeds")
    ax.legend(fontsize=7)

    # ── Panel 3: accuracy vs parameter count ──────────────────────────────────
    ax = axes[2]
    for (label, m_fn), color in zip(MODEL_CFGS, colors):
        m = m_fn()
        p = n_params(m)
        mu = summary[label]["rmse_mean"]
        sd = summary[label]["rmse_std"]
        ax.errorbar(p, mu, yerr=sd, fmt="o", color=color, ms=10, capsize=5)
        ax.annotate(label.replace("QPINN","Q").replace("Advanced","Adv"),
                    (p, mu), textcoords="offset points",
                    xytext=(6, 3), fontsize=7)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Parameter count"); ax.set_ylabel("RMSE (mean)")
    ax.set_title("Parameter efficiency\nlower-right is better")

    plt.suptitle(
        "Advanced QPINN: Entangled Input + Re-injection + Photon Loops + Hybrid FF\n"
        "Heat equation  u_t = u_xx,  u₀(x)=sin(πx),  u(x,t)=exp(-π²t)sin(πx)",
        fontsize=10, y=1.02)
    plt.tight_layout()
    out = os.path.join(RESULTS, "exp7_advanced_qpinn.png")
    plt.savefig(out, dpi=130, bbox_inches="tight")
    print(f"Figure saved: {out}")
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# 6.  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Advanced photonic QPINN experiment")
    p.add_argument("--seeds",   type=int, nargs="+", default=[0, 1, 2])
    p.add_argument("--epochs",  type=int, default=500)
    p.add_argument("--n-ic",    type=int, default=64)
    p.add_argument("--n-pde",   type=int, default=64)
    p.add_argument("--lbfgs",   type=int, default=40)
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--quick",   action="store_true",
                   help="Quick test: 1 seed, 100 epochs, 32 colloc pts")
    args = p.parse_args()

    if args.quick:
        args.seeds   = [0]
        args.epochs  = 100
        args.n_ic    = 32
        args.n_pde   = 32
        args.lbfgs   = 10

    metrics, histories, summary = run_experiment(
        seeds=args.seeds, epochs=args.epochs,
        n_ic=args.n_ic, n_pde=args.n_pde,
        lbfgs_steps=args.lbfgs, verbose=args.verbose)
    plot_results(metrics, histories, summary)
