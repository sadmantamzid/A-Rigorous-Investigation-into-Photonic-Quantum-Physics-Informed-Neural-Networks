"""
exp5_boson_sampling_qpinn.py
----------------------------
Demonstrates quantum advantage for photonic boson sampling by adding
non-Gaussian (Haar-random fixed interferometer) scrambler layers to a
data-reuploading QPINN, then analysing:

  1. Hilbert-space / classical-cost scaling across (n_modes, n_photons)
  2. Gradient-variance diagnostics: identity init vs barren plateau as dim H grows
  3. Head-to-head RMSE on the heat equation at scaled circuit sizes
  4. Boson sampling output distribution vs Haar-uniform benchmark

References
----------
- Aaronson & Arkhipov (2011): boson sampling is #P-hard
- Reck et al. (1994) / Clements et al. (2016): universal interferometer decomposition
- Holmes et al. (2022): expressibility vs barren plateau
- Grant et al. (2019): identity initialisation
"""

import math, time, json, os, sys
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from math import comb
from scipy.integrate import solve_ivp
from scipy.stats import qmc

# ── locate merlinquantum ───────────────────────────────────────────────────────
try:
    import merlin as ML
    from merlin.core.components import BeamSplitter, Rotation, ParameterRole
    MERLIN_AVAILABLE = True
    print(f"MerLin {getattr(ML, '__version__', '?')} — CircuitBuilder: {hasattr(ML,'CircuitBuilder')}")
except ImportError:
    MERLIN_AVAILABLE = False
    print("MerLin not found — quantum cells will use a classical fallback.")

dtype  = torch.float32
device = torch.device("cpu")
torch.set_default_dtype(torch.float32)
torch.manual_seed(0)
np.random.seed(0)

_here = os.path.abspath(os.path.dirname(__file__))
for _c in [os.path.join(_here, "..", "results"), "/cluster/home/lazhang/qpinn/results"]:
    if os.path.isdir(_c):
        RESULTS = os.path.abspath(_c)
        break
print(f"Results dir: {RESULTS}")

# ══════════════════════════════════════════════════════════════════════════════
# 1.  PDE SETUP (heat equation, shared with other experiments)
# ══════════════════════════════════════════════════════════════════════════════
alpha_d  = 0.30
x_min, x_max = -math.pi/2, math.pi/2
t_min, t_max = 0.0, 0.5
sigma_sq = 0.2
x_shift  = math.pi/8

def T0_torch(x): return 0.5 * torch.exp(-(x + x_shift)**2 / (2.0*sigma_sq))

_NX, _NT = 257, 101
ref_x = np.linspace(x_min, x_max, _NX)
ref_t = np.linspace(t_min, t_max, _NT)
_dx   = ref_x[1] - ref_x[0]
_T0g  = 0.5 * np.exp(-(ref_x + x_shift)**2 / (2.0*sigma_sq))
_T0g[0] = _T0g[-1] = 0.0

def _rhs(_t, T):
    d2 = np.zeros_like(T)
    d2[1:-1] = (T[2:] - 2*T[1:-1] + T[:-2]) / _dx**2
    return alpha_d * d2

_sol = solve_ivp(_rhs, (0, t_max), _T0g, t_eval=ref_t,
                 method="RK45", rtol=1e-8, atol=1e-10, max_step=1e-3)
T_REF = _sol.y

def ref_interp(x_np, t_np):
    ix = np.clip((x_np - ref_x[0]) / _dx, 0, _NX-2).astype(int)
    dt = ref_t[1] - ref_t[0]
    it = np.clip((t_np - ref_t[0]) / dt, 0, _NT-2).astype(int)
    fx = (x_np - ref_x[0]) / _dx - ix
    ft = (t_np - ref_t[0]) / dt  - it
    return ((1-fx)*(1-ft)*T_REF[ix,it] + fx*(1-ft)*T_REF[ix+1,it]
          + (1-fx)*ft*T_REF[ix,it+1]  + fx*ft*T_REF[ix+1,it+1])

_sobol = qmc.Sobol(d=2, scramble=True, seed=0)
def _reset_sobol(s): global _sobol; _sobol = qmc.Sobol(d=2, scramble=True, seed=int(s))
def sobol_xt(n):
    p = _sobol.random(n)
    x = x_min + (x_max-x_min)*p[:,0:1]
    t = t_min + (t_max-t_min)*p[:,1:2]
    return torch.tensor(np.concatenate([x,t],1), dtype=dtype)
def sobol_x_only(n):
    p = _sobol.random(n)
    return torch.tensor(x_min + (x_max-x_min)*p[:,0:1], dtype=dtype)

def paper_metrics(pred_fn, nx=80, nt=80):
    xs = np.linspace(x_min, x_max, nx); ts = np.linspace(t_min, t_max, nt)
    X, T = np.meshgrid(xs, ts, indexing="ij")
    xt_np = np.stack([X.ravel(), T.ravel()], 1)
    xt    = torch.tensor(xt_np, dtype=dtype)
    with torch.no_grad():
        Tp = pred_fn(xt).detach().cpu().numpy().reshape(nx, nt)
    Tt = ref_interp(xt_np[:,0], xt_np[:,1]).reshape(nx, nt)
    e  = Tp - Tt
    return dict(rmse=float(np.sqrt(np.mean(e**2))),
                mae=float(np.mean(np.abs(e))),
                linf=float(np.max(np.abs(e))))

def _hard_bc(x, q_u): return torch.cos(x) * q_u
def _grad(y, x):
    return torch.autograd.grad(y, x, grad_outputs=torch.ones_like(y),
                               create_graph=True, retain_graph=True)[0]
def residual_nested(model, xt):
    T    = model(xt)
    gT   = _grad(T, xt)
    T_xx = _grad(gT[:,0:1], xt)[:,0:1]
    return gT[:,1:2] - alpha_d * T_xx
def n_trainable(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


# ══════════════════════════════════════════════════════════════════════════════
# 2.  NON-GAUSSIAN CIRCUIT COMPONENTS
# ══════════════════════════════════════════════════════════════════════════════

def _add_haar_scrambler(builder, n_modes: int, seed: int) -> None:
    """
    Append a fixed Haar-random interferometer block to the circuit.

    Implementation: brick-wall MZI mesh (alternating even/odd columns).
    Depth = n_modes - 1 columns → covers all O(n²) beamsplitter positions,
    giving a distribution close to Haar measure (Clements 2016).

    Parameters
    ----------
    builder  : ML.CircuitBuilder
    n_modes  : number of optical modes
    seed     : RNG seed for reproducibility (each scrambler layer uses a
               different seed so consecutive scramblers are independent)

    Non-Gaussianity note
    --------------------
    The gate set {BS, PhaseShift} is GAUSSIAN on coherent / squeezed states.
    Non-Gaussianity here arises from the FOCK STATE input: |n_1,...,n_k⟩ is
    non-Gaussian, so the full circuit computes permanents of submatrices of U
    (Aaronson & Arkhipov 2011) — a #P-hard operation classically.
    Adding scramblers maximises the "hardness" of the permanent by ensuring U
    is close to Haar-random rather than a structured (easy) matrix.
    """
    rng = np.random.default_rng(int(seed))
    for col in range(n_modes - 1):
        start = col % 2  # alternating even/odd column offsets
        for row in range(start, n_modes - 1, 2):
            theta = float(rng.uniform(0, math.pi))
            phi   = float(rng.uniform(0, 2 * math.pi))
            builder.circuit.add(BeamSplitter(
                targets=(row, row + 1),
                theta_role=ParameterRole.FIXED, theta_value=theta,
                phi_role=ParameterRole.FIXED,   phi_value=phi,
            ))
    # Final random diagonal phase shifts
    for m in range(n_modes):
        builder.circuit.add(Rotation(
            target=m, role=ParameterRole.FIXED,
            value=float(rng.uniform(0, 2 * math.pi)), axis="z",
        ))


def _spaced_fock_state(n_modes: int, n_photons: int) -> list:
    occupied = sorted(set(np.linspace(0, n_modes-1, n_photons, dtype=int).tolist()))
    state = [0] * n_modes
    for m in occupied: state[m] = 1
    return state


def make_bs_circuit(n_modes: int, n_photons: int, feature_size: int,
                    q_depth: int, scramble: bool = True):
    """
    Build a data-reuploading DV circuit with optional Haar-random scramblers.

    Layout (per layer d):
        angle_encoding(x)  →  trainable entangling  →  [fixed Haar scrambler]

    The scrambler layers are NOT trainable and inject the maximum
    boson-sampling hardness (#P-hard regime) between trainable blocks.
    Identity init on the trainable phases keeps initial grad var = O(1).

    Returns
    -------
    ML.QuantumLayer with input_size = feature_size * q_depth
    """
    if not MERLIN_AVAILABLE:
        return None
    builder = ML.CircuitBuilder(n_modes=n_modes)
    for d in range(q_depth):
        builder.add_angle_encoding(
            modes=list(range(feature_size)),
            name=f"enc_{d}",
            subset_combinations=False,
        )
        builder.add_entangling_layer(trainable=True, name=f"ent_{d}")
        if scramble:
            # Seed depends on layer + config so each scrambler is independent
            _add_haar_scrambler(builder, n_modes, seed=d * 997 + n_modes * 31)
    state = _spaced_fock_state(n_modes, n_photons)
    return ML.QuantumLayer(
        input_size=feature_size * q_depth,
        input_state=state,
        n_photons=n_photons,
        builder=builder,
        measurement_strategy=ML.MeasurementStrategy.PROBABILITIES,
        computation_space=ML.ComputationSpace.UNBUNCHED,
    )


# ══════════════════════════════════════════════════════════════════════════════
# 3.  MODEL CLASSES
# ══════════════════════════════════════════════════════════════════════════════

class LearnableFourierFeatures(nn.Module):
    def __init__(self, in_dim=2, num_freqs=8, sigma_init=2.0, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        self.B = nn.Parameter(torch.randn(in_dim, num_freqs, generator=g) * sigma_init)
    def forward(self, x):
        z = x @ self.B * (2 * math.pi)
        return torch.cat([torch.sin(z), torch.cos(z)], -1)
    def bandwidth(self): return self.B.norm(dim=0).mean().item()


class BosonSamplingQPINN(nn.Module):
    """
    Physics-Informed Neural Network backed by a boson-sampling-strength
    photonic circuit.

    Architecture
    ------------
    x → LearnableFourierFeatures(B) → Linear → tanh → tile(q_depth)
      → QuantumLayer [encode → entangle → Haar scramble] × q_depth
      → readout MLP → u(x,t)

    Quantum advantage argument
    --------------------------
    The Haar scramblers push the photon output distribution into the regime
    where computing P(s) = |Perm(U_S)|² is #P-hard classically.
    Circuit size parameters:
      dim H = C(n_modes + n_photons - 1, n_photons)
      Classical Ryser cost per sample: 2^n_photons × n_photons²
    """
    def __init__(self, n_modes=8, n_photons=3, q_depth=3,
                 feature_size=4, num_freqs=8, sigma_init=3.0,
                 hidden=24, scramble=True):
        super().__init__()
        self.n_modes      = n_modes
        self.n_photons    = n_photons
        self.q_depth      = q_depth
        self.feature_size = feature_size
        self.scramble     = scramble

        self.ff   = LearnableFourierFeatures(2, num_freqs, sigma_init)
        self.proj = nn.Linear(2 * num_freqs, feature_size)

        self.quantum = make_bs_circuit(n_modes, n_photons, feature_size,
                                       q_depth, scramble=scramble)
        if self.quantum is not None:
            # Identity init: zero trainable phases → O(1) initial grad var
            with torch.no_grad():
                for p in self.quantum.parameters():
                    p.fill_(0.0)
            q_out = self.quantum.output_size
        else:
            q_out = feature_size
            self.quantum = nn.Sequential(
                nn.Linear(feature_size * q_depth, hidden), nn.Tanh(),
                nn.Linear(hidden, q_out))

        self.readout = nn.Sequential(
            nn.Linear(q_out, hidden), nn.Tanh(), nn.Linear(hidden, 1))

    def forward(self, xt):
        x   = xt[:, 0:1]
        z   = torch.tanh(self.proj(self.ff(xt)))    # (B, feature_size)
        z   = z.repeat(1, self.q_depth)              # (B, feature_size * q_depth)
        return _hard_bc(x, self.readout(self.quantum(z)))

    @property
    def hilbert_dim(self): return comb(self.n_modes + self.n_photons - 1, self.n_photons)

    @property
    def ryser_ops(self): return 2**self.n_photons * self.n_photons**2

    @property
    def frequency_bound(self): return self.q_depth * self.n_photons


# ══════════════════════════════════════════════════════════════════════════════
# 4.  TRAINING UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

class NTKBalancedTrainer:
    def __init__(self, terms=("pde","ic"), alpha=0.9):
        self.alpha = alpha
        self._w    = {t: 1.0 for t in terms}

    def _gnorm(self, loss, params):
        gs = torch.autograd.grad(loss, params, retain_graph=True, allow_unused=True)
        return max((g.abs().max().item() for g in gs if g is not None), default=1e-8)

    def update(self, losses, model):
        params = [p for p in model.parameters() if p.requires_grad]
        norms  = {k: self._gnorm(v, params) for k, v in losses.items()}
        ref    = norms.get("pde", max(norms.values()))
        for k in losses:
            t = ref / (norms[k] + 1e-8)
            self._w[k] = self.alpha * self._w[k] + (1-self.alpha) * t

    def __getitem__(self, k): return self._w.get(k, 1.0)


def train(model, pretrain=150, epochs=350, lr=5e-3, lbfgs_steps=30,
          ntk_every=40, n_f=128, n_i=128, seed=0):
    _reset_sobol(seed)
    mse = nn.MSELoss()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    ntk = NTKBalancedTrainer()
    t0  = time.perf_counter()

    for _ in range(pretrain):
        opt.zero_grad()
        x_ic  = sobol_x_only(n_i)
        xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], 1)
        mse(model(xt_ic), T0_torch(x_ic)).backward()
        opt.step()

    for ep in range(epochs):
        opt.zero_grad()
        xt_f  = sobol_xt(n_f); xt_f.requires_grad_(True)
        x_ic  = sobol_x_only(n_i)
        xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], 1)
        lp = mse(residual_nested(model, xt_f), torch.zeros(n_f, 1))
        li = mse(model(xt_ic), T0_torch(x_ic))
        if ep % ntk_every == 0: ntk.update({"pde": lp, "ic": li}, model)
        loss = ntk["pde"]*lp + ntk["ic"]*li
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

    opt_lb = torch.optim.LBFGS(model.parameters(), lr=0.1, max_iter=20)
    def _closure():
        opt_lb.zero_grad()
        xt2 = sobol_xt(n_f); xt2.requires_grad_(True)
        l   = mse(residual_nested(model, xt2), torch.zeros(n_f, 1))
        l.backward(); return l
    for _ in range(max(1, lbfgs_steps // 20)):
        opt_lb.step(_closure)

    return time.perf_counter() - t0


def measure_gradient_variance(model, n_trials=80, n_pts=16):
    """Var[∂L/∂θ_k] over quantum parameters only (BP diagnostic)."""
    mse     = nn.MSELoss()
    qparams = list(model.quantum.parameters())
    if not qparams: return float("nan"), float("nan"), 0
    grads = []
    for _ in range(n_trials):
        xt = torch.cat([torch.FloatTensor(n_pts,1).uniform_(x_min,x_max),
                        torch.FloatTensor(n_pts,1).uniform_(t_min,t_max)], 1)
        model.zero_grad()
        mse(model(xt), torch.zeros(n_pts,1)).backward()
        g = torch.cat([p.grad.flatten() for p in qparams if p.grad is not None])
        if g.numel(): grads.append(g.detach())
    if not grads: return float("nan"), float("nan"), 0
    G = torch.stack(grads)
    v = G.var(0)
    return v.mean().item(), v.max().item(), G.shape[1]


# ══════════════════════════════════════════════════════════════════════════════
# 5.  EXPERIMENT A — Scaling table and hardness plot
# ══════════════════════════════════════════════════════════════════════════════

def exp_a_scaling():
    print("\n" + "="*70)
    print("Experiment A: Boson Sampling Hilbert-Space and Classical-Cost Scaling")
    print("="*70)

    configs = [(5,2),(8,3),(10,4),(12,5),(15,7),(20,10),(30,15),(50,25)]
    hdr = f"{'Config':14s}  {'dim H':>14s}  {'log₂ H':>8s}  {'Ryser ops':>12s}  Regime"
    print(hdr); print("─"*70)
    rows = []
    for m, n in configs:
        hdim  = comb(m + n - 1, n)
        ryser = 2**n * n**2
        if ryser > 1e14:      regime = "★ supremacy"
        elif ryser > 1e9:     regime = "→ hard"
        else:                 regime = "  simulable"
        print(f"({m:2d}m,{n:2d}p)         {hdim:>14,d}  {math.log2(hdim):>8.1f}  {ryser:>12.2e}  {regime}")
        rows.append((m, n, hdim, ryser))

    n_arr  = np.arange(2, 31)
    ryser  = 2.0**n_arr * n_arr**2
    hdim5  = np.array([comb(5  + n - 1, n) for n in n_arr])
    hdim12 = np.array([comb(12 + n - 1, n) for n in n_arr])
    hdim20 = np.array([comb(20 + n - 1, n) for n in n_arr])

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
    axes[0].semilogy(n_arr, ryser,  "k--", lw=2,   label="Ryser cost  2ⁿn²")
    axes[0].semilogy(n_arr, hdim5,  color="#C44E52", lw=1.8, label="dim H, m=5")
    axes[0].semilogy(n_arr, hdim12, color="#4C72B0", lw=1.8, label="dim H, m=12")
    axes[0].semilogy(n_arr, hdim20, color="#55A868", lw=1.8, label="dim H, m=20")
    axes[0].axvspan(20, 30, alpha=0.08, color="gold", label="supremacy zone (est.)")
    axes[0].set_xlabel("n photons"); axes[0].set_ylabel("Count (log)")
    axes[0].set_title("Classical cost vs Hilbert-space dimension")
    axes[0].legend(fontsize=8)

    axes[1].semilogy(n_arr, ryser / np.maximum(hdim12, 1),
                     color="#4C72B0", lw=2, label="m=12")
    axes[1].semilogy(n_arr, ryser / np.maximum(hdim20, 1),
                     color="#55A868", lw=2, label="m=20")
    axes[1].axhline(1, ls="--", color="gray", label="parity")
    axes[1].fill_between(n_arr, 1, ryser/np.maximum(hdim20,1),
                         where=(ryser > hdim20), alpha=0.12,
                         color="#55A868", label="quantum adv. (m=20)")
    axes[1].set_xlabel("n photons")
    axes[1].set_ylabel("Ryser ops / dim H  (>1 = classically intractable)")
    axes[1].set_title("Quantum advantage ratio")
    axes[1].legend(fontsize=8)
    plt.suptitle("Photonic boson sampling: hardness scaling", y=1.02)
    plt.tight_layout()
    out = os.path.join(RESULTS, "exp5_bs_scaling.png")
    plt.savefig(out, dpi=120); print(f"\nSaved: {out}")
    plt.show()


# ══════════════════════════════════════════════════════════════════════════════
# 6.  EXPERIMENT B — Gradient variance: identity init across circuit scales
# ══════════════════════════════════════════════════════════════════════════════

def exp_b_gradient_variance():
    if not MERLIN_AVAILABLE:
        print("Skipped (MerLin not available).")
        return
    print("\n" + "="*70)
    print("Experiment B: Gradient Variance vs Circuit Scale (BP Diagnostic)")
    print("="*70)

    variants = [
        ("5m-2p  no-scramble", dict(n_modes=5, n_photons=2, q_depth=2, scramble=False)),
        ("5m-2p  Haar-scramble",dict(n_modes=5, n_photons=2, q_depth=2, scramble=True)),
        ("8m-3p  Haar-scramble",dict(n_modes=8, n_photons=3, q_depth=3, scramble=True)),
        ("10m-4p Haar-scramble",dict(n_modes=10,n_photons=4, q_depth=2, scramble=True)),
        ("12m-5p Haar-scramble",dict(n_modes=12,n_photons=5, q_depth=3, scramble=True)),
        ("15m-7p Haar-scramble",dict(n_modes=15,n_photons=7, q_depth=4, scramble=True)),
    ]
    results = []
    for label, cfg in variants:
        torch.manual_seed(42)
        m = BosonSamplingQPINN(**cfg)
        hdim = m.hilbert_dim
        mv, xv, nq = measure_gradient_variance(m, n_trials=80, n_pts=16)
        results.append((label, mv, xv, nq, hdim))
        print(f"  {label:30s}  dim_H={hdim:>7,d}  n_q={nq:4d}  "
              f"mean_Var={mv:.3e}  max_Var={xv:.3e}")

    labels  = [r[0] for r in results]
    mvars   = [r[1] for r in results]
    hdims   = [r[4] for r in results]
    colors  = ["#55A868","#4C72B0","#C44E52","#8172B2"]

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    bars = axes[0].bar(range(len(labels)), mvars, color=colors, alpha=0.85)
    axes[0].set_xticks(range(len(labels)))
    axes[0].set_xticklabels([l.replace(" ","\n") for l in labels], fontsize=8)
    axes[0].set_yscale("log"); axes[0].set_ylabel("Mean gradient variance (log)")
    axes[0].set_title("Gradient variance across circuit scales\n(identity init)")
    for bar, v in zip(bars, mvars):
        axes[0].text(bar.get_x()+bar.get_width()/2, v*1.5,
                     f"{v:.1e}", ha="center", va="bottom", fontsize=7)

    axes[1].plot(hdims, mvars, "o-", color="#4C72B0", lw=2, ms=9)
    for (label, mv, _, _, hdim) in results:
        axes[1].annotate(label.split()[0], (hdim, mv),
                         textcoords="offset points", xytext=(6,4), fontsize=8)
    axes[1].set_xscale("log"); axes[1].set_yscale("log")
    axes[1].set_xlabel("Hilbert dim H = C(m+n-1, n)")
    axes[1].set_ylabel("Mean gradient variance")
    axes[1].set_title("BP signature: Var[∇L] vs dim H\n"
                      "(identity init delays exponential decay)")
    plt.suptitle("Non-Gaussian QPINN: gradient health at boson-sampling scales", y=1.02)
    plt.tight_layout()
    out = os.path.join(RESULTS, "exp5_bs_grad_variance.png")
    plt.savefig(out, dpi=120); print(f"Saved: {out}")
    plt.show()

    return results


# ══════════════════════════════════════════════════════════════════════════════
# 7.  EXPERIMENT C — RMSE: scrambled vs unscrambled at scaled sizes
# ══════════════════════════════════════════════════════════════════════════════

def exp_c_rmse_comparison(seeds=(0, 1, 2)):
    if not MERLIN_AVAILABLE:
        print("Skipped (MerLin not available).")
        return
    print("\n" + "="*70)
    print("Experiment C: RMSE – scrambled vs unscrambled (heat equation)")
    print("="*70)

    cfgs = [
        ("5m-2p-no-scramble",  dict(n_modes=5, n_photons=2, q_depth=2, scramble=False)),
        ("5m-2p-Haar-scramble", dict(n_modes=5, n_photons=2, q_depth=2, scramble=True)),
        ("8m-3p-Haar-scramble", dict(n_modes=8, n_photons=3, q_depth=3, scramble=True)),
        ("12m-6p-Haar-scramble", dict(n_modes=12, n_photons=6, q_depth=3, scramble=True)),
        ("15m-8p-Haar-scramble", dict(n_modes=15, n_photons=8, q_depth=4, scramble=True)),
    ]
    all_results = {}
    for name, cfg in cfgs:
        rmses = []
        for seed in seeds:
            torch.manual_seed(seed)
            m = BosonSamplingQPINN(**cfg)
            elapsed = train(m, seed=seed)
            met = paper_metrics(m)
            rmses.append(met["rmse"])
            print(f"  {name} seed={seed}: RMSE={met['rmse']:.4e}  time={elapsed:.0f}s")
        all_results[name] = np.array(rmses)
        print(f"  → mean={np.mean(rmses):.4e}  std={np.std(rmses):.2e}")

    names = list(all_results.keys())
    means = [all_results[k].mean() for k in names]
    stds  = [all_results[k].std()  for k in names]
    colors = ["#55A868","#4C72B0","#C44E52"]

    fig, ax = plt.subplots(figsize=(8, 4))
    bars = ax.bar(range(len(names)), means, yerr=stds, capsize=6,
                  color=colors, alpha=0.85)
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels([n.replace("-","\n") for n in names], fontsize=8)
    ax.set_ylabel("RMSE (heat eq.)"); ax.set_title("RMSE comparison across circuit types")
    ax.yaxis.get_major_formatter().set_powerlimits((-4,-4))
    for bar, v in zip(bars, means):
        ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()*1.02,
                f"{v:.2e}", ha="center", va="bottom", fontsize=8)
    plt.tight_layout()
    out = os.path.join(RESULTS, "exp5_bs_rmse_comparison.png")
    plt.savefig(out, dpi=120); print(f"Saved: {out}")
    plt.show()

    json_out = os.path.join(RESULTS, "exp5_bs_results.json")
    with open(json_out, "w") as f:
        json.dump({k: v.tolist() for k, v in all_results.items()}, f, indent=2)
    print(f"Results saved: {json_out}")
    return all_results


# ══════════════════════════════════════════════════════════════════════════════
# 8.  MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Boson Sampling QPINN experiments")
    parser.add_argument("--exp", choices=["a","b","c","all"], default="a",
                        help="Which experiment to run (default: a = scaling table only)")
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    args = parser.parse_args()

    exp_a_scaling()

    if args.exp in ("b", "all"):
        exp_b_gradient_variance()

    if args.exp in ("c", "all"):
        exp_c_rmse_comparison(seeds=args.seeds)

    print("\nDone.")
