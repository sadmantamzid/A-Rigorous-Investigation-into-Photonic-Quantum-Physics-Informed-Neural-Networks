"""
exp6_sample_efficiency_regimes.py
----------------------------------
Identifies regimes where a hybrid quantum-classical (photonic QPINN) model is
more sample-efficient than a parameter-matched classical PINN.

Theory
------
Sample efficiency in PINNs is governed by the RKHS norm of the PDE solution
in the model's implicit kernel (Shin et al. 2020):

    n_f^* ∝ ||u||²_{H_K}

where K is the model's neural tangent kernel (NTK) at convergence.  A model
is more sample-efficient when its kernel aligns with the spectral content of u.

For photonic QPINNs (Schuld et al. 2021), the accessible frequency set is:

    |Ω|_baseline    = 2·n_photons + 1   (single encoding)
    |Ω|_reuploading = 2·L·n_photons + 1 (data reuploading, L layers)

Regime hypothesis
-----------------
┌──────────────────┬──────────┬─────────────────────────────────────────────┐
│  ω_PDE vs |Ω|    │ n_f      │ Expected winner                              │
├──────────────────┼──────────┼─────────────────────────────────────────────┤
│ ω < |Ω|_base     │ any      │ parity — both can represent u                │
│ |Ω|_base<ω<|Ω|_q │ low      │ hybrid WINS — frequency alignment only       │
│ |Ω|_base<ω<|Ω|_q │ high     │ classical catches up — enough data             │
│ ω > |Ω|_q        │ any      │ classical WINS — quantum can't represent u   │
└──────────────────┴──────────┴─────────────────────────────────────────────┘

Experiment design
-----------------
Three PDEs with different dominant frequencies on x ∈ [-π/2, π/2]:
  Low  (k=1): u₀(x) = sin(2x),  ω₀ = 2   → within |Ω|_base = 5
  Mid  (k=3): u₀(x) = sin(6x),  ω₀ = 6   → outside |Ω|_base, within |Ω|_reup = 9
  High (k=5): u₀(x) = sin(10x), ω₀ = 10  → outside both quantum models

Three models (parameter-matched):
  1. ClassicalPINN      — standard MLP + fixed Fourier features
  2. BaselineQPINN      — single-upload, no scramble
  3. HybridQPINN        — data-reuploading (L=2) + Haar scramblers

Measured over n_f ∈ {8, 16, 32, 64, 128} (2 seeds each, 3-seed option).

Additional analysis
-------------------
  - Kernel alignment score: ⟨K_model, yy'⟩ / (||K_model|| ||yy'||)
    (predicts sample efficiency without training)
  - Crossover n_f: smallest n_f where hybrid RMSE < classical RMSE
  - Regime diagram: advantage ratio as function of (ω_PDE, n_f)
"""

import math, time, json, os, sys
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from math import comb
from scipy.integrate import solve_ivp
from scipy.stats import qmc

# ── MerLin import (perceval first to avoid openblas init race) ────────────────
try:
    import perceval as _pcvl  # noqa: F401
    import merlin as ML
    from merlin.core.components import BeamSplitter, Rotation, ParameterRole
    MERLIN_AVAILABLE = bool(hasattr(ML, "CircuitBuilder"))
    print(f"MerLin {getattr(ML,'__version__','?')}  CircuitBuilder={MERLIN_AVAILABLE}")
except (ImportError, Exception) as _e:
    MERLIN_AVAILABLE = False
    print(f"MerLin not available ({_e})")

dtype  = torch.float32
torch.set_default_dtype(torch.float32)
torch.manual_seed(0); np.random.seed(0)

_here = os.path.abspath(os.path.dirname(__file__))
for _c in [os.path.join(_here, "..", "results"), "/cluster/home/lazhang/qpinn/results"]:
    if os.path.isdir(_c):
        RESULTS = os.path.abspath(_c); break
print(f"Results dir: {RESULTS}")

# ══════════════════════════════════════════════════════════════════════════════
# 1.  PDE FAMILY — heat equation with sinusoidal ICs at different frequencies
# ══════════════════════════════════════════════════════════════════════════════
alpha_d  = 0.30
x_min, x_max = -math.pi/2, math.pi/2
t_min, t_max = 0.0, 0.5

# PDE variants: (label, k, dominant_omega)
# u₀(x) = sin(k * 2 * x) so that ω₀ = 2k (spatial rad/unit on [-π/2, π/2])
PDE_VARIANTS = [
    ("low-freq  (ω=2, k=1)",  1,  2.0),   # within |Ω|_base = 5
    ("mid-freq  (ω=6, k=3)",  3,  6.0),   # inside |Ω|_reup = 9, outside |Ω|_base
    ("high-freq (ω=10, k=5)", 5, 10.0),   # outside both quantum models
]
# |Ω| bounds for quick reference (n_photons=2, q_depth=2)
OMEGA_BASE  = 5   # 2*n_photons + 1
OMEGA_REUP  = 9   # 2*q_depth*n_photons + 1


def make_ic(k: int):
    """Return (IC_numpy_fn, IC_torch_fn) for u₀(x) = sin(2k x)."""
    def ic_np(x): return np.sin(2 * k * x)
    def ic_torch(x): return torch.sin(2 * k * x)
    return ic_np, ic_torch


def build_reference(k: int, nx=257, nt=101):
    """RK45 reference solution for u₀(x) = sin(2k x)."""
    ic_np, _ = make_ic(k)
    rx = np.linspace(x_min, x_max, nx)
    rt = np.linspace(t_min, t_max, nt)
    dx = rx[1] - rx[0]
    u0 = ic_np(rx); u0[0] = u0[-1] = 0.0
    def rhs(_t, u):
        d2 = np.zeros_like(u)
        d2[1:-1] = (u[2:] - 2*u[1:-1] + u[:-2]) / dx**2
        return alpha_d * d2
    sol = solve_ivp(rhs, (0, t_max), u0, t_eval=rt,
                    method="RK45", rtol=1e-8, atol=1e-10, max_step=1e-3)
    T_ref = sol.y  # (nx, nt)

    def interp(x_np, t_np):
        ix = np.clip((x_np - rx[0]) / dx, 0, nx-2).astype(int)
        dt = rt[1] - rt[0]
        it = np.clip((t_np - rt[0]) / dt, 0, nt-2).astype(int)
        fx = (x_np - rx[0]) / dx - ix
        ft = (t_np - rt[0]) / dt  - it
        return ((1-fx)*(1-ft)*T_ref[ix,it] + fx*(1-ft)*T_ref[ix+1,it]
              + (1-fx)*ft*T_ref[ix,it+1]  + fx*ft*T_ref[ix+1,it+1])
    return interp, rx, rt


_sobol = qmc.Sobol(d=2, scramble=True, seed=0)
def _reset_sobol(s):
    global _sobol; _sobol = qmc.Sobol(d=2, scramble=True, seed=int(s))
def sobol_xt(n):
    p = _sobol.random(n)
    x = x_min + (x_max-x_min)*p[:,0:1]
    t = t_min + (t_max-t_min)*p[:,1:2]
    return torch.tensor(np.concatenate([x,t],1), dtype=dtype)
def sobol_x_only(n):
    return torch.tensor(
        x_min + (x_max-x_min)*_sobol.random(n)[:,0:1], dtype=dtype)

def paper_metrics(pred_fn, ref_interp, nx=80, nt=80):
    xs = np.linspace(x_min, x_max, nx); ts = np.linspace(t_min, t_max, nt)
    X, T = np.meshgrid(xs, ts, indexing="ij")
    xt_np = np.stack([X.ravel(), T.ravel()], 1)
    xt    = torch.tensor(xt_np, dtype=dtype)
    with torch.no_grad():
        Tp = pred_fn(xt).detach().cpu().numpy().reshape(nx, nt)
    Tt = ref_interp(xt_np[:,0], xt_np[:,1]).reshape(nx, nt)
    e  = Tp - Tt
    return dict(rmse=float(np.sqrt(np.mean(e**2))),
                nmse=float(np.sum(e**2)/np.sum(Tt**2)))

def _hard_bc(x, q_u): return torch.cos(x) * q_u
def _grad(y, x):
    return torch.autograd.grad(y, x, grad_outputs=torch.ones_like(y),
                               create_graph=True, retain_graph=True)[0]
def pde_residual(model, xt):
    T    = model(xt)
    gT   = _grad(T, xt)
    T_xx = _grad(gT[:,0:1], xt)[:,0:1]
    return gT[:,1:2] - alpha_d * T_xx

_FD_EPS = 1e-3
def pde_residual_fd(model, xt):
    """Finite-difference PDE residual. 5× forward passes, no 2nd-order autograd.
    Gradients flow through each forward pass back to model parameters.
    O(n) cost through quantum circuit vs O(n²) for autograd."""
    u     = model(xt)
    xt_xp = xt.detach().clone(); xt_xp[:, 0] = xt[:, 0].detach() + _FD_EPS
    xt_xm = xt.detach().clone(); xt_xm[:, 0] = xt[:, 0].detach() - _FD_EPS
    xt_tp = xt.detach().clone(); xt_tp[:, 1] = xt[:, 1].detach() + _FD_EPS
    xt_tm = xt.detach().clone(); xt_tm[:, 1] = xt[:, 1].detach() - _FD_EPS
    u_xx = (model(xt_xp) - 2*u + model(xt_xm)) / _FD_EPS**2
    u_t  = (model(xt_tp) - model(xt_tm))        / (2*_FD_EPS)
    return u_t - alpha_d * u_xx

def n_params(m): return sum(p.numel() for p in m.parameters() if p.requires_grad)


# ══════════════════════════════════════════════════════════════════════════════
# 2.  MODEL LIBRARY
# ══════════════════════════════════════════════════════════════════════════════

class FourierFeatures(nn.Module):
    """Fixed random Fourier features."""
    def __init__(self, in_dim=2, num_freqs=8, sigma=2.0, seed=0, trainable=False):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        B = torch.randn(in_dim, num_freqs, generator=g) * sigma
        if trainable:
            self.B = nn.Parameter(B)
        else:
            self.register_buffer("B", B)
    def forward(self, x):
        z = x @ self.B * (2 * math.pi)
        return torch.cat([torch.sin(z), torch.cos(z)], -1)


class ClassicalPINN(nn.Module):
    """
    Matched classical baseline: same trainable Fourier preprocessing as
    QuantumPINN, but quantum layer replaced by a parameter-matched MLP.

    Architecture mirrors QuantumPINN:
      trainable FF (2→2*num_freqs) → proj (→feature_size) → MLP → readout
    """
    def __init__(self, num_freqs=8, feature_size=4, q_depth=2, hidden=24):
        super().__init__()
        self.ff      = FourierFeatures(2, num_freqs, sigma=2.0, trainable=True)
        self.proj    = nn.Linear(2*num_freqs, feature_size)
        # MLP replaces quantum layer: same input dim (feature_size*q_depth) and output (hidden)
        self.mlp     = nn.Sequential(
            nn.Linear(feature_size * q_depth, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden),                 nn.Tanh(),
        )
        self.readout = nn.Sequential(nn.Linear(hidden, hidden), nn.Tanh(), nn.Linear(hidden, 1))
        self.q_depth = q_depth

    def forward(self, xt):
        z = torch.tanh(self.proj(self.ff(xt))).repeat(1, self.q_depth)
        return _hard_bc(xt[:,0:1], self.readout(self.mlp(z)))


def _add_haar_scrambler(builder, n_modes, seed):
    rng = np.random.default_rng(int(seed))
    for col in range(n_modes - 1):
        start = col % 2
        for row in range(start, n_modes - 1, 2):
            builder.circuit.add(BeamSplitter(
                targets=(row, row+1),
                theta_role=ParameterRole.FIXED,
                theta_value=float(rng.uniform(0, math.pi)),
                phi_role=ParameterRole.FIXED,
                phi_value=float(rng.uniform(0, 2*math.pi)),
            ))
    for m in range(n_modes):
        builder.circuit.add(Rotation(
            target=m, role=ParameterRole.FIXED,
            value=float(rng.uniform(0, 2*math.pi)), axis="z",
        ))


def _spaced_fock(n_modes, n_photons):
    occ = sorted(set(np.linspace(0, n_modes-1, n_photons, dtype=int).tolist()))
    s = [0]*n_modes
    for m in occ: s[m] = 1
    return s


def make_quantum_layer(n_modes, n_photons, feature_size, q_depth,
                       scramble=False):
    if not MERLIN_AVAILABLE:
        return None
    builder = ML.CircuitBuilder(n_modes=n_modes)
    for d in range(q_depth):
        builder.add_angle_encoding(
            modes=list(range(feature_size)),
            name=f"enc_{d}", subset_combinations=False)
        builder.add_entangling_layer(trainable=True, name=f"ent_{d}")
        if scramble:
            _add_haar_scrambler(builder, n_modes, seed=d*997 + n_modes*31)
    return ML.QuantumLayer(
        input_size=feature_size * q_depth,
        input_state=_spaced_fock(n_modes, n_photons),
        n_photons=n_photons, builder=builder,
        measurement_strategy=ML.MeasurementStrategy.PROBABILITIES,
        computation_space=ML.ComputationSpace.UNBUNCHED,
    )


class QuantumPINN(nn.Module):
    """
    Hybrid photonic QPINN.

    scramble=False → baseline single-upload (|Ω| = 2*n_photons+1 = 5)
    scramble=True  → data-reuploading + Haar layers (|Ω| = 2*q_depth*n_photons+1 = 9)
    """
    def __init__(self, n_modes=5, n_photons=2, q_depth=2,
                 feature_size=4, num_freqs=8, hidden=24,
                 scramble=False):
        super().__init__()
        self.q_depth      = q_depth
        self.n_photons    = n_photons
        self.feature_size = feature_size
        self.scramble     = scramble
        self.omega_bound  = (2*n_photons+1) if not scramble else (2*q_depth*n_photons+1)

        self.ff   = FourierFeatures(2, num_freqs, sigma=2.0, trainable=True)
        self.proj = nn.Linear(2*num_freqs, feature_size)

        self.quantum = make_quantum_layer(n_modes, n_photons, feature_size,
                                          q_depth, scramble=scramble)
        if self.quantum is not None:
            with torch.no_grad():
                for p in self.quantum.parameters(): p.fill_(0.0)
            q_out = self.quantum.output_size
        else:
            q_out = feature_size
            self.quantum = nn.Sequential(
                nn.Linear(feature_size*q_depth, hidden), nn.Tanh(),
                nn.Linear(hidden, q_out))

        self.readout = nn.Sequential(
            nn.Linear(q_out, hidden), nn.Tanh(), nn.Linear(hidden, 1))

    def forward(self, xt):
        x   = xt[:,0:1]
        z   = torch.tanh(self.proj(self.ff(xt)))
        z   = z.repeat(1, self.q_depth)
        return _hard_bc(x, self.readout(self.quantum(z)))


# ══════════════════════════════════════════════════════════════════════════════
# 3.  TRAINING  —  IC-SUPERVISED MODE (fast, gradient through 1 forward pass)
#
# Rationale: quantum backward through 2nd-order PDE residual is O(n²) and
# ~200× slower than forward.  For sample-efficiency comparisons we instead
# train each model to fit n_ic supervised IC samples (t=0) and evaluate
# generalisation error on the full (x,t) grid.  This is the minimal task
# that reveals the model's implicit kernel bias without any 2nd derivatives.
#
# Optional PINN mode (--pinn-mode): adds FD-based PDE collocation loss on top
# of the IC loss.  FD still costs 5× forward per step, so it is 5× slower
# than IC-only but correctly converges to the PDE solution.
# ══════════════════════════════════════════════════════════════════════════════

def train(model, ic_torch, ref_interp, *, n_ic, epochs=500,
          lr=3e-3, lbfgs_steps=30, seed=0, pinn_mode=False, n_pde=32):
    """Train model on n_ic supervised IC samples (t=0).

    pinn_mode=True adds FD-based PDE collocation loss (5× forward passes per
    step, but no 2nd-order backprop — safe with quantum circuits).
    """
    _reset_sobol(seed)
    mse  = nn.MSELoss()
    # weight_decay prevents trainable FF from blowing up at very low n_ic
    opt  = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)

    for ep in range(epochs):
        opt.zero_grad()
        # IC supervised loss
        x_ic  = sobol_x_only(n_ic)
        xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], 1)
        li = mse(model(xt_ic), ic_torch(x_ic))
        loss = li
        # Optional PDE collocation via FD (no 2nd-order backprop)
        if pinn_mode:
            xt_f = sobol_xt(n_pde)
            lp   = mse(pde_residual_fd(model, xt_f), torch.zeros(n_pde, 1))
            loss = loss + lp
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

    if lbfgs_steps:
        opt2 = torch.optim.LBFGS(model.parameters(), lr=0.5, max_iter=lbfgs_steps)
        def _cl():
            opt2.zero_grad()
            x_ic  = sobol_x_only(n_ic)
            xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], 1)
            l = mse(model(xt_ic), ic_torch(x_ic)); l.backward()
            return l
        opt2.step(_cl)


# ══════════════════════════════════════════════════════════════════════════════
# 4.  KERNEL ALIGNMENT ANALYSIS  (no training required)
# ══════════════════════════════════════════════════════════════════════════════

def empirical_kernel(model, n_pts=64, t_fixed=0.25):
    """K(i,j) = φ(xᵢ)ᵀ φ(xⱼ) using the penultimate layer activations."""
    xs  = np.linspace(x_min, x_max, n_pts)
    xt  = torch.tensor(
        np.stack([xs, np.full(n_pts, t_fixed)], axis=1), dtype=dtype)
    # Hook the penultimate readout activation as the feature map
    feats = {}
    def _hook(mod, inp, out): feats["z"] = out.detach()
    # Register on the layer before the last linear
    hook_layer = model.readout[0] if hasattr(model, "readout") else model.net[0]
    h = hook_layer.register_forward_hook(_hook)
    with torch.no_grad(): model(xt)
    h.remove()
    phi = feats["z"].numpy()          # (n_pts, d)
    K   = phi @ phi.T                 # (n_pts, n_pts)
    return K / (np.linalg.norm(K, "fro") + 1e-12)


def target_kernel(k_pde, ref_interp, n_pts=64, t_fixed=0.25):
    """Target kernel: yᵢyⱼ at t=t_fixed, normalised."""
    xs = np.linspace(x_min, x_max, n_pts)
    ts = np.full(n_pts, t_fixed)
    y  = ref_interp(xs, ts)
    K  = np.outer(y, y)
    return K / (np.linalg.norm(K, "fro") + 1e-12)


def kernel_alignment(K_model, K_target):
    """Frobenius inner product alignment ∈ [-1, 1]."""
    return float(np.sum(K_model * K_target))


# ══════════════════════════════════════════════════════════════════════════════
# 5.  MAIN EXPERIMENTS
# ══════════════════════════════════════════════════════════════════════════════

def exp_kernel_alignment():
    """
    Compute kernel alignment for each (model type, PDE variant) pair.
    No training needed — uses randomly initialised models.
    Predicts which regime favours the hybrid model.
    """
    print("\n" + "="*68)
    print("Kernel Alignment Analysis  (predicts sample efficiency regime)")
    print("="*68)

    model_cfgs = [
        ("Classical",        lambda: ClassicalPINN(hidden=64)),
        ("Baseline QPINN",   lambda: QuantumPINN(scramble=False) if MERLIN_AVAILABLE
                                     else ClassicalPINN(hidden=32)),
        ("Hybrid QPINN",     lambda: QuantumPINN(scramble=True)  if MERLIN_AVAILABLE
                                     else ClassicalPINN(hidden=48)),
    ]

    align_table = {}
    for pde_label, k, omega in PDE_VARIANTS:
        ref_interp, _, _ = build_reference(k)
        K_tgt = target_kernel(k, ref_interp)
        row = {}
        for m_label, m_fn in model_cfgs:
            torch.manual_seed(0)
            m = m_fn()
            K_m = empirical_kernel(m)
            row[m_label] = kernel_alignment(K_m, K_tgt)
        align_table[pde_label] = row

    hdr = f"{'PDE':32s}  {'Classical':>12s}  {'Baseline Q':>12s}  {'Hybrid Q':>12s}"
    print(hdr); print("─"*len(hdr))
    for pde_label, row in align_table.items():
        vals = [row[k] for k in ["Classical","Baseline QPINN","Hybrid QPINN"]]
        best = max(range(3), key=lambda i: vals[i])
        strs = [f"{v:>12.4f}" for v in vals]
        strs[best] += " ★"
        print(f"{pde_label:32s}  {'  '.join(strs)}")
    print("\nHigher alignment → better sample efficiency predicted for that model.")
    print("★ marks the expected most sample-efficient model per PDE frequency.")
    return align_table


def exp_sample_efficiency_sweep(nf_levels=(8, 16, 32, 64, 128), seeds=(0, 1),
                                epochs=500, lbfgs_steps=30, pinn_mode=False):
    """
    Sample-efficiency sweep: models are trained on n_ic supervised IC samples
    (t=0) and evaluated on the full (x,t) grid.  This is the IC-supervised
    regime that directly tests kernel alignment without 2nd-order autodiff.

    pinn_mode=True additionally adds FD-based PDE collocation (5× forward/step
    but no 2nd-order backprop).
    """
    if not MERLIN_AVAILABLE:
        print("MerLin unavailable — quantum models replaced by size-matched MLPs.")

    mode_str = "PINN (IC + FD-PDE)" if pinn_mode else "IC-supervised"
    print("\n" + "="*68)
    print(f"Sample-Efficiency Sweep  [{mode_str}]")
    print(f"  n_ic={list(nf_levels)}, seeds={list(seeds)}, epochs={epochs}")
    print("="*68)

    MODEL_CFGS = [
        ("Classical",    lambda: ClassicalPINN(hidden=64)),
        ("Baseline-Q",   lambda: QuantumPINN(scramble=False)),
        ("Hybrid-Q",     lambda: QuantumPINN(scramble=True)),
    ]

    results = {}   # results[pde_label][model_label][n_ic] = [rmse, ...]

    for pde_label, k, omega in PDE_VARIANTS:
        _, ic_torch = make_ic(k)
        ref_interp, _, _ = build_reference(k)
        results[pde_label] = {m: {nf: [] for nf in nf_levels}
                               for m, _ in MODEL_CFGS}

        for nf in nf_levels:
            for m_label, m_fn in MODEL_CFGS:
                for seed in seeds:
                    torch.manual_seed(seed); np.random.seed(seed)
                    m = m_fn()
                    t0 = time.perf_counter()
                    train(m, ic_torch, ref_interp, n_ic=nf, seed=seed,
                          epochs=epochs, lbfgs_steps=lbfgs_steps,
                          pinn_mode=pinn_mode)
                    elapsed = time.perf_counter() - t0
                    met = paper_metrics(m, ref_interp)
                    results[pde_label][m_label][nf].append(met["rmse"])
                    print(f"  {pde_label[:20]:20s} | {m_label:12s} | "
                          f"n_ic={nf:3d} s={seed}: "
                          f"RMSE={met['rmse']:.3e}  t={elapsed:.0f}s")

    # ── Compute crossover and advantage ratio ─────────────────────────────────
    print("\n" + "="*72)
    print("Regime Summary: Classical RMSE / Best-Quantum RMSE  (>1 = quantum wins)")
    print("="*72)
    regime_data = {}
    for pde_label, k, omega in PDE_VARIANTS:
        print(f"\n  PDE: {pde_label}  |  ω₀={omega:.0f}  "
              f"|Ω|_base={OMEGA_BASE}  |Ω|_reup={OMEGA_REUP}")
        print(f"  {'n_ic':>5s}  {'Classic RMSE':>14s}  "
              f"{'Baseline-Q':>12s}  {'Hybrid-Q':>12s}  "
              f"{'Best-Q/Class':>14s}  Regime")
        row = {}
        for nf in nf_levels:
            rc  = np.mean(results[pde_label]["Classical"][nf])
            rb  = np.mean(results[pde_label]["Baseline-Q"][nf])
            rh  = np.mean(results[pde_label]["Hybrid-Q"][nf])
            rq  = min(rb, rh)        # best quantum model
            best_q_label = "Base-Q" if rb <= rh else "Hybr-Q"
            ratio = rc / max(rq, 1e-12)
            regime = ("★ quantum wins" if ratio > 1.05
                      else ("≈ parity"    if ratio > 0.95 else "  classic wins"))
            row[nf] = dict(rmse_classical=rc, rmse_baseline=rb, rmse_hybrid=rh,
                           rmse_best_quantum=rq, best_q_label=best_q_label,
                           ratio=ratio, regime=regime)
            print(f"  {nf:>5d}  {rc:>14.4e}  "
                  f"{rb:>12.4e}  {rh:>12.4e}  "
                  f"{ratio:>14.3f}[{best_q_label}]  {regime}")
        regime_data[pde_label] = row

    # ── Save JSON ─────────────────────────────────────────────────────────────
    out_json = os.path.join(RESULTS, "exp6_sample_efficiency_regimes.json")
    serialisable = {
        pdl: {ml: {str(nf): v for nf, v in nf_dict.items()}
              for ml, nf_dict in model_dict.items()}
        for pdl, model_dict in results.items()
    }
    with open(out_json, "w") as f:
        json.dump(serialisable, f, indent=2)
    print(f"\nRaw results saved: {out_json}")

    return results, regime_data


def plot_regime_results(results, regime_data, align_table=None):
    """Four-panel figure: RMSE curves + regime diagram + kernel alignment."""
    nf_levels = sorted(next(iter(next(iter(results.values())).values())).keys())
    n_pde     = len(PDE_VARIANTS)
    colors    = {"Classical": "#555555", "Baseline-Q": "#C44E52", "Hybrid-Q": "#4C72B0"}
    markers   = {"Classical": "s", "Baseline-Q": "^", "Hybrid-Q": "o"}

    fig = plt.figure(figsize=(16, 10))
    gs  = fig.add_gridspec(2, n_pde+1, wspace=0.35, hspace=0.45)

    # ── Top row: RMSE curves ──────────────────────────────────────────────────
    for col, (pde_label, k, omega) in enumerate(PDE_VARIANTS):
        ax = fig.add_subplot(gs[0, col])
        for m_label in ["Classical", "Baseline-Q", "Hybrid-Q"]:
            nf_arr = np.array(nf_levels)
            mu     = np.array([np.mean(results[pde_label][m_label][nf]) for nf in nf_levels])
            se     = np.array([np.std(results[pde_label][m_label][nf])  for nf in nf_levels])
            ax.errorbar(nf_arr, mu, yerr=se, fmt=f"{markers[m_label]}-",
                        color=colors[m_label], capsize=4, lw=1.8, ms=6,
                        label=m_label)
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("n_f (collocation pts)"); ax.set_ylabel("RMSE")
        omega_str = f"ω₀={omega:.0f}"
        inside = "in |Ω|" if omega < OMEGA_BASE else ("in |Ω|_reup" if omega < OMEGA_REUP else "outside both")
        ax.set_title(f"{pde_label.split('(')[0].strip()}\n"
                     f"{omega_str} — {inside}")
        ax.legend(fontsize=7)

    # ── Bottom row: advantage ratio (Hybrid/Classical) ────────────────────────
    for col, (pde_label, k, omega) in enumerate(PDE_VARIANTS):
        ax = fig.add_subplot(gs[1, col])
        nf_arr = np.array(nf_levels)
        ratios = [regime_data[pde_label][nf]["ratio"] for nf in nf_levels]
        clrs   = ["#4C72B0" if r > 1.05 else ("#aaaaaa" if r > 0.95 else "#C44E52")
                  for r in ratios]
        bars = ax.bar(range(len(nf_levels)), ratios, color=clrs, alpha=0.85)
        ax.axhline(1.0, ls="--", color="gray", lw=1.2)
        ax.axhline(1.05, ls=":", color="#4C72B0", lw=0.8)
        ax.set_xticks(range(len(nf_levels)))
        ax.set_xticklabels([str(nf) for nf in nf_levels], fontsize=8)
        ax.set_xlabel("n_f"); ax.set_ylabel("Classical RMSE / Hybrid RMSE")
        ax.set_title(f"Advantage ratio\n(>1 = hybrid wins)")
        for bar, r in zip(bars, ratios):
            ax.text(bar.get_x()+bar.get_width()/2, r+0.01,
                    f"{r:.2f}", ha="center", va="bottom", fontsize=7)

    # ── Right column: regime diagram (kernel alignment heat-map) ─────────────
    if align_table is not None:
        ax_km = fig.add_subplot(gs[:, n_pde])
        pde_labels  = [p[0].split("(")[0].strip() for p in PDE_VARIANTS]
        model_lbls  = ["Classical", "Baseline-Q", "Hybrid-Q"]
        Z = np.array([[align_table[p[0]][ml] for ml in
                       ["Classical", "Baseline QPINN", "Hybrid QPINN"]]
                      for p in PDE_VARIANTS])
        im = ax_km.imshow(Z, cmap="RdYlGn", vmin=-0.2, vmax=0.8, aspect="auto")
        plt.colorbar(im, ax=ax_km, label="Kernel alignment score")
        ax_km.set_xticks([0,1,2]); ax_km.set_xticklabels(model_lbls, rotation=30, fontsize=8)
        ax_km.set_yticks(range(len(pde_labels)))
        ax_km.set_yticklabels(pde_labels, fontsize=8)
        ax_km.set_title("Kernel alignment\n(higher → more sample-\nefficient predicted)")
        for i in range(len(PDE_VARIANTS)):
            for j in range(3):
                ax_km.text(j, i, f"{Z[i,j]:.2f}", ha="center", va="center",
                           fontsize=9, color="black")

    plt.suptitle(
        "Sample Efficiency Regime Analysis — Hybrid QPINN vs Classical PINN\n"
        f"|Ω|_base={OMEGA_BASE} (n_p=2),  |Ω|_reup={OMEGA_REUP} (L=2·n_p=4)",
        fontsize=11, y=1.01)
    plt.savefig(os.path.join(RESULTS, "exp6_regime_diagram.png"),
                dpi=120, bbox_inches="tight")
    print(f"Saved: {os.path.join(RESULTS, 'exp6_regime_diagram.png')}")
    plt.show()


def print_regime_table(regime_data):
    """Print a concise regime identification table."""
    print("\n" + "="*78)
    print("REGIME IDENTIFICATION TABLE")
    print("="*78)
    print(f"{'PDE':12s} {'ω₀':>5s} {'ω in |Ω|?':>12s} | "
          f"{'n_ic=8':>8s} {'n_ic=32':>8s} {'n_ic=128':>8s} | Best regime")
    print("─"*78)
    for pde_label, k, omega in PDE_VARIANTS:
        if omega < OMEGA_BASE:
            in_omega = "base+reup"
        elif omega < OMEGA_REUP:
            in_omega = "reup only"
        else:
            in_omega = "neither"

        row = regime_data[pde_label]
        nf_keys = sorted(row.keys())

        # Find smallest n_ic where quantum wins (ratio > 1.05)
        crossover = next((nf for nf in nf_keys if row[nf]["ratio"] > 1.05), None)

        r8   = row[nf_keys[0]]["ratio"]  if nf_keys[0] <= 8   else "-"
        r32  = row[32]["ratio"]          if 32  in row else "-"
        r128 = row[128]["ratio"]         if 128 in row else "-"

        if crossover:
            bq = row[crossover]["best_q_label"]
            best = f"★ {bq} wins at n_ic≤{crossover}"
        elif all(row[nf]["ratio"] < 0.95 for nf in nf_keys):
            best = "  classical dominates"
        else:
            best = "≈ parity"

        r8s   = f"{r8:.2f}"   if isinstance(r8,   float) else r8
        r32s  = f"{r32:.2f}"  if isinstance(r32,  float) else r32
        r128s = f"{r128:.2f}" if isinstance(r128, float) else r128

        short = pde_label.split("(")[0].strip()[:10]
        print(f"{short:12s} {omega:>5.0f} {in_omega:>12s} | "
              f"{r8s:>8s} {r32s:>8s} {r128s:>8s} | {best}")

    print("\nRatio = Classical RMSE / Best-Quantum RMSE. >1.05 = quantum more sample-efficient.")
    print(f"|Ω|_base = {OMEGA_BASE}  (baseline, no scramble, n_photons=2)")
    print(f"|Ω|_reup = {OMEGA_REUP}  (data reuploading, q_depth=2, n_photons=2)")


# ══════════════════════════════════════════════════════════════════════════════
# 6.  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(
        description="Sample efficiency regime analysis — "
                    "IC-supervised training, sweep over n_ic samples")
    p.add_argument("--nf",         type=int, nargs="+", default=[8, 16, 32, 64, 128],
                   help="Number of IC training samples to sweep")
    p.add_argument("--seeds",      type=int, nargs="+", default=[0, 1])
    p.add_argument("--epochs",     type=int, default=500,
                   help="Adam epochs per run (default 500)")
    p.add_argument("--lbfgs",      type=int, default=30,
                   help="L-BFGS steps (default 30, 0 to disable)")
    p.add_argument("--pinn-mode",  action="store_true",
                   help="Add FD-based PDE collocation loss on top of IC loss "
                        "(5× slower per step, but trains toward PDE solution)")
    p.add_argument("--skip-sweep", action="store_true",
                   help="Only run kernel alignment analysis (fast, no training)")
    args = p.parse_args()

    align_table = exp_kernel_alignment()

    if not args.skip_sweep:
        results, regime_data = exp_sample_efficiency_sweep(
            nf_levels=args.nf, seeds=args.seeds,
            epochs=args.epochs, lbfgs_steps=args.lbfgs,
            pinn_mode=args.pinn_mode)
        plot_regime_results(results, regime_data, align_table)
        print_regime_table(regime_data)
    else:
        print("\n(Skipped training sweep — pass without --skip-sweep to run full analysis)")
