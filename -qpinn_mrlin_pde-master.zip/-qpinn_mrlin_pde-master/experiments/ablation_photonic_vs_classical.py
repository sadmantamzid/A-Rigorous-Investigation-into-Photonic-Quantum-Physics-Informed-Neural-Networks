"""
Ablation: is the photonic layer in MerLin_QPINN_Plus actually load-bearing?

Build ClassicalPlus = MerlinQPINN_Plus with `ML.QuantumLayer.simple(4,4)` (40 params)
swapped for `Linear(4,4) -> Tanh -> Linear(4,4)` (also 40 params). Everything else is
identical: same Fourier features, same input projection, same skip-concat readout,
same nested-autodiff residual, same Adam schedule, same LBFGS finetune, same seeds.

If the photonic block provides genuine advantage on this PDE, ClassicalPlus must be
measurably worse than MerlinQPINN_Plus. If they tie, the win in the headline benchmark
is from Fourier features + LBFGS + skip readout — not from quantum.

Headline metric: RMSE (mean +/- std over 3 seeds).
"""

import math, time, json
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

# Re-use everything from the main benchmark script.
from benchmark_qpinn_vs_pinn import (
    DTYPE, DEVICE, SEEDS, PRETRAIN, EPOCHS, LBFGS_STEPS, LR_ADAM, ALPHA_D,
    X_MIN, X_MAX, T_MIN, T_MAX,
    FourierFeatures, MerlinQPINN_Plus,
    train, paper_metrics, n_trainable, _hard_bc, _pred_nested,
)


class ClassicalPlus(nn.Module):
    """Identical to MerlinQPINN_Plus, but the photonic block is replaced by a 40-param
    classical MLP `Linear(qin, qmid) -> Tanh -> Linear(qmid, qos)`."""
    def __init__(self, num_freqs=6, sigma=2.0, qin=4, qmid=4, qos=4, hidden=16, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.proj_in = nn.Linear(ff_dim, qin)
        # Photonic-shaped classical block: 4 -> 4 -> 4. Param count: 5*qmid + 4*qmid + 4 = 9*qmid + 4
        # qmid=4 => 40 params, matching ML.QuantumLayer.simple(4,4) exactly.
        self.middle = nn.Sequential(
            nn.Linear(qin, qmid), nn.Tanh(),
            nn.Linear(qmid, qos),
        )
        self.readout = nn.Sequential(
            nn.Linear(qos + 2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.ff(xt)
        z = self.proj_in(z)
        m = self.middle(z)
        h = torch.cat([m, xt], dim=-1)
        return _hard_bc(x, self.readout(h))


# --- Frozen-random photonic ablation: keep the photonic layer but freeze its weights
#     at random init. Tests whether the photonic block contributes via *trained*
#     dynamics or merely as a fixed random nonlinear feature map.
class MerlinQPINN_PlusFrozenQ(MerlinQPINN_Plus):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        for p in self.quantum.parameters():
            p.requires_grad = False


def main():
    print(f"torch {torch.__version__} | device {DEVICE}")
    # --- Verify parameter counts match ---
    plus = MerlinQPINN_Plus()
    cls = ClassicalPlus()
    plus_q = sum(p.numel() for p in plus.quantum.parameters())
    cls_m = sum(p.numel() for p in cls.middle.parameters())
    print(f"MerLin photonic block params : {plus_q}")
    print(f"Classical drop-in block params: {cls_m}")
    print(f"MerLin total params          : {n_trainable(plus)}")
    print(f"Classical total params        : {n_trainable(cls)}")
    assert plus_q == cls_m, "middle blocks must have identical param count"
    assert n_trainable(plus) == n_trainable(cls), "totals must match"

    frozen = MerlinQPINN_PlusFrozenQ()
    frozen_total = n_trainable(frozen)
    print(f"MerLin (photonic frozen) trainable params: {frozen_total}")

    VARIANTS = [
        ("MerLin_QPINN_Plus",     "nested", lambda: MerlinQPINN_Plus(),         LBFGS_STEPS),
        ("Classical_Plus",        "nested", lambda: ClassicalPlus(),            LBFGS_STEPS),
        ("MerLin_FrozenPhotonic", "nested", lambda: MerlinQPINN_PlusFrozenQ(),  LBFGS_STEPS),
    ]

    results = {n: [] for n, *_ in VARIANTS}
    fields  = {n: None for n, *_ in VARIANTS}

    print("\n" + "=" * 80)
    for seed in SEEDS:
        print(f"\n=== seed {seed} ===")
        for name, kind, build, lbfgs in VARIANTS:
            torch.manual_seed(seed); np.random.seed(seed)
            m = build().to(DEVICE)
            for p in m.parameters():
                if p.is_floating_point():
                    p.data = p.data.to(DTYPE)
            _, dt = train(m, kind, seed=seed, lbfgs_steps=lbfgs)
            metrics, T_pred, T_true = paper_metrics(_pred_nested(m))
            metrics["train_time_s"] = dt
            results[name].append(metrics)
            fields[name] = (T_pred, T_true)
            print(f"  {name:25s} | RMSE={metrics['rmse']:.3e} NMSE={metrics['nmse']:.3e} time={dt:5.1f}s")

    print("\n" + "=" * 80)
    print(f"{'variant':28s} {'RMSE mean':>11s} {'RMSE std':>11s} {'NMSE mean':>11s} {'time(s)':>8s}")
    print("-" * 80)
    summary = {}
    for name, *_ in VARIANTS:
        rs = np.array([r["rmse"] for r in results[name]])
        ns = np.array([r["nmse"] for r in results[name]])
        tt = np.array([r["train_time_s"] for r in results[name]])
        summary[name] = dict(
            rmse_mean=float(rs.mean()), rmse_std=float(rs.std()),
            nmse_mean=float(ns.mean()),
            time_mean=float(tt.mean()),
            per_seed=results[name],
        )
        print(f"{name:28s} {rs.mean():>11.3e} {rs.std():>11.3e} {ns.mean():>11.3e} {tt.mean():>8.2f}")
    print("=" * 80)

    # --- delta and statistical interpretation ---
    plus_rs = np.array([r["rmse"] for r in results["MerLin_QPINN_Plus"]])
    cls_rs  = np.array([r["rmse"] for r in results["Classical_Plus"]])
    fz_rs   = np.array([r["rmse"] for r in results["MerLin_FrozenPhotonic"]])
    delta = cls_rs - plus_rs    # >0 means Plus better
    print(f"\nPaired RMSE delta (Classical_Plus - MerLin_Plus) per seed: {delta}")
    print(f"  mean delta : {delta.mean():+.3e}   (positive => photonic helps)")
    print(f"  geo-ratio  : {np.exp(np.mean(np.log(cls_rs/plus_rs))):.3f}x")
    print(f"  frozen-photonic vs trained-photonic ratio: "
          f"{np.exp(np.mean(np.log(fz_rs/plus_rs))):.3f}x")

    with open("ablation_photonic_results.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("\nWrote ablation_photonic_results.json")

    # --- plot ---
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    names = [n for n, *_ in VARIANTS]
    means = [summary[n]["rmse_mean"] for n in names]
    stds  = [summary[n]["rmse_std"]  for n in names]
    colors = ["#d62728", "#888", "#1f77b4"]
    bars = axes[0].bar(range(len(names)), means, yerr=stds, capsize=5, color=colors)
    axes[0].set_yscale("log")
    axes[0].set_xticks(range(len(names)))
    axes[0].set_xticklabels([n.replace("_", "\n") for n in names], fontsize=9)
    axes[0].set_ylabel("RMSE (log)")
    axes[0].set_title("Photonic vs classical drop-in (matched architecture)")
    for b, m in zip(bars, means):
        axes[0].text(b.get_x() + b.get_width() / 2, m * 1.18, f"{m:.2e}",
                     ha="center", va="bottom", fontsize=9)

    # paired-seed scatter
    for i, seed in enumerate(SEEDS):
        axes[1].plot([0, 1, 2],
                     [results["MerLin_QPINN_Plus"][i]["rmse"],
                      results["Classical_Plus"][i]["rmse"],
                      results["MerLin_FrozenPhotonic"][i]["rmse"]],
                     "o-", alpha=0.6, label=f"seed {seed}")
    axes[1].set_yscale("log")
    axes[1].set_xticks([0, 1, 2])
    axes[1].set_xticklabels(["Plus", "Classical_Plus", "Frozen"], fontsize=9)
    axes[1].set_ylabel("RMSE (log)")
    axes[1].set_title("Paired per-seed RMSE")
    axes[1].legend(fontsize=8)
    plt.tight_layout()
    plt.savefig("ablation_photonic.png", dpi=140, bbox_inches="tight")
    print("Wrote ablation_photonic.png")


if __name__ == "__main__":
    main()
