"""
Experiment 1: Push out of the simulable regime — mode/photon scaling.

Hypothesis: with more modes and photons, the photonic interferometer accesses a
classically-harder feature space; if there is any inductive bias from the photonic
dynamics, it should show at scale.

Method: at each (n_modes, n_photons, q_depth) configuration we build BOTH:
  * MerlinPlusBig - Fourier features -> proj -> photon-rich photonic block ->
                    proj_out -> skip-concat readout, nested-autodiff residual,
                    Adam + LBFGS finetune.
  * ClassicalPlusBig - identical wrapper, photonic block replaced by an MLP whose
                       parameter count matches the photonic block + proj_out exactly.

Runs 3 seeds. Reports RMSE, NMSE, train time, photonic / classical block param count.
"""
import math, time, json
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import merlin as ML

from benchmark_qpinn_vs_pinn import (
    DTYPE, DEVICE, SEEDS, PRETRAIN, EPOCHS, LBFGS_STEPS, ALPHA_D,
    X_MIN, X_MAX, T_MIN, T_MAX,
    FourierFeatures, paper_metrics, train, n_trainable, _hard_bc, _pred_nested,
)


def spaced_input_state(num_modes, num_photons):
    occupied = np.linspace(0, num_modes - 1, num_photons, dtype=int).tolist()
    occupied = sorted(set(occupied))
    for mode in range(num_modes):
        if len(occupied) == num_photons:
            break
        if mode not in occupied:
            occupied.append(mode)
    state = [0] * num_modes
    for mode in sorted(occupied):
        state[mode] = 1
    return state


def make_photon_rich_layer(feature_size, num_modes, num_photons, q_depth):
    builder = ML.CircuitBuilder(n_modes=num_modes)
    builder.add_entangling_layer(trainable=True, name="LI")
    builder.add_angle_encoding(modes=list(range(feature_size)),
                               name="input", subset_combinations=False)
    for d in range(q_depth):
        builder.add_entangling_layer(trainable=True, name=f"RI_{d}")
    state = spaced_input_state(num_modes, num_photons)
    ms = ML.MeasurementStrategy.probs(
        computation_space=ML.ComputationSpace.coerce("unbunched"))
    q = ML.QuantumLayer(
        input_size=feature_size, input_state=state, n_photons=num_photons,
        builder=builder, measurement_strategy=ms,
    )
    return q


class MerlinPlusBig(nn.Module):
    def __init__(self, *, num_modes, num_photons, q_depth, feature_size,
                 num_freqs=6, sigma=2.0, q_compress=4, hidden=16, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.proj_in = nn.Linear(ff_dim, feature_size)
        self.quantum = make_photon_rich_layer(feature_size, num_modes, num_photons, q_depth)
        self.proj_out = nn.Linear(self.quantum.output_size, q_compress)
        self.readout = nn.Sequential(
            nn.Linear(q_compress + 2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.proj_in(self.ff(xt))
        q = self.quantum(z)
        q = self.proj_out(q)
        h = torch.cat([q, xt], dim=-1)
        return _hard_bc(x, self.readout(h))


class ClassicalPlusBig(nn.Module):
    """Identical wrapper, photonic block + proj_out replaced by a single MLP whose
    total trainable params match the photonic block + proj_out exactly."""
    def __init__(self, *, target_block_params, feature_size, q_compress=4,
                 num_freqs=6, sigma=2.0, hidden=16, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.proj_in = nn.Linear(ff_dim, feature_size)
        # MLP feature_size -> mid -> q_compress matched to target_block_params:
        #   params = (feature_size+1)*mid + (mid+1)*q_compress
        # solve mid:
        mid = max(2, round((target_block_params - q_compress) /
                           (feature_size + 1 + q_compress)))
        self.middle = nn.Sequential(
            nn.Linear(feature_size, mid), nn.Tanh(),
            nn.Linear(mid, q_compress),
        )
        self.readout = nn.Sequential(
            nn.Linear(q_compress + 2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
        self.mid = mid

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.proj_in(self.ff(xt))
        q = self.middle(z)
        h = torch.cat([q, xt], dim=-1)
        return _hard_bc(x, self.readout(h))


# ----------------------------------------------------------------------
# Sweep configurations
# ----------------------------------------------------------------------
CONFIGS = [
    # (n_modes, n_photons, q_depth, feature_size, label)
    (5,  2, 1, 4, "(5m,2p,d1,fs4)"),
    (8,  3, 2, 4, "(8m,3p,d2,fs4)"),
    (10, 5, 2, 6, "(10m,5p,d2,fs6)"),
    (12, 6, 3, 6, "(12m,6p,d3,fs6)"),
]


def run_one(name, build_fn, kind, seed, lbfgs):
    torch.manual_seed(seed); np.random.seed(seed)
    m = build_fn().to(DEVICE)
    for p in m.parameters():
        if p.is_floating_point():
            p.data = p.data.to(DTYPE)
    _, dt = train(m, kind, seed=seed, lbfgs_steps=lbfgs)
    metrics, _, _ = paper_metrics(_pred_nested(m))
    return n_trainable(m), metrics, dt


def main():
    print(f"torch {torch.__version__} | merlin {ML.__version__} | device {DEVICE}")
    print("=" * 96)

    all_results = []
    for n_modes, n_photons, q_depth, fs, label in CONFIGS:
        print(f"\n### Config {label}: modes={n_modes}, photons={n_photons}, "
              f"depth={q_depth}, feature_size={fs}")

        # Probe photonic block size
        torch.manual_seed(0)
        probe = MerlinPlusBig(num_modes=n_modes, num_photons=n_photons,
                              q_depth=q_depth, feature_size=fs)
        q_block_params = sum(p.numel() for p in probe.quantum.parameters())
        po_params = sum(p.numel() for p in probe.proj_out.parameters())
        target_block = q_block_params + po_params
        total_q = n_trainable(probe)
        # Output dim of photonic block (basis-state dim of the unbunched space)
        q_out_dim = probe.quantum.output_size
        del probe

        torch.manual_seed(0)
        probe_c = ClassicalPlusBig(target_block_params=target_block, feature_size=fs)
        total_c = n_trainable(probe_c)
        cls_mid = probe_c.mid
        del probe_c

        print(f"  photonic block params (q+proj_out): {target_block}  "
              f"(quantum={q_block_params}, proj_out={po_params}, q_out_dim={q_out_dim})")
        print(f"  classical drop-in: MLP feature->{cls_mid}->4")
        print(f"  total trainable: photonic={total_q}, classical={total_c}")

        rec = dict(label=label, n_modes=n_modes, n_photons=n_photons,
                   q_depth=q_depth, feature_size=fs,
                   q_block_params=target_block, q_out_dim=q_out_dim,
                   cls_mid=cls_mid, total_q=total_q, total_c=total_c,
                   photonic=[], classical=[])

        for seed in SEEDS:
            print(f"  seed {seed} ...", flush=True)
            # Photonic
            tot_q, m_q, dt_q = run_one(
                "photonic",
                lambda: MerlinPlusBig(num_modes=n_modes, num_photons=n_photons,
                                      q_depth=q_depth, feature_size=fs),
                "nested", seed, LBFGS_STEPS,
            )
            print(f"    Photonic   RMSE={m_q['rmse']:.3e} NMSE={m_q['nmse']:.3e} time={dt_q:.1f}s")
            rec["photonic"].append(dict(**m_q, train_time_s=dt_q))

            # Classical
            tot_c, m_c, dt_c = run_one(
                "classical",
                lambda: ClassicalPlusBig(target_block_params=target_block,
                                         feature_size=fs),
                "nested", seed, LBFGS_STEPS,
            )
            print(f"    Classical  RMSE={m_c['rmse']:.3e} NMSE={m_c['nmse']:.3e} time={dt_c:.1f}s")
            rec["classical"].append(dict(**m_c, train_time_s=dt_c))

        all_results.append(rec)

    # ----------------------------------------------------------------------
    # Summary
    # ----------------------------------------------------------------------
    print("\n" + "=" * 110)
    print(f"{'config':18s} {'modes':>6s} {'phot':>5s} {'q_dim':>6s} "
          f"{'q_blk':>6s} {'tot_q':>6s} {'tot_c':>6s} "
          f"{'RMSE_q':>11s} {'RMSE_c':>11s} {'ratio (c/q)':>13s} "
          f"{'time_q':>8s} {'time_c':>8s}")
    print("-" * 110)
    summary = []
    for r in all_results:
        rs_q = np.array([m["rmse"] for m in r["photonic"]])
        rs_c = np.array([m["rmse"] for m in r["classical"]])
        tt_q = np.mean([m["train_time_s"] for m in r["photonic"]])
        tt_c = np.mean([m["train_time_s"] for m in r["classical"]])
        ratio = np.exp(np.mean(np.log(rs_c / rs_q)))  # >1 means photonic better
        summary.append(dict(
            label=r["label"], n_modes=r["n_modes"], n_photons=r["n_photons"],
            q_block_params=r["q_block_params"], q_out_dim=r["q_out_dim"],
            total_q=r["total_q"], total_c=r["total_c"],
            rmse_q_mean=float(rs_q.mean()), rmse_q_std=float(rs_q.std()),
            rmse_c_mean=float(rs_c.mean()), rmse_c_std=float(rs_c.std()),
            ratio_c_over_q=float(ratio),
            time_q=float(tt_q), time_c=float(tt_c),
        ))
        print(f"{r['label']:18s} {r['n_modes']:>6d} {r['n_photons']:>5d} {r['q_out_dim']:>6d} "
              f"{r['q_block_params']:>6d} {r['total_q']:>6d} {r['total_c']:>6d} "
              f"{rs_q.mean():>11.3e} {rs_c.mean():>11.3e} {ratio:>13.3f} "
              f"{tt_q:>8.1f} {tt_c:>8.1f}")
    print("=" * 110)
    print("ratio = exp(mean(log(rmse_classical / rmse_photonic)))   >1 means photonic better")

    with open("exp1_photon_scaling.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("\nWrote exp1_photon_scaling.json")

    # Plot RMSE vs photonic block size
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    xs = [s["q_block_params"] for s in summary]
    rmse_q = [s["rmse_q_mean"] for s in summary]
    rmse_c = [s["rmse_c_mean"] for s in summary]
    err_q = [s["rmse_q_std"]  for s in summary]
    err_c = [s["rmse_c_std"]  for s in summary]
    labels = [s["label"] for s in summary]

    ax[0].errorbar(xs, rmse_q, yerr=err_q, fmt="o-", capsize=4, label="MerLin (photonic)", color="#d62728")
    ax[0].errorbar(xs, rmse_c, yerr=err_c, fmt="s-", capsize=4, label="Classical drop-in", color="#666")
    for x, lab in zip(xs, labels):
        ax[0].annotate(lab, (x, max(rmse_q)*1.05), fontsize=7, rotation=15)
    ax[0].set_xlabel("photonic block params (= matched classical params)")
    ax[0].set_ylabel("RMSE (mean+/-std, 3 seeds)")
    ax[0].set_yscale("log"); ax[0].set_xscale("log")
    ax[0].set_title("Accuracy vs photonic scale")
    ax[0].legend()

    ratios = [s["ratio_c_over_q"] for s in summary]
    ax[1].axhline(1.0, ls="--", c="k", lw=0.7, label="parity")
    ax[1].plot(xs, ratios, "o-", color="#1f77b4")
    for x, lab, r in zip(xs, labels, ratios):
        ax[1].annotate(f"{lab}\n{r:.2f}x", (x, r), fontsize=7)
    ax[1].set_xlabel("photonic block params")
    ax[1].set_ylabel("RMSE ratio (classical / photonic)")
    ax[1].set_xscale("log")
    ax[1].set_title("Photonic advantage at scale (>1 means photonic wins)")
    ax[1].legend()
    plt.tight_layout()
    plt.savefig("exp1_photon_scaling.png", dpi=140, bbox_inches="tight")
    print("Wrote exp1_photon_scaling.png")


if __name__ == "__main__":
    main()
