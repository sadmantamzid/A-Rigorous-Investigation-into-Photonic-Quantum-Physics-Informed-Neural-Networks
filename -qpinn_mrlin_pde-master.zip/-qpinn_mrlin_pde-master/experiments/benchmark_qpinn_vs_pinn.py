"""
Benchmark: Classical PINN vs MerLin QPINN on the 1D heat equation.

Setup mirrors merlin_dv_qpinn_paper_baseline.ipynb (paper-faithful):
  alpha = 0.30, x in [-pi/2, pi/2], t in [0, 0.5], Gaussian IC at -pi/8.
  Hard BC via cos(x) * q_u. Sobol sampling. RK45 reference.
  3 seeds, 200 IC pretrain + 500 main epochs, Adam lr=1e-2.

Variants:
  C1  Classical_PINN           - paper-style aux-deriv MLP (param-matched)
  C2  Classical_PINN_FF        - classical with Fourier features (param-matched)
  Q1  MerLin_QPINN_Paper       - paper hybrid, aux-deriv + consistency
  Q2  MerLin_QPINN_Nested      - hybrid with nested autodiff
  Q3  MerLin_QPINN_Plus        - Fourier + nested + LBFGS finetune (improved)

Outputs:
  benchmark_results.json   - full per-seed metrics + train times
  benchmark_summary.png    - bar+error plot, loss curves, predicted fields
"""

import math
import time
import json
import copy
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.stats import qmc

import merlin as ML

# ----------------------------------------------------------------------
# Paper-faithful constants
# ----------------------------------------------------------------------
torch.set_default_dtype(torch.float32)
DTYPE = torch.float32
DEVICE = torch.device("cpu")  # photonic sim is CPU-bound; MPS adds little here.
SEEDS = [1234, 2024, 7]
PRETRAIN = 200
EPOCHS = 500
LBFGS_STEPS = 50          # only for Q3
LR_ADAM = 1e-2
ALPHA_D = 0.30
X_MIN, X_MAX = -math.pi / 2, math.pi / 2
T_MIN, T_MAX = 0.0, 0.5
SIGMA_SQ = 0.2
X_SHIFT = math.pi / 8

print(f"torch {torch.__version__} | merlin {getattr(ML, '__version__', '?')} | device {DEVICE}")


# ----------------------------------------------------------------------
# Reference, sampling, metrics
# ----------------------------------------------------------------------
def T0_np(x):
    return 0.5 * np.exp(-(x + X_SHIFT) ** 2 / (2.0 * SIGMA_SQ))


def T0_torch(x):
    return 0.5 * torch.exp(-(x + X_SHIFT) ** 2 / (2.0 * SIGMA_SQ))


_sobol = qmc.Sobol(d=2, scramble=True, seed=0)


def _reset_sobol(s):
    global _sobol
    _sobol = qmc.Sobol(d=2, scramble=True, seed=int(s))


def sobol_xt(n):
    p = _sobol.random(n)
    x = X_MIN + (X_MAX - X_MIN) * p[:, 0:1]
    t = T_MIN + (T_MAX - T_MIN) * p[:, 1:2]
    return torch.tensor(np.concatenate([x, t], axis=1), dtype=DTYPE, device=DEVICE)


def sobol_x(n):
    p = _sobol.random(n)
    return torch.tensor(X_MIN + (X_MAX - X_MIN) * p[:, 0:1], dtype=DTYPE, device=DEVICE)


def build_reference(alpha=ALPHA_D, T0_fn=T0_np, xL=X_MIN, xR=X_MAX, tF=T_MAX, nx=257, nt=101):
    x = np.linspace(xL, xR, nx); dx = x[1] - x[0]
    t = np.linspace(0.0, tF, nt)
    T0g = T0_fn(x); T0g[0] = 0.0; T0g[-1] = 0.0

    def rhs(_t, T):
        d2 = np.zeros_like(T)
        d2[1:-1] = (T[2:] - 2 * T[1:-1] + T[:-2]) / dx ** 2
        return alpha * d2

    sol = solve_ivp(rhs, (0.0, tF), T0g, t_eval=t, method="RK45",
                    rtol=1e-8, atol=1e-10, max_step=1e-3)
    return x, t, sol.y


REF_X, REF_T, T_REF = build_reference()
print(f"reference grid: x={REF_X.shape}, t={REF_T.shape}, T_ref={T_REF.shape}")


def _ref_interp(x_np, t_np):
    rx0, rxN = REF_X[0], REF_X[-1]; rt0, rtN = REF_T[0], REF_T[-1]
    dx = REF_X[1] - REF_X[0]; dt = REF_T[1] - REF_T[0]
    Nx, Nt = T_REF.shape
    x_np = np.clip(x_np, rx0, rxN); t_np = np.clip(t_np, rt0, rtN)
    ix = (x_np - rx0) / dx; it = (t_np - rt0) / dt
    i0 = np.clip(np.floor(ix).astype(int), 0, Nx - 2)
    j0 = np.clip(np.floor(it).astype(int), 0, Nt - 2)
    fx = ix - i0; ft = it - j0
    return ((1 - fx) * (1 - ft) * T_REF[i0, j0]
            + fx * (1 - ft) * T_REF[i0 + 1, j0]
            + (1 - fx) * ft * T_REF[i0, j0 + 1]
            + fx * ft * T_REF[i0 + 1, j0 + 1])


def paper_metrics(pred_fn, nx=80, nt=80):
    xs = np.linspace(X_MIN, X_MAX, nx); ts = np.linspace(T_MIN, T_MAX, nt)
    X, T = np.meshgrid(xs, ts, indexing="ij")
    xt_np = np.stack([X.ravel(), T.ravel()], axis=1)
    xt = torch.tensor(xt_np, dtype=DTYPE, device=DEVICE)
    with torch.no_grad():
        T_pred = pred_fn(xt).detach().cpu().numpy().reshape(nx, nt)
    T_true = _ref_interp(xt_np[:, 0], xt_np[:, 1]).reshape(nx, nt)
    err = T_pred - T_true
    return dict(
        rmse=float(np.sqrt(np.mean(err ** 2))),
        mae=float(np.mean(np.abs(err))),
        linf=float(np.max(np.abs(err))),
        nmse=float(np.sum(err ** 2) / np.sum(T_true ** 2)),
    ), T_pred, T_true


def n_trainable(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def _hard_bc(x, q_u):
    return torch.cos(x) * q_u


def _grad(y, x):
    return torch.autograd.grad(y, x, grad_outputs=torch.ones_like(y),
                               create_graph=True, retain_graph=True)[0]


# ----------------------------------------------------------------------
# Fourier feature encoder (learnable=False, reproducible with seed)
# ----------------------------------------------------------------------
class FourierFeatures(nn.Module):
    """Random Fourier feature encoder. Standard PINN trick to fight spectral bias."""
    def __init__(self, in_dim=2, num_freqs=8, sigma=2.0, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        B = torch.randn(in_dim, num_freqs, generator=g) * sigma
        self.register_buffer("B", B)

    def forward(self, x):
        z = x @ self.B * 2 * math.pi
        return torch.cat([torch.sin(z), torch.cos(z)], dim=-1)  # [N, 2*num_freqs]


# ----------------------------------------------------------------------
# Models
# ----------------------------------------------------------------------
class ClassicalPINN(nn.Module):
    """Pure-classical PINN with aux-deriv head (paper-style residual)."""
    def __init__(self, hidden_a=16, mlp_hidden=8, feature_size=4, qos=4):
        super().__init__()
        self.feature_map = nn.Sequential(
            nn.Linear(2, hidden_a), nn.Tanh(), nn.Linear(hidden_a, feature_size),
        )
        self.middle = nn.Sequential(
            nn.Linear(feature_size, mlp_hidden), nn.Tanh(),
            nn.Linear(mlp_hidden, qos),
        )
        self.readout = nn.Sequential(
            nn.Linear(qos, hidden_a), nn.Tanh(), nn.Linear(hidden_a, 2),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.feature_map(xt)
        m = self.middle(z)
        out = self.readout(m)
        return _hard_bc(x, out[:, 0:1]), out[:, 1:2]


class ClassicalPINN_FF(nn.Module):
    """Classical PINN with Fourier features; aux-deriv head."""
    def __init__(self, num_freqs=8, sigma=2.0, hidden=24, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.net = nn.Sequential(
            nn.Linear(ff_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 2),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.ff(xt)
        out = self.net(z)
        return _hard_bc(x, out[:, 0:1]), out[:, 1:2]


class MerlinQPINN_Paper(nn.Module):
    """Paper-style hybrid: feature_map -> QuantumLayer.simple -> readout, aux-deriv head."""
    def __init__(self, feature_size=4, qos=4, hidden=16):
        super().__init__()
        self.feature_map = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(), nn.Linear(hidden, feature_size),
        )
        self.quantum = ML.QuantumLayer.simple(input_size=feature_size, output_size=qos)
        self.readout = nn.Sequential(
            nn.Linear(qos, hidden), nn.Tanh(), nn.Linear(hidden, 2),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.feature_map(xt)
        q = self.quantum(z)
        out = self.readout(q)
        return _hard_bc(x, out[:, 0:1]), out[:, 1:2]


class MerlinQPINN_Nested(nn.Module):
    """Same hybrid; single output T; PDE residual uses nested autodiff."""
    def __init__(self, feature_size=4, qos=4, hidden=16):
        super().__init__()
        self.feature_map = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(), nn.Linear(hidden, feature_size),
        )
        self.quantum = ML.QuantumLayer.simple(input_size=feature_size, output_size=qos)
        self.readout = nn.Sequential(
            nn.Linear(qos, hidden), nn.Tanh(), nn.Linear(hidden, 1),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.feature_map(xt)
        q = self.quantum(z)
        return _hard_bc(x, self.readout(q))


class MerlinQPINN_Plus(nn.Module):
    """Improved: Fourier features -> projection -> photonic core -> readout with skip.
    Single output T; nested-autodiff residual; LBFGS finetune applied externally.
    """
    def __init__(self, num_freqs=6, sigma=2.0, qin=4, qos=4, hidden=16, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.proj_in = nn.Linear(ff_dim, qin)
        self.quantum = ML.QuantumLayer.simple(input_size=qin, output_size=qos)
        # Skip-connect raw (x,t) into the readout so the photonic block is the nonlinearity,
        # not the only thing carrying coordinates.
        self.readout = nn.Sequential(
            nn.Linear(qos + 2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.ff(xt)
        z = self.proj_in(z)
        q = self.quantum(z)
        h = torch.cat([q, xt], dim=-1)
        return _hard_bc(x, self.readout(h))


# ----------------------------------------------------------------------
# Training loops
# ----------------------------------------------------------------------
def _bc_batch(n=64):
    t_b = T_MIN + (T_MAX - T_MIN) * sobol_x(n).clamp(min=X_MIN, max=X_MAX).sub(X_MIN).div(X_MAX - X_MIN)
    half = n // 2
    x_b = torch.cat([
        torch.full((half, 1), X_MIN, dtype=DTYPE, device=DEVICE),
        torch.full((n - half, 1), X_MAX, dtype=DTYPE, device=DEVICE),
    ], dim=0)
    return torch.cat([x_b, t_b], dim=1)


def _ic_batch(n=128):
    x_ic = sobol_x(n)
    return torch.cat([x_ic, torch.zeros_like(x_ic)], dim=1), x_ic


LAM_AUX = dict(pde=0.1, ic=0.6, bc=0.1, cons=0.1)
LAM_NESTED = dict(pde=0.1, ic=0.7, bc=0.2)


def loss_aux(model, lam=LAM_AUX, n_f=128, n_i=128, n_b=64):
    xt_f = sobol_xt(n_f); xt_f.requires_grad_(True)
    xt_ic, x_ic = _ic_batch(n_i)
    xt_b = _bc_batch(n_b)
    T, Tx_hat = model(xt_f)
    g = _grad(T, xt_f)
    T_x, T_t = g[:, 0:1], g[:, 1:2]
    Tx_x = _grad(Tx_hat, xt_f)[:, 0:1]
    r_pde = T_t - ALPHA_D * Tx_x
    r_cons = T_x - Tx_hat
    T_ic, _ = model(xt_ic)
    T_bv, _ = model(xt_b)
    mse = nn.MSELoss()
    return (lam["pde"] * mse(r_pde, torch.zeros_like(r_pde))
            + lam["ic"] * mse(T_ic, T0_torch(x_ic))
            + lam["bc"] * mse(T_bv, torch.zeros_like(T_bv))
            + lam["cons"] * mse(r_cons, torch.zeros_like(r_cons)))


def loss_nested(model, lam=LAM_NESTED, n_f=128, n_i=128, n_b=64):
    xt_f = sobol_xt(n_f); xt_f.requires_grad_(True)
    xt_ic, x_ic = _ic_batch(n_i)
    xt_b = _bc_batch(n_b)
    T = model(xt_f)
    g = _grad(T, xt_f)
    T_x, T_t = g[:, 0:1], g[:, 1:2]
    T_xx = _grad(T_x, xt_f)[:, 0:1]
    r_pde = T_t - ALPHA_D * T_xx
    T_ic = model(xt_ic)
    T_bv = model(xt_b)
    mse = nn.MSELoss()
    return (lam["pde"] * mse(r_pde, torch.zeros_like(r_pde))
            + lam["ic"] * mse(T_ic, T0_torch(x_ic))
            + lam["bc"] * mse(T_bv, torch.zeros_like(T_bv)))


def train(model, kind, *, seed, pretrain=PRETRAIN, epochs=EPOCHS, lr=LR_ADAM,
          lbfgs_steps=0):
    """kind in {'aux', 'nested'}; lbfgs_steps>0 enables LBFGS finetune."""
    _reset_sobol(seed)
    torch.manual_seed(seed); np.random.seed(seed)
    opt = torch.optim.Adam(
        [p for p in model.parameters() if p.requires_grad], lr=lr,
    )
    history = np.zeros(pretrain + epochs)
    t0 = time.perf_counter()

    # IC pre-train
    for e in range(pretrain):
        opt.zero_grad()
        xt_ic, x_ic = _ic_batch(128)
        out = model(xt_ic)
        T_ic = out[0] if isinstance(out, tuple) else out
        loss = nn.MSELoss()(T_ic, T0_torch(x_ic))
        loss.backward(); opt.step()
        history[e] = loss.item()

    # Adam main loop
    loss_fn = loss_aux if kind == "aux" else loss_nested
    for e in range(epochs):
        opt.zero_grad()
        loss = loss_fn(model)
        loss.backward(); opt.step()
        history[pretrain + e] = loss.item()

    # Optional LBFGS finetune (uses full-batch fixed Sobol points for stable closure)
    if lbfgs_steps > 0:
        # Snapshot a reproducible collocation set
        _reset_sobol(seed + 9999)
        xt_f = sobol_xt(512); xt_f.requires_grad_(True)
        xt_ic_lb, x_ic_lb = _ic_batch(256)
        xt_b_lb = _bc_batch(128)
        opt2 = torch.optim.LBFGS(
            [p for p in model.parameters() if p.requires_grad],
            lr=1.0, max_iter=20, history_size=50, tolerance_grad=1e-9,
            tolerance_change=1e-12, line_search_fn="strong_wolfe",
        )
        mse = nn.MSELoss()

        def closure():
            opt2.zero_grad()
            T = model(xt_f)
            T = T[0] if isinstance(T, tuple) else T
            g = _grad(T, xt_f)
            T_x, T_t = g[:, 0:1], g[:, 1:2]
            T_xx = _grad(T_x, xt_f)[:, 0:1]
            r_pde = T_t - ALPHA_D * T_xx
            T_ic = model(xt_ic_lb)
            T_ic = T_ic[0] if isinstance(T_ic, tuple) else T_ic
            T_bv = model(xt_b_lb)
            T_bv = T_bv[0] if isinstance(T_bv, tuple) else T_bv
            loss = (LAM_NESTED["pde"] * mse(r_pde, torch.zeros_like(r_pde))
                    + LAM_NESTED["ic"] * mse(T_ic, T0_torch(x_ic_lb))
                    + LAM_NESTED["bc"] * mse(T_bv, torch.zeros_like(T_bv)))
            loss.backward()
            return loss

        for _ in range(lbfgs_steps):
            opt2.step(closure)

    return history, time.perf_counter() - t0


def _pred_aux(model):
    return lambda xt: model(xt)[0]


def _pred_nested(model):
    return lambda xt: model(xt)


# ----------------------------------------------------------------------
# Match parameter counts + run benchmark (only when this file is the entry point;
# importing the module just exposes the model classes & helpers).
# ----------------------------------------------------------------------
if __name__ == "__main__":
    torch.manual_seed(0)
    target = n_trainable(MerlinQPINN_Paper())
    q_params = sum(p.numel() for p in MerlinQPINN_Paper().quantum.parameters() if p.requires_grad)
    print(f"Target trainable params (Merlin paper hybrid): {target}  (of which photonic: {q_params})")

    best_h, best_diff = 8, None
    for h in range(2, 64):
        cand = ClassicalPINN(mlp_hidden=h)
        diff = abs(n_trainable(cand) - target)
        if best_diff is None or diff < best_diff:
            best_h, best_diff = h, diff
    MLP_HIDDEN = best_h
    print(f"Classical_PINN mlp_hidden={MLP_HIDDEN} -> {n_trainable(ClassicalPINN(mlp_hidden=MLP_HIDDEN))} params")

    best_ff, best_diff = 16, None
    for h in range(8, 48):
        cand = ClassicalPINN_FF(hidden=h, num_freqs=8)
        diff = abs(n_trainable(cand) - target)
        if best_diff is None or diff < best_diff:
            best_ff, best_diff = h, diff
    FF_HIDDEN = best_ff
    print(f"Classical_PINN_FF hidden={FF_HIDDEN} -> {n_trainable(ClassicalPINN_FF(hidden=FF_HIDDEN, num_freqs=8))} params")

    print(f"MerLin_QPINN_Plus -> {n_trainable(MerlinQPINN_Plus())} params (allowed to be ~30% larger)")

    VARIANTS = [
        ("Classical_PINN",        "aux",    lambda: ClassicalPINN(mlp_hidden=MLP_HIDDEN), 0),
        ("Classical_PINN_FF",     "aux",    lambda: ClassicalPINN_FF(hidden=FF_HIDDEN, num_freqs=8), 0),
        ("MerLin_QPINN_Paper",    "aux",    lambda: MerlinQPINN_Paper(), 0),
        ("MerLin_QPINN_Nested",   "nested", lambda: MerlinQPINN_Nested(), 0),
        ("MerLin_QPINN_Plus",     "nested", lambda: MerlinQPINN_Plus(), LBFGS_STEPS),
    ]

    results = {name: [] for name, *_ in VARIANTS}
    curves  = {name: [] for name, *_ in VARIANTS}
    fields  = {name: None for name, *_ in VARIANTS}
    param_counts = {}

    print("\n" + "=" * 88)
    for seed in SEEDS:
        print(f"\n=== seed {seed} ===")
        for name, kind, build, lbfgs in VARIANTS:
            torch.manual_seed(seed); np.random.seed(seed)
            m = build().to(DEVICE)
            for p in m.parameters():
                if p.is_floating_point():
                    p.data = p.data.to(DTYPE)
            param_counts[name] = n_trainable(m)
            hist, dt = train(m, kind, seed=seed, lbfgs_steps=lbfgs)
            pred_fn = _pred_aux(m) if kind == "aux" else _pred_nested(m)
            metrics, T_pred, T_true = paper_metrics(pred_fn)
            metrics["train_time_s"] = dt
            results[name].append(metrics)
            curves[name].append(hist)
            fields[name] = (T_pred, T_true)
            flag = " (+LBFGS)" if lbfgs else ""
            print(f"  {name:22s}{flag:9s} | params={param_counts[name]:4d} | "
                  f"RMSE={metrics['rmse']:.3e} NMSE={metrics['nmse']:.3e} time={dt:5.1f}s")

    print("\n" + "=" * 88)
    print(f"{'variant':24s} {'params':>7s} {'RMSE mean':>11s} {'RMSE std':>10s} "
          f"{'NMSE mean':>11s} {'Linf mean':>11s} {'time(s)':>9s}")
    print("-" * 88)
    summary = {}
    for name, *_ in VARIANTS:
        rs = np.array([r["rmse"] for r in results[name]])
        ns = np.array([r["nmse"] for r in results[name]])
        li = np.array([r["linf"] for r in results[name]])
        tt = np.array([r["train_time_s"] for r in results[name]])
        summary[name] = dict(
            params=param_counts[name],
            rmse_mean=float(rs.mean()), rmse_std=float(rs.std()),
            nmse_mean=float(ns.mean()), linf_mean=float(li.mean()),
            time_mean=float(tt.mean()),
            per_seed=results[name],
        )
        print(f"{name:24s} {param_counts[name]:>7d} {rs.mean():>11.3e} {rs.std():>10.3e} "
              f"{ns.mean():>11.3e} {li.mean():>11.3e} {tt.mean():>9.2f}")
    print("=" * 88)

    with open("benchmark_results.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("\nWrote benchmark_results.json")

    # ---- plots ----
    fig = plt.figure(figsize=(15, 10))
    gs = fig.add_gridspec(2, 3, hspace=0.35, wspace=0.30)
    ax = fig.add_subplot(gs[0, 0])
    names = [n for n, *_ in VARIANTS]
    means = [summary[n]["rmse_mean"] for n in names]
    stds  = [summary[n]["rmse_std"]  for n in names]
    colors = ["#888", "#666", "#1f77b4", "#2ca02c", "#d62728"]
    bars = ax.bar(range(len(names)), means, yerr=stds, capsize=5, color=colors)
    ax.set_yscale("log")
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels([n.replace("_", "\n") for n in names], fontsize=8)
    ax.set_ylabel("RMSE (lower better)")
    ax.set_title("RMSE on heat eq, 3 seeds")
    for b, m in zip(bars, means):
        ax.text(b.get_x() + b.get_width() / 2, m * 1.15, f"{m:.2e}",
                ha="center", va="bottom", fontsize=8)
    ax = fig.add_subplot(gs[0, 1])
    for name, c in zip(names, colors):
        arr = np.stack(curves[name])
        mn, st = arr.mean(0), arr.std(0)
        e = np.arange(1, mn.size + 1)
        ax.semilogy(e, mn, label=name, color=c, lw=1.2)
        ax.fill_between(e, np.maximum(mn - st, 1e-10), mn + st, alpha=0.15, color=c)
    ax.axvline(PRETRAIN, ls="--", c="k", lw=0.6)
    ax.set_xlabel("epoch"); ax.set_ylabel("total loss")
    ax.set_title("Training loss (pretrain | main)")
    ax.legend(fontsize=7, loc="upper right")
    ax = fig.add_subplot(gs[0, 2])
    for name, c in zip(names, colors):
        ax.errorbar(summary[name]["time_mean"], summary[name]["rmse_mean"],
                    yerr=summary[name]["rmse_std"], fmt="o", ms=8, color=c,
                    label=name, capsize=4)
    ax.set_xlabel("train time (s)"); ax.set_ylabel("RMSE")
    ax.set_yscale("log"); ax.set_xscale("log")
    ax.set_title("Accuracy vs cost"); ax.legend(fontsize=7)
    T_pred_best, T_true = fields["MerLin_QPINN_Plus"]
    T_pred_classic, _   = fields["Classical_PINN"]
    vmax = max(np.abs(T_true).max(), np.abs(T_pred_best).max())
    emax_b = np.abs(T_pred_best - T_true).max()
    emax_c = np.abs(T_pred_classic - T_true).max()
    emax = max(emax_b, emax_c, 1e-6)
    ax = fig.add_subplot(gs[1, 0])
    im = ax.imshow(T_true, origin="lower", aspect="auto", vmin=-vmax, vmax=vmax,
                   extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="viridis")
    ax.set_title("RK45 reference T(x,t)"); ax.set_xlabel("t"); ax.set_ylabel("x")
    plt.colorbar(im, ax=ax)
    ax = fig.add_subplot(gs[1, 1])
    im = ax.imshow(np.abs(T_pred_classic - T_true), origin="lower", aspect="auto",
                   vmin=0, vmax=emax, extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="magma")
    ax.set_title(f"|err| Classical_PINN  (max={emax_c:.2e})"); ax.set_xlabel("t")
    plt.colorbar(im, ax=ax)
    ax = fig.add_subplot(gs[1, 2])
    im = ax.imshow(np.abs(T_pred_best - T_true), origin="lower", aspect="auto",
                   vmin=0, vmax=emax, extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="magma")
    ax.set_title(f"|err| MerLin_QPINN_Plus  (max={emax_b:.2e})"); ax.set_xlabel("t")
    plt.colorbar(im, ax=ax)
    fig.suptitle("Classical PINN vs MerLin QPINN — 1D heat equation benchmark",
                 fontsize=12, y=0.995)
    plt.savefig("benchmark_summary.png", dpi=140, bbox_inches="tight")
    print("Wrote benchmark_summary.png")
    print("\nDone.")
