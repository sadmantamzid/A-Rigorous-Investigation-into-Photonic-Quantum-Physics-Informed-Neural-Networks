"""
Experiment 2: Schroedinger equation — a PDE whose structure (unitary evolution)
might match the photonic interferometer's inductive bias better than the heat
equation does.

  i d/dt psi(x,t) = -1/2 d2/dx2 psi(x,t)        (free particle, hbar=m=1)
  IC:  psi(x,0) = (2 pi s2)^(-1/4) exp(-(x-x0)^2/(4 s2) + i k0 (x-x0))
  Domain: x in [-3, 3], t in [0, 0.5]
  Parameters: x0=0, k0=2.0, sigma=0.4

We split psi = u + i v. Schroedinger:
  Real:  u_t = -1/2 v_xx
  Imag:  v_t =  1/2 u_xx

Reference: closed-form analytic free-particle Gaussian wavepacket.
Hard BC: psi(x, t) = cos(pi x / 6) * raw  (cos(+/-pi/2) = 0 at x=+/-3).

Compare PhotonicPlus vs ClassicalPlus (matched 40-param block) under identical wrapper.
"""
import math, time, json
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from scipy.stats import qmc
import merlin as ML

from benchmark_qpinn_vs_pinn import (
    DTYPE, DEVICE, SEEDS, FourierFeatures, n_trainable, _grad,
)


# Domain & wavepacket
X_MIN, X_MAX = -3.0, 3.0
T_MIN, T_MAX = 0.0, 0.5
X0 = 0.0
K0 = 2.0
SIGMA = 0.4
S2 = SIGMA ** 2

PRETRAIN = 200
EPOCHS = 800
LBFGS_STEPS = 80
LR = 5e-3


def analytic(x_np, t_np):
    """Closed-form free-particle Gaussian wavepacket. Returns (u, v) = (Re, Im)."""
    x = x_np.astype(np.complex128)
    t = t_np.astype(np.complex128)
    alpha = S2 + 1j * t * 0.5
    norm = (2 * math.pi * S2) ** (-0.25) * np.sqrt(S2 / alpha)
    psi = norm * np.exp(- (x - X0 - K0 * t) ** 2 / (4 * alpha)
                        + 1j * K0 * (x - X0) - 1j * (K0 ** 2) * t / 2)
    return psi.real.astype(np.float32), psi.imag.astype(np.float32)


def analytic_torch(xt):
    """Analytic IC at given (x, t) - returns torch tensors (u, v)."""
    x = xt[:, 0:1].detach().cpu().numpy()
    t = xt[:, 1:2].detach().cpu().numpy()
    u, v = analytic(x, t)
    return (torch.tensor(u, dtype=DTYPE, device=DEVICE),
            torch.tensor(v, dtype=DTYPE, device=DEVICE))


_sobol = qmc.Sobol(d=2, scramble=True, seed=0)
def _reset_sobol(s):
    global _sobol
    _sobol = qmc.Sobol(d=2, scramble=True, seed=int(s))


def sobol_xt(n):
    p = _sobol.random(n)
    x = X_MIN + (X_MAX - X_MIN) * p[:, 0:1]
    t = T_MIN + (T_MAX - T_MIN) * p[:, 1:2]
    return torch.tensor(np.concatenate([x, t], axis=1), dtype=DTYPE, device=DEVICE)


def sobol_x(n):
    p = _sobol.random(n)
    return torch.tensor(X_MIN + (X_MAX - X_MIN) * p[:, 0:1], dtype=DTYPE, device=DEVICE)


def metrics(pred_fn, nx=80, nt=80):
    """RMSE on |psi|^2 against analytic reference."""
    xs = np.linspace(X_MIN, X_MAX, nx); ts = np.linspace(T_MIN, T_MAX, nt)
    Xg, Tg = np.meshgrid(xs, ts, indexing="ij")
    xt_np = np.stack([Xg.ravel(), Tg.ravel()], axis=1)
    xt = torch.tensor(xt_np, dtype=DTYPE, device=DEVICE)
    with torch.no_grad():
        u_pred, v_pred = pred_fn(xt)
        rho_pred = (u_pred ** 2 + v_pred ** 2).cpu().numpy().reshape(nx, nt)
    u_t, v_t = analytic(xt_np[:, 0], xt_np[:, 1])
    rho_true = (u_t ** 2 + v_t ** 2).reshape(nx, nt)
    err = rho_pred - rho_true
    return dict(
        rmse=float(np.sqrt(np.mean(err ** 2))),
        mae=float(np.mean(np.abs(err))),
        linf=float(np.max(np.abs(err))),
        nmse=float(np.sum(err ** 2) / np.sum(rho_true ** 2)),
    ), rho_pred, rho_true


def _hard_bc(x, raw):
    """Multiply by cos(pi x / 6) so output is exactly zero at x = +/- 3."""
    factor = torch.cos(math.pi * x / 6)
    return factor * raw


class SchroPhotonicPlus(nn.Module):
    """Photonic Plus, two outputs (u, v) for psi = u + i v."""
    def __init__(self, num_freqs=8, sigma=2.0, qin=4, qos=4, hidden=24, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.proj_in = nn.Linear(ff_dim, qin)
        self.quantum = ML.QuantumLayer.simple(input_size=qin, output_size=qos)
        self.readout = nn.Sequential(
            nn.Linear(qos + 2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 2),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.proj_in(self.ff(xt))
        q = self.quantum(z)
        out = self.readout(torch.cat([q, xt], dim=-1))
        u = _hard_bc(x, out[:, 0:1])
        v = _hard_bc(x, out[:, 1:2])
        return u, v


class SchroClassicalPlus(nn.Module):
    def __init__(self, num_freqs=8, sigma=2.0, qin=4, qmid=4, qos=4, hidden=24, ff_seed=0):
        super().__init__()
        self.ff = FourierFeatures(in_dim=2, num_freqs=num_freqs, sigma=sigma, seed=ff_seed)
        ff_dim = 2 * num_freqs
        self.proj_in = nn.Linear(ff_dim, qin)
        self.middle = nn.Sequential(
            nn.Linear(qin, qmid), nn.Tanh(),
            nn.Linear(qmid, qos),
        )
        self.readout = nn.Sequential(
            nn.Linear(qos + 2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 2),
        )

    def forward(self, xt):
        x = xt[:, 0:1]
        z = self.proj_in(self.ff(xt))
        m = self.middle(z)
        out = self.readout(torch.cat([m, xt], dim=-1))
        u = _hard_bc(x, out[:, 0:1])
        v = _hard_bc(x, out[:, 1:2])
        return u, v


LAM = dict(pde=1.0, ic=10.0)


def loss_fn(model, n_f=256, n_i=128):
    xt_f = sobol_xt(n_f); xt_f.requires_grad_(True)
    x_ic = sobol_x(n_i)
    xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], dim=1)
    u, v = model(xt_f)
    g_u = _grad(u, xt_f); u_x, u_t = g_u[:, 0:1], g_u[:, 1:2]
    g_v = _grad(v, xt_f); v_x, v_t = g_v[:, 0:1], g_v[:, 1:2]
    u_xx = _grad(u_x, xt_f)[:, 0:1]
    v_xx = _grad(v_x, xt_f)[:, 0:1]
    # Schroedinger: u_t = -1/2 v_xx,  v_t = 1/2 u_xx
    r_u = u_t + 0.5 * v_xx
    r_v = v_t - 0.5 * u_xx
    u_ic, v_ic = model(xt_ic)
    u_ic_true, v_ic_true = analytic_torch(xt_ic)
    mse = nn.MSELoss()
    pde = mse(r_u, torch.zeros_like(r_u)) + mse(r_v, torch.zeros_like(r_v))
    ic  = mse(u_ic, u_ic_true) + mse(v_ic, v_ic_true)
    return LAM["pde"] * pde + LAM["ic"] * ic


def train(model, *, seed):
    _reset_sobol(seed)
    torch.manual_seed(seed); np.random.seed(seed)
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=LR)
    t0 = time.perf_counter()
    # IC pre-train
    for _ in range(PRETRAIN):
        opt.zero_grad()
        x_ic = sobol_x(128)
        xt_ic = torch.cat([x_ic, torch.zeros_like(x_ic)], dim=1)
        u, v = model(xt_ic)
        u_t_ic, v_t_ic = analytic_torch(xt_ic)
        loss = nn.MSELoss()(u, u_t_ic) + nn.MSELoss()(v, v_t_ic)
        loss.backward(); opt.step()
    # Adam main loop
    for _ in range(EPOCHS):
        opt.zero_grad()
        loss = loss_fn(model)
        loss.backward(); opt.step()
    # LBFGS finetune
    if LBFGS_STEPS > 0:
        _reset_sobol(seed + 9999)
        xt_f = sobol_xt(1024); xt_f.requires_grad_(True)
        x_ic_lb = sobol_x(256)
        xt_ic_lb = torch.cat([x_ic_lb, torch.zeros_like(x_ic_lb)], dim=1)
        u_t_lb, v_t_lb = analytic_torch(xt_ic_lb)
        opt2 = torch.optim.LBFGS(
            [p for p in model.parameters() if p.requires_grad],
            lr=1.0, max_iter=20, history_size=50,
            tolerance_grad=1e-9, tolerance_change=1e-12,
            line_search_fn="strong_wolfe",
        )
        mse = nn.MSELoss()

        def closure():
            opt2.zero_grad()
            u, v = model(xt_f)
            g_u = _grad(u, xt_f); u_x, u_t_ = g_u[:, 0:1], g_u[:, 1:2]
            g_v = _grad(v, xt_f); v_x, v_t_ = g_v[:, 0:1], g_v[:, 1:2]
            u_xx = _grad(u_x, xt_f)[:, 0:1]
            v_xx = _grad(v_x, xt_f)[:, 0:1]
            r_u = u_t_ + 0.5 * v_xx
            r_v = v_t_ - 0.5 * u_xx
            u_ic, v_ic = model(xt_ic_lb)
            pde = mse(r_u, torch.zeros_like(r_u)) + mse(r_v, torch.zeros_like(r_v))
            ic = mse(u_ic, u_t_lb) + mse(v_ic, v_t_lb)
            loss = LAM["pde"] * pde + LAM["ic"] * ic
            loss.backward()
            return loss
        for _ in range(LBFGS_STEPS):
            opt2.step(closure)
    return time.perf_counter() - t0


def main():
    print(f"torch {torch.__version__} | merlin {ML.__version__} | device {DEVICE}")
    p_phot = n_trainable(SchroPhotonicPlus())
    p_cls  = n_trainable(SchroClassicalPlus())
    p_q    = sum(p.numel() for p in SchroPhotonicPlus().quantum.parameters())
    p_m    = sum(p.numel() for p in SchroClassicalPlus().middle.parameters())
    print(f"Photonic block params: {p_q}   Classical drop-in params: {p_m}")
    print(f"Total trainable: photonic={p_phot}, classical={p_cls}")
    assert p_phot == p_cls and p_q == p_m

    results = dict(photonic=[], classical=[])
    fields = {}

    print("=" * 80)
    for seed in SEEDS:
        print(f"\n=== seed {seed} ===")
        torch.manual_seed(seed); np.random.seed(seed)
        mp = SchroPhotonicPlus().to(DEVICE)
        for p in mp.parameters():
            if p.is_floating_point(): p.data = p.data.to(DTYPE)
        dt_p = train(mp, seed=seed)
        m_p, rho_p, rho_t = metrics(lambda xt: mp(xt))
        print(f"  Photonic   |psi|^2 RMSE={m_p['rmse']:.3e} NMSE={m_p['nmse']:.3e} "
              f"Linf={m_p['linf']:.3e} time={dt_p:.1f}s")
        results["photonic"].append(dict(**m_p, train_time_s=dt_p))
        fields["photonic"] = (rho_p, rho_t)

        torch.manual_seed(seed); np.random.seed(seed)
        mc = SchroClassicalPlus().to(DEVICE)
        for p in mc.parameters():
            if p.is_floating_point(): p.data = p.data.to(DTYPE)
        dt_c = train(mc, seed=seed)
        m_c, rho_c, _ = metrics(lambda xt: mc(xt))
        print(f"  Classical  |psi|^2 RMSE={m_c['rmse']:.3e} NMSE={m_c['nmse']:.3e} "
              f"Linf={m_c['linf']:.3e} time={dt_c:.1f}s")
        results["classical"].append(dict(**m_c, train_time_s=dt_c))
        fields["classical"] = (rho_c, rho_t)

    rs_q = np.array([r["rmse"] for r in results["photonic"]])
    rs_c = np.array([r["rmse"] for r in results["classical"]])
    li_q = np.array([r["linf"] for r in results["photonic"]])
    li_c = np.array([r["linf"] for r in results["classical"]])
    tt_q = np.mean([r["train_time_s"] for r in results["photonic"]])
    tt_c = np.mean([r["train_time_s"] for r in results["classical"]])
    ratio = float(np.exp(np.mean(np.log(rs_c / rs_q))))

    print("\n" + "=" * 80)
    print(f"{'variant':22s} {'RMSE mean':>11s} {'RMSE std':>11s} {'Linf mean':>11s} {'time(s)':>9s}")
    print("-" * 80)
    print(f"{'SchroPhotonicPlus':22s} {rs_q.mean():>11.3e} {rs_q.std():>11.3e} "
          f"{li_q.mean():>11.3e} {tt_q:>9.1f}")
    print(f"{'SchroClassicalPlus':22s} {rs_c.mean():>11.3e} {rs_c.std():>11.3e} "
          f"{li_c.mean():>11.3e} {tt_c:>9.1f}")
    print("=" * 80)
    print(f"Geometric ratio classical/photonic = {ratio:.3f}x   (>1 means photonic better)")

    summary = dict(
        photonic=dict(rmse_mean=float(rs_q.mean()), rmse_std=float(rs_q.std()),
                      linf_mean=float(li_q.mean()), time_mean=float(tt_q),
                      per_seed=results["photonic"]),
        classical=dict(rmse_mean=float(rs_c.mean()), rmse_std=float(rs_c.std()),
                       linf_mean=float(li_c.mean()), time_mean=float(tt_c),
                       per_seed=results["classical"]),
        ratio_classical_over_photonic=ratio,
        params=dict(x0=X0, k0=K0, sigma=SIGMA),
    )
    with open("exp2_schrodinger.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("\nWrote exp2_schrodinger.json")

    # Plot
    rho_p, rho_t = fields["photonic"]
    rho_c, _ = fields["classical"]
    fig, axes = plt.subplots(2, 3, figsize=(13, 7))
    vmax = max(rho_t.max(), rho_p.max(), rho_c.max())
    err_p = np.abs(rho_p - rho_t)
    err_c = np.abs(rho_c - rho_t)
    emax = max(err_p.max(), err_c.max(), 1e-9)

    axes[0, 0].imshow(rho_t, origin="lower", aspect="auto", vmin=0, vmax=vmax,
                      extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="viridis")
    axes[0, 0].set_title("Analytic |psi|^2(x,t)")
    axes[0, 1].imshow(rho_p, origin="lower", aspect="auto", vmin=0, vmax=vmax,
                      extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="viridis")
    axes[0, 1].set_title("Photonic prediction (last seed)")
    axes[0, 2].imshow(rho_c, origin="lower", aspect="auto", vmin=0, vmax=vmax,
                      extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="viridis")
    axes[0, 2].set_title("Classical prediction (last seed)")
    axes[1, 0].axis("off")
    axes[1, 1].imshow(err_p, origin="lower", aspect="auto", vmin=0, vmax=emax,
                      extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="magma")
    axes[1, 1].set_title(f"|err photonic|  max={err_p.max():.2e}")
    axes[1, 2].imshow(err_c, origin="lower", aspect="auto", vmin=0, vmax=emax,
                      extent=[T_MIN, T_MAX, X_MIN, X_MAX], cmap="magma")
    axes[1, 2].set_title(f"|err classical|  max={err_c.max():.2e}")
    fig.suptitle(f"Schroedinger free-particle Gaussian (x0={X0}, k0={K0}, sigma={SIGMA})")
    plt.tight_layout()
    plt.savefig("exp2_schrodinger.png", dpi=140, bbox_inches="tight")
    print("Wrote exp2_schrodinger.png")


if __name__ == "__main__":
    main()
