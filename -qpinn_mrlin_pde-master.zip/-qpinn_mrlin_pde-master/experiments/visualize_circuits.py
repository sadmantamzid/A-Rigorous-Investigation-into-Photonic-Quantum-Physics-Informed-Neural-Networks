"""
visualize_circuits.py
---------------------
Renders photonic circuit diagrams for all QPINN architectures using
Perceval's built-in pdisplay_to_file.

Circuits rendered
-----------------
  1. DataReuploadQPINN  — baseline (5m-2p, q_depth=2, state=[1,0,1,0,0])
  2. AdvancedQPINN Q_init — entangled input (6m-3p, q_depth=2, state=[1,1,1,0,0,0])
  3. AdvancedQPINN Q_loop — photon loop (6m-3p, q_depth=3, state=[1,0,1,0,1,0])
  4. AdvancedQPINN full   — Q_init + Q_loop stitched together
  5. Haar-scrambled block — one layer of Q_init with Haar interferometer

Output: results/circuits/  (PNG + SVG via matplotlib and TEXT)
"""

import os, math, sys
import numpy as np
import perceval as pcvl
import merlin as ML       # noqa: F401 — import after perceval
from merlin.core.components import BeamSplitter, Rotation, ParameterRole

# ── Output directory ──────────────────────────────────────────────────────────
_here  = os.path.abspath(os.path.dirname(__file__))
_root  = os.path.join(_here, "..")
OUTDIR = os.path.join(_root, "results", "circuits")
os.makedirs(OUTDIR, exist_ok=True)
print(f"Output dir: {OUTDIR}\n")


# ══════════════════════════════════════════════════════════════════════════════
# Helper: build circuits
# ══════════════════════════════════════════════════════════════════════════════

def _add_haar_scrambler(builder, n_modes, seed=42):
    """Brick-wall Haar-random interferometer (fixed phases)."""
    rng = np.random.default_rng(int(seed))
    for col in range(n_modes - 1):
        start = col % 2
        for row in range(start, n_modes - 1, 2):
            builder.circuit.add(BeamSplitter(
                targets=(row, row + 1),
                theta_role=ParameterRole.FIXED,
                theta_value=float(rng.uniform(0, math.pi)),
                phi_role=ParameterRole.FIXED,
                phi_value=float(rng.uniform(0, 2 * math.pi)),
            ))
    for m in range(n_modes):
        builder.circuit.add(Rotation(
            target=m, role=ParameterRole.FIXED,
            value=float(rng.uniform(0, 2 * math.pi)), axis="z",
        ))


def make_builder(n_modes, feature_size, q_depth, haar=False, haar_seed=7):
    b = ML.CircuitBuilder(n_modes=n_modes)
    for d in range(q_depth):
        b.add_angle_encoding(
            modes=list(range(feature_size)),
            name=f"enc_{d}", subset_combinations=False)
        b.add_entangling_layer(trainable=True, name=f"ent_{d}")
        if haar:
            _add_haar_scrambler(b, n_modes, seed=haar_seed + d * 997)
    return b


def make_ql(n_modes, n_photons, feature_size, input_state, q_depth,
            haar=False, haar_seed=7):
    b = make_builder(n_modes, feature_size, q_depth, haar, haar_seed)
    return ML.QuantumLayer(
        input_size=feature_size * q_depth,
        input_state=input_state,
        n_photons=n_photons,
        builder=b,
        measurement_strategy=ML.MeasurementStrategy.PROBABILITIES,
        computation_space=ML.ComputationSpace.UNBUNCHED,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Rendering helpers
# ══════════════════════════════════════════════════════════════════════════════

def save_circuit(circ_or_exp, name, formats=("png", "txt")):
    """
    Render a Perceval circuit or Experiment to file.
    formats: subset of ("png", "txt", "html", "latex")
    """
    fmt_map = {
        "png":   pcvl.Format.MPLOT,
        "txt":   pcvl.Format.TEXT,
        "html":  pcvl.Format.HTML,
        "latex": pcvl.Format.LATEX,
    }
    for fmt in formats:
        ext  = fmt
        path = os.path.join(OUTDIR, f"{name}.{ext}")
        try:
            pcvl.pdisplay_to_file(
                circ_or_exp,
                path=path,
                output_format=fmt_map[fmt],
            )
            print(f"  ✓  {os.path.basename(path)}")
        except Exception as e:
            print(f"  ✗  {os.path.basename(path)}: {e}")


def print_text(circ_or_exp, label):
    """Print ASCII circuit diagram to stdout."""
    print(f"\n{'─'*60}")
    print(f"  {label}")
    print(f"{'─'*60}")
    try:
        txt = pcvl.pdisplay(circ_or_exp, output_format=pcvl.Format.TEXT)
        print(txt)
    except Exception as e:
        print(f"  (text render failed: {e})")


# ══════════════════════════════════════════════════════════════════════════════
# 1. DataReuploadQPINN  —  baseline (5m-2p)
# ══════════════════════════════════════════════════════════════════════════════
print("="*60)
print("1. DataReuploadQPINN  (5m-2p, q_depth=2, state=[1,0,1,0,0])")
print("="*60)

ql_base = make_ql(
    n_modes=5, n_photons=2, feature_size=4,
    input_state=[1, 0, 1, 0, 0],
    q_depth=2, haar=True, haar_seed=42,
)

circ_base = ql_base.circuit                  # perceval.Circuit
exp_base  = ql_base.get_experiment()         # perceval.Experiment (includes input state)

print_text(circ_base, "DataReuploadQPINN circuit (5 modes, 2 photons, q_depth=2)")
save_circuit(circ_base, "01_DataReupload_circuit", formats=("png", "txt"))
save_circuit(exp_base,  "01_DataReupload_experiment", formats=("png",))


# ══════════════════════════════════════════════════════════════════════════════
# 2. AdvancedQPINN — Q_init  (6m-3p, entangled input [1,1,1,0,0,0])
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*60)
print("2. AdvancedQPINN Q_init  (6m-3p, q_depth=2, state=[1,1,1,0,0,0])")
print("="*60)

ql_init = make_ql(
    n_modes=6, n_photons=3, feature_size=4,
    input_state=[1, 1, 1, 0, 0, 0],
    q_depth=2, haar=True, haar_seed=7,
)

print_text(ql_init.circuit, "Q_init circuit (entangled input, 6 modes, 3 photons, q_depth=2)")
save_circuit(ql_init.circuit,          "02_AdvQPINN_Qinit_circuit",    formats=("png", "txt"))
save_circuit(ql_init.get_experiment(), "02_AdvQPINN_Qinit_experiment",  formats=("png",))


# ══════════════════════════════════════════════════════════════════════════════
# 3. AdvancedQPINN — Q_loop  (6m-3p, alternating [1,0,1,0,1,0], q_depth=3)
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*60)
print("3. AdvancedQPINN Q_loop  (6m-3p, q_depth=3, state=[1,0,1,0,1,0])")
print("="*60)

ql_loop = make_ql(
    n_modes=6, n_photons=3, feature_size=4,
    input_state=[1, 0, 1, 0, 1, 0],
    q_depth=3, haar=True, haar_seed=13,
)

print_text(ql_loop.circuit, "Q_loop circuit (photon loop, 6 modes, 3 photons, q_depth=3)")
save_circuit(ql_loop.circuit,          "03_AdvQPINN_Qloop_circuit",    formats=("png", "txt"))
save_circuit(ql_loop.get_experiment(), "03_AdvQPINN_Qloop_experiment",  formats=("png",))


# ══════════════════════════════════════════════════════════════════════════════
# 4. Side-by-side: Q_init vs Q_loop  (highlight different input states)
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*60)
print("4. Entangled input comparison: [1,1,1,0,0,0] vs [1,0,1,0,1,0]")
print("="*60)

# Build bare circuits (no Haar, just encoding+entangling) for cleaner comparison
b_consec  = make_builder(6, 4, q_depth=2, haar=False)  # consecutive spread
b_altern  = make_builder(6, 4, q_depth=2, haar=False)  # alternating spread

ql_consec = ML.QuantumLayer(input_size=8, input_state=[1,1,1,0,0,0], n_photons=3,
    builder=b_consec, measurement_strategy=ML.MeasurementStrategy.PROBABILITIES,
    computation_space=ML.ComputationSpace.UNBUNCHED)

ql_altern = ML.QuantumLayer(input_size=8, input_state=[1,0,1,0,1,0], n_photons=3,
    builder=b_altern, measurement_strategy=ML.MeasurementStrategy.PROBABILITIES,
    computation_space=ML.ComputationSpace.UNBUNCHED)

print_text(ql_consec.get_experiment(),
           "Consecutive spread [1,1,1,0,0,0] — Q_init (entangled)")
print_text(ql_altern.get_experiment(),
           "Alternating spread [1,0,1,0,1,0] — Q_loop (photon loop)")

save_circuit(ql_consec.get_experiment(), "04a_input_consecutive_111000", formats=("png",))
save_circuit(ql_altern.get_experiment(), "04b_input_alternating_101010", formats=("png",))


# ══════════════════════════════════════════════════════════════════════════════
# 5. Haar scrambler detail — one encoding layer + entangling + Haar block
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*60)
print("5. Haar scrambler detail  (6m-3p, q_depth=1, Haar seed=7)")
print("="*60)

ql_haar = make_ql(
    n_modes=6, n_photons=3, feature_size=4,
    input_state=[1, 1, 1, 0, 0, 0],
    q_depth=1, haar=True, haar_seed=7,
)

print_text(ql_haar.circuit, "Single layer with Haar scrambler (enc → ent → Haar)")
save_circuit(ql_haar.circuit,          "05_Haar_scrambler_circuit",    formats=("png", "txt"))
save_circuit(ql_haar.get_experiment(), "05_Haar_scrambler_experiment",  formats=("png",))


# ══════════════════════════════════════════════════════════════════════════════
# 6. Summary: print output_size information
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*60)
print("Circuit dimensions summary")
print("="*60)
circuits = [
    ("DataReupload (5m-2p, qd=2)", ql_base),
    ("Q_init (6m-3p, qd=2)",       ql_init),
    ("Q_loop (6m-3p, qd=3)",       ql_loop),
    ("Haar-detail (6m-3p, qd=1)",  ql_haar),
]
from math import comb
for label, ql in circuits:
    n  = ql.n_photons
    m  = ql.circuit.m
    nc = ql.circuit.ncomponents
    print(f"  {label:35s}  modes={m}  photons={n}  "
          f"output={ql.output_size}  ncomponents={nc}")

print(f"\nAll diagrams saved to: {OUTDIR}/")
print("Files: 01–05 (circuit = just gates, experiment = gates + input state)")


# ══════════════════════════════════════════════════════════════════════════════
# 7. Consolidated matplotlib figure — architecture overview
# ══════════════════════════════════════════════════════════════════════════════

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import matplotlib.patches as mpatches

fig = plt.figure(figsize=(20, 14))
fig.patch.set_facecolor("#f7f7f7")

# ── Row 1: DataReupload circuit ───────────────────────────────────────────────
ax1 = fig.add_axes([0.02, 0.67, 0.95, 0.28])
try:
    img = mpimg.imread(os.path.join(OUTDIR, "01_DataReupload_circuit.png"))
    ax1.imshow(img)
    ax1.set_title(
        "DataReuploadQPINN  (5 modes, 2 photons, q_depth=2,  input=[1,0,1,0,0])\n"
        "CPLX = angle encoding (trainable phase shifters on modes 0-3)  |  "
        "BS.Rx = Mach-Zehnder interferometer  |  Φ = phase shifter",
        fontsize=9, loc="left", pad=4)
except Exception as e:
    ax1.text(0.5, 0.5, f"(image load failed: {e})", ha="center", va="center")
ax1.axis("off")

# ── Row 2: Q_init (left) and Haar scrambler detail (right) ───────────────────
ax2a = fig.add_axes([0.02, 0.35, 0.52, 0.28])
try:
    img = mpimg.imread(os.path.join(OUTDIR, "02_AdvQPINN_Qinit_circuit.png"))
    ax2a.imshow(img)
    ax2a.set_title(
        "AdvancedQPINN — Q_init\n"
        "6 modes, 3 photons, q_depth=2\n"
        "input = [1,1,1,0,0,0]  ← entangled spread",
        fontsize=9, loc="left", pad=4)
except Exception as e:
    ax2a.text(0.5, 0.5, str(e), ha="center", va="center")
ax2a.axis("off")

ax2b = fig.add_axes([0.54, 0.35, 0.44, 0.28])
try:
    img = mpimg.imread(os.path.join(OUTDIR, "05_Haar_scrambler_circuit.png"))
    ax2b.imshow(img)
    ax2b.set_title(
        "Haar scrambler detail (1 layer)\n"
        "6 modes, 3 photons, q_depth=1\n"
        "Brick-wall MZI mesh — fixed random phases",
        fontsize=9, loc="left", pad=4)
except Exception as e:
    ax2b.text(0.5, 0.5, str(e), ha="center", va="center")
ax2b.axis("off")

# ── Row 3: Q_loop ─────────────────────────────────────────────────────────────
ax3 = fig.add_axes([0.02, 0.03, 0.95, 0.28])
try:
    img = mpimg.imread(os.path.join(OUTDIR, "03_AdvQPINN_Qloop_circuit.png"))
    ax3.imshow(img)
    ax3.set_title(
        "AdvancedQPINN — Q_loop  (photon loop via data reuploading)\n"
        "6 modes, 3 photons, q_depth=3,  input=[1,0,1,0,1,0]  ← alternating spread\n"
        "3 encoding+entangling+Haar blocks in sequence → photon traverses circuit 3 times",
        fontsize=9, loc="left", pad=4)
except Exception as e:
    ax3.text(0.5, 0.5, str(e), ha="center", va="center")
ax3.axis("off")

# ── Input state annotation insets ─────────────────────────────────────────────
def draw_fock_state(ax, state, x0, y0, scale=0.012, label=""):
    """Draw photon-number state as circles on mode lines."""
    n = len(state)
    for i, occ in enumerate(state):
        y = y0 - i * scale
        ax.plot([x0, x0 + scale*3], [y, y],
                color="#888", lw=0.8, transform=ax.transAxes)
        if occ:
            circ = plt.Circle((x0 + scale*1.5, y), scale*0.4,
                               color="#4C72B0", zorder=5, transform=ax.transAxes,
                               clip_on=False)
            ax.add_patch(circ)
    if label:
        ax.text(x0 + scale*3.5, y0 - (n//2)*scale, label,
                fontsize=7, va="center", transform=ax.transAxes)

plt.suptitle(
    "Photonic Circuit Diagrams — QPINN Architectures\n"
    "Generated with Perceval pdisplay  |  Merlin 0.2.3  |  exp7_advanced_qpinn",
    fontsize=11, y=0.995, fontweight="bold")

out_consolidated = os.path.join(OUTDIR, "00_overview.png")
plt.savefig(out_consolidated, dpi=150, bbox_inches="tight",
            facecolor=fig.get_facecolor())
plt.close()
print(f"\n  ✓  00_overview.png  (consolidated figure)")

# ── Input-state comparison: side-by-side photon positions ────────────────────
fig2, axes = plt.subplots(1, 2, figsize=(14, 6))
fig2.patch.set_facecolor("#f9f9f9")

for ax, fname, title in [
    (axes[0], "04a_input_consecutive_111000.png",
     "Q_init:  input=[1,1,1,0,0,0]\n(consecutive modes — strong HOM at adjacent BS)"),
    (axes[1], "04b_input_alternating_101010.png",
     "Q_loop:  input=[1,0,1,0,1,0]\n(alternating modes — HOM across longer paths)"),
]:
    try:
        img = mpimg.imread(os.path.join(OUTDIR, fname))
        ax.imshow(img)
        ax.set_title(title, fontsize=10, pad=6)
    except Exception as e:
        ax.text(0.5, 0.5, str(e), ha="center", va="center", transform=ax.transAxes)
    ax.axis("off")

plt.suptitle(
    "Entangled Input State Comparison\n"
    "Different photon spreads → different Hong-Ou-Mandel interference → decorrelated features",
    fontsize=10, y=1.01)
plt.tight_layout()
out_states = os.path.join(OUTDIR, "00_input_states.png")
plt.savefig(out_states, dpi=150, bbox_inches="tight",
            facecolor=fig2.get_facecolor())
plt.close()
print(f"  ✓  00_input_states.png  (entangled state comparison)")
print(f"\nAll files in: {OUTDIR}/")
