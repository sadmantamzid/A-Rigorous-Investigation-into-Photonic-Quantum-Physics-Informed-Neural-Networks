"""
Experiment 4: Sample-efficiency curve.

Hypothesis: an inductive-bias advantage from the photonic block (if any) should be
strongest in the few-collocation-points regime — because a model with the right
priors needs less data.

Method: sweep interior collocation points n_f in {16, 32, 64, 128, 256}, holding
n_i and n_b fixed, holding all training hyperparameters fixed. Run MerLin_QPINN_Plus
and Classical_Plus side-by-side, 3 seeds each. Report RMSE(n_f).

If photonic has better inductive bias: the photonic curve should sit below the
classical curve, especially at small n_f. If they overlap: no inductive-bias advantage.
"""
import time, json, math
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

from benchmark_qpinn_vs_pinn import (
    DTYPE, DEVICE, SEEDS, PRETRAIN, EPOCHS, LBFGS_STEPS, LR_ADAM, ALPHA_D,
    X_MIN, X_MAX, T_MIN, T_MAX,
    MerlinQPINN_Plus, paper_metrics, n_trainable, _hard_bc, _pred_nested,
    sobol_xt, sobol_x, _ic_batch, _bc_batch, _grad, _reset_sobol, T0_torch,
    LAM_NESTED,
)
from ablation_photonic_vs_classical import ClassicalPlus


def loss_nested_nf(model, n_f, n_i=128, n_b=64, lam=LAM_NESTED):
    xt_f = sobol_xt(n_f); xt_f.requires_grad_(True)
    xt_ic, x_ic = _ic_batch(n_i)
    xt_b = _bc_batch(n_b)
    T = model(xt_f)
    g = _grad(T, xt_f); T_x, T_t = g[:, 0:1], g[:, 1:2]
    T_xx = _grad(T_x, xt_f)[:, 0:1]
    r_pde = T_t - ALPHA_D * T_xx
    T_ic = model(xt_ic)
    T_bv = model(xt_b)
    mse = nn.MSELoss()
    return (lam["pde"] * mse(r_pde, torch.zeros_like(r_pde))
            + lam["ic"] * mse(T_ic, T0_torch(x_ic))
            + lam["bc"] * mse(T_bv, torch.zeros_like(T_bv)))


def train_with_nf(model, *, n_f, seed, pretrain=PRETRAIN, epochs=EPOCHS,
                  lr=LR_ADAM, lbfgs_steps=LBFGS_STEPS):
    _reset_sobol(seed)
    torch.manual_seed(seed); np.random.seed(seed)
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=lr)
    t0 = time.perf_counter()
    for e in range(pretrain):
        opt.zero_grad()
        xt_ic, x_ic = _ic_batch(128)
        out = model(xt_ic)
        T_ic = out[0] if isinstance(out, tuple) else out
        loss = nn.MSELoss()(T_ic, T0_torch(x_ic))
        loss.backward(); opt.step()
    for e in range(epochs):
        opt.zero_grad()
        loss = loss_nested_nf(model, n_f=n_f)
        loss.backward(); opt.step()

    if lbfgs_steps > 0:
        # LBFGS still uses a richer 512-point Sobol set so the finetune phase
        # is fair across all n_f levels (only Adam's stochastic gradient signal
        # is starved by small n_f).
        _reset_sobol(seed + 9999)
        xt_f = sobol_xt(512); xt_f.requires_grad_(True)
        xt_ic_lb, x_ic_lb = _ic_batch(256)
        xt_b_lb = _bc_batch(128)
        opt2 = torch.optim.LBFGS(
            [p for p in model.parameters() if p.requires_grad],
            lr=1.0, max_iter=20, history_size=50, tolerance_grad=1e-9,
            tolerance_change=1e-12, line_search_fn="strong_wolfe",
        )
        mse = nn.MSELoss()

        def closure():
            opt2.zero_grad()
            T = model(xt_f); T = T[0] if isinstance(T, tuple) else T
            g = _grad(T, xt_f); T_x, T_t = g[:, 0:1], g[:, 1:2]
            T_xx = _grad(T_x, xt_f)[:, 0:1]
            r_pde = T_t - ALPHA_D * T_xx
            T_ic = model(xt_ic_lb); T_ic = T_ic[0] if isinstance(T_ic, tuple) else T_ic
            T_bv = model(xt_b_lb);  T_bv = T_bv[0] if isinstance(T_bv, tuple) else T_bv
            loss = (LAM_NESTED["pde"] * mse(r_pde, torch.zeros_like(r_pde))
                    + LAM_NESTED["ic"] * mse(T_ic, T0_torch(x_ic_lb))
                    + LAM_NESTED["bc"] * mse(T_bv, torch.zeros_like(T_bv)))
            loss.backward()
            return loss

        for _ in range(lbfgs_steps):
            opt2.step(closure)

    return time.perf_counter() - t0


def main():
    print(f"torch {torch.__version__} | device {DEVICE}")
    NF_LEVELS = [16, 32, 64, 128, 256]
    print(f"Sweep n_f in {NF_LEVELS}; 3 seeds each variant.")

    results = {nf: dict(photonic=[], classical=[]) for nf in NF_LEVELS}

    for nf in NF_LEVELS:
        print(f"\n=== n_f = {nf} ===")
        for seed in SEEDS:
            print(f"  seed {seed} ", end="", flush=True)
            torch.manual_seed(seed); np.random.seed(seed)
            mp = MerlinQPINN_Plus().to(DEVICE)
            for p in mp.parameters():
                if p.is_floating_point():
                    p.data = p.data.to(DTYPE)
            dt_p = train_with_nf(mp, n_f=nf, seed=seed)
            metrics_p, _, _ = paper_metrics(_pred_nested(mp))
            print(f"| Photonic RMSE={metrics_p['rmse']:.3e} t={dt_p:.1f}s ", end="", flush=True)
            results[nf]["photonic"].append(dict(**metrics_p, train_time_s=dt_p))

            torch.manual_seed(seed); np.random.seed(seed)
            mc = ClassicalPlus().to(DEVICE)
            for p in mc.parameters():
                if p.is_floating_point():
                    p.data = p.data.to(DTYPE)
            dt_c = train_with_nf(mc, n_f=nf, seed=seed)
            metrics_c, _, _ = paper_metrics(_pred_nested(mc))
            print(f"| Classical RMSE={metrics_c['rmse']:.3e} t={dt_c:.1f}s")
            results[nf]["classical"].append(dict(**metrics_c, train_time_s=dt_c))

    # Summary
    print("\n" + "=" * 92)
    print(f"{'n_f':>5s} {'RMSE_q mean':>13s} {'RMSE_q std':>12s} "
          f"{'RMSE_c mean':>13s} {'RMSE_c std':>12s} {'ratio_c/q':>11s} {'time_q':>8s} {'time_c':>8s}")
    print("-" * 92)
    summary = {}
    for nf in NF_LEVELS:
        rs_q = np.array([m["rmse"] for m in results[nf]["photonic"]])
        rs_c = np.array([m["rmse"] for m in results[nf]["classical"]])
        tt_q = np.mean([m["train_time_s"] for m in results[nf]["photonic"]])
        tt_c = np.mean([m["train_time_s"] for m in results[nf]["classical"]])
        ratio = float(np.exp(np.mean(np.log(rs_c / rs_q))))
        summary[nf] = dict(
            rmse_q_mean=float(rs_q.mean()), rmse_q_std=float(rs_q.std()),
            rmse_c_mean=float(rs_c.mean()), rmse_c_std=float(rs_c.std()),
            ratio_c_over_q=ratio, time_q=float(tt_q), time_c=float(tt_c),
        )
        print(f"{nf:>5d} {rs_q.mean():>13.3e} {rs_q.std():>12.3e} "
              f"{rs_c.mean():>13.3e} {rs_c.std():>12.3e} {ratio:>11.3f} "
              f"{tt_q:>8.1f} {tt_c:>8.1f}")
    print("=" * 92)
    print("ratio_c/q > 1 means photonic better (less data more accurate).")

    with open("exp4_sample_efficiency.json", "w") as f:
        json.dump({str(k): v for k, v in summary.items()}, f, indent=2)
    print("\nWrote exp4_sample_efficiency.json")

    # Plot
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    nfs = NF_LEVELS
    rmse_q = [summary[nf]["rmse_q_mean"] for nf in nfs]
    rmse_c = [summary[nf]["rmse_c_mean"] for nf in nfs]
    err_q  = [summary[nf]["rmse_q_std"] for nf in nfs]
    err_c  = [summary[nf]["rmse_c_std"] for nf in nfs]

    ax[0].errorbar(nfs, rmse_q, yerr=err_q, fmt="o-", capsize=4,
                   label="MerLin_QPINN_Plus (photonic)", color="#d62728")
    ax[0].errorbar(nfs, rmse_c, yerr=err_c, fmt="s-", capsize=4,
                   label="Classical_Plus (matched MLP)", color="#666")
    ax[0].set_xlabel("interior collocation points n_f"); ax[0].set_ylabel("RMSE (mean+/-std)")
    ax[0].set_xscale("log"); ax[0].set_yscale("log")
    ax[0].set_title("Sample efficiency (lower curve = better)")
    ax[0].legend()

    ratios = [summary[nf]["ratio_c_over_q"] for nf in nfs]
    ax[1].axhline(1.0, ls="--", c="k", lw=0.7, label="parity")
    ax[1].plot(nfs, ratios, "o-", color="#1f77b4")
    ax[1].set_xlabel("n_f"); ax[1].set_ylabel("RMSE ratio (classical / photonic)")
    ax[1].set_xscale("log")
    ax[1].set_title("Photonic advantage at scarcer data (>1 means photonic wins)")
    ax[1].legend()
    plt.tight_layout()
    plt.savefig("exp4_sample_efficiency.png", dpi=140, bbox_inches="tight")
    print("Wrote exp4_sample_efficiency.png")


if __name__ == "__main__":
    main()
