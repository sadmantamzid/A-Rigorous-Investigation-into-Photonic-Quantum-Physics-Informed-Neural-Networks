"""
Post-hoc summary of exp1_photon_scaling: parses exp1_run.log (the experiment was
terminated before its in-script summary cell ran, because config 4 would have
taken hours and config 3 already showed the pattern).

Produces a JSON summary and a bar plot.
"""
import re
import json
import numpy as np
import matplotlib.pyplot as plt

with open("exp1_run.log") as f:
    log = f.read()

# Parse blocks per config
config_re = re.compile(
    r"### Config (\([^)]+\)): modes=(\d+), photons=(\d+), depth=(\d+), feature_size=(\d+)\n"
    r"  photonic block params \(q\+proj_out\): (\d+).*?q_out_dim=(\d+).*?\n"
    r"  classical drop-in: MLP feature->(\d+)->4\n"
    r"  total trainable: photonic=(\d+), classical=(\d+)",
    re.S,
)
seed_re = re.compile(
    r"  seed (\d+) \.\.\.\n"
    r"    Photonic\s+RMSE=([\d.eE+-]+) NMSE=([\d.eE+-]+) time=([\d.]+)s\n"
    r"    Classical\s+RMSE=([\d.eE+-]+) NMSE=([\d.eE+-]+) time=([\d.]+)s",
    re.S,
)

# Split log by config headers
parts = log.split("### Config ")[1:]  # first part is preamble
all_results = []
for part in parts:
    head = "### Config " + part
    m = config_re.search(head)
    if not m:
        continue
    label, n_modes, n_photons, q_depth, fs, qblk, qdim, mid, tot_q, tot_c = m.groups()
    rec = dict(
        label=label, n_modes=int(n_modes), n_photons=int(n_photons),
        q_depth=int(q_depth), feature_size=int(fs),
        q_block_params=int(qblk), q_out_dim=int(qdim),
        cls_mid=int(mid), total_q=int(tot_q), total_c=int(tot_c),
        seeds=[],
    )
    for sm in seed_re.finditer(head):
        seed, rmse_q, nmse_q, t_q, rmse_c, nmse_c, t_c = sm.groups()
        rec["seeds"].append(dict(
            seed=int(seed),
            rmse_q=float(rmse_q), nmse_q=float(nmse_q), time_q=float(t_q),
            rmse_c=float(rmse_c), nmse_c=float(nmse_c), time_c=float(t_c),
        ))
    all_results.append(rec)

print(f"Parsed {len(all_results)} configs from exp1_run.log")
print("=" * 110)
print(f"{'config':18s} {'modes':>6s} {'phot':>5s} {'q_dim':>6s} "
      f"{'tot_q':>6s} {'seeds':>6s} {'RMSE_q':>11s} {'RMSE_c':>11s} {'ratio (c/q)':>13s} "
      f"{'time_q':>8s} {'time_c':>8s}")
print("-" * 110)

summary = []
for r in all_results:
    if not r["seeds"]:
        print(f"{r['label']:18s}  (no completed seeds)")
        continue
    rs_q = np.array([s["rmse_q"] for s in r["seeds"]])
    rs_c = np.array([s["rmse_c"] for s in r["seeds"]])
    tt_q = np.mean([s["time_q"] for s in r["seeds"]])
    tt_c = np.mean([s["time_c"] for s in r["seeds"]])
    ratio = float(np.exp(np.mean(np.log(rs_c / rs_q))))
    summary.append(dict(
        label=r["label"], n_modes=r["n_modes"], n_photons=r["n_photons"],
        q_depth=r["q_depth"], feature_size=r["feature_size"],
        q_block_params=r["q_block_params"], q_out_dim=r["q_out_dim"],
        total_q=r["total_q"], total_c=r["total_c"],
        n_seeds=len(r["seeds"]),
        rmse_q_mean=float(rs_q.mean()), rmse_q_std=float(rs_q.std()),
        rmse_c_mean=float(rs_c.mean()), rmse_c_std=float(rs_c.std()),
        ratio_c_over_q=ratio,
        time_q=float(tt_q), time_c=float(tt_c),
        per_seed=r["seeds"],
    ))
    print(f"{r['label']:18s} {r['n_modes']:>6d} {r['n_photons']:>5d} {r['q_out_dim']:>6d} "
          f"{r['total_q']:>6d} {len(r['seeds']):>6d} "
          f"{rs_q.mean():>11.3e} {rs_c.mean():>11.3e} {ratio:>13.3f} "
          f"{tt_q:>8.1f} {tt_c:>8.1f}")
print("=" * 110)
print("ratio = exp(mean(log(rmse_classical / rmse_photonic)))   >1 means photonic better")

with open("exp1_photon_scaling.json", "w") as f:
    json.dump(summary, f, indent=2)
print("\nWrote exp1_photon_scaling.json (post-hoc)")

# Plot
fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))
xs = [s["q_block_params"] for s in summary]
labels = [s["label"] for s in summary]
rmse_q = [s["rmse_q_mean"] for s in summary]
rmse_c = [s["rmse_c_mean"] for s in summary]
err_q = [s["rmse_q_std"]  for s in summary]
err_c = [s["rmse_c_std"]  for s in summary]
ratios = [s["ratio_c_over_q"] for s in summary]

ax[0].errorbar(xs, rmse_q, yerr=err_q, fmt="o-", capsize=4,
               label="MerLin (photonic)", color="#d62728")
ax[0].errorbar(xs, rmse_c, yerr=err_c, fmt="s-", capsize=4,
               label="Classical drop-in", color="#666")
for x, lab, ymax in zip(xs, labels,
                        [max(rmse_q[i], rmse_c[i]) for i in range(len(xs))]):
    ax[0].annotate(lab, (x, ymax * 1.10), fontsize=7, rotation=12, ha="left")
ax[0].set_xlabel("photonic block params (= matched classical params)")
ax[0].set_ylabel("RMSE (mean +/- std)")
ax[0].set_yscale("log"); ax[0].set_xscale("log")
ax[0].set_title("Accuracy vs photonic scale")
ax[0].legend(fontsize=8)

ax[1].axhline(1.0, ls="--", c="k", lw=0.7, label="parity")
ax[1].plot(xs, ratios, "o-", color="#1f77b4")
for x, lab, r in zip(xs, labels, ratios):
    ax[1].annotate(f"{lab}\n{r:.2f}x", (x, r), fontsize=7, ha="center")
ax[1].set_xlabel("photonic block params"); ax[1].set_xscale("log")
ax[1].set_ylabel("RMSE ratio (classical / photonic)")
ax[1].set_title("Photonic advantage at scale (>1 = photonic wins)")
ax[1].legend(fontsize=8)
plt.tight_layout()
plt.savefig("exp1_photon_scaling.png", dpi=140, bbox_inches="tight")
print("Wrote exp1_photon_scaling.png")
