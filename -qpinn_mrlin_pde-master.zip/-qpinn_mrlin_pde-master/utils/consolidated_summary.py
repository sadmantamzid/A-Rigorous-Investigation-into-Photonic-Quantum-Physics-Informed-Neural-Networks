"""
Consolidated summary across all four "is the photonic block load-bearing?" tests.

Inputs (JSON outputs from prior runs):
  ablation_photonic_results.json  - matched-arch ablation (heat eq)
  exp1_photon_scaling.json        - photonic mode/photon scaling (heat eq)
  exp2_schrodinger.json           - Schroedinger free-particle wavepacket
  exp3_burgers.json               - viscous Burgers' equation (shock)
  exp4_sample_efficiency.json     - n_f sweep (heat eq)

Output:
  consolidated_summary.png        - one-figure overview of all four directions
  consolidated_summary.txt        - text summary table
"""
import json
import numpy as np
import matplotlib.pyplot as plt

with open("ablation_photonic_results.json") as f:
    abl = json.load(f)
with open("exp1_photon_scaling.json") as f:
    e1 = json.load(f)
with open("exp2_schrodinger.json") as f:
    e2 = json.load(f)
with open("exp3_burgers.json") as f:
    e3 = json.load(f)
with open("exp4_sample_efficiency.json") as f:
    e4 = json.load(f)


def ratio(c, q):
    return c / q


fig = plt.figure(figsize=(15, 10))
gs = fig.add_gridspec(2, 2, hspace=0.32, wspace=0.28)

# (a) Exp 1 - mode/photon scaling
ax = fig.add_subplot(gs[0, 0])
xs = [s["q_block_params"] for s in e1]
labels = [s["label"] for s in e1]
rmse_q = [s["rmse_q_mean"] for s in e1]
rmse_c = [s["rmse_c_mean"] for s in e1]
err_q = [s["rmse_q_std"]  for s in e1]
err_c = [s["rmse_c_std"]  for s in e1]
ax.errorbar(xs, rmse_q, yerr=err_q, fmt="o-", capsize=4,
            label="MerLin (photonic)", color="#d62728")
ax.errorbar(xs, rmse_c, yerr=err_c, fmt="s-", capsize=4,
            label="Classical drop-in", color="#444")
for x, lab in zip(xs, labels):
    ax.annotate(lab, (x, max(rmse_q + rmse_c) * 1.4),
                fontsize=7, rotation=12, ha="left")
ax.set_xlabel("photonic block params (matched classical params)")
ax.set_ylabel("RMSE (mean +/- std)")
ax.set_yscale("log"); ax.set_xscale("log")
ax.set_title("(1) Mode/photon scaling — heat eq")
ax.legend(fontsize=8)

# (b) Exp 4 - sample efficiency
ax = fig.add_subplot(gs[0, 1])
nfs = sorted(int(k) for k in e4.keys())
rq = [e4[str(nf)]["rmse_q_mean"] for nf in nfs]
rc = [e4[str(nf)]["rmse_c_mean"] for nf in nfs]
sq = [e4[str(nf)]["rmse_q_std"]  for nf in nfs]
sc = [e4[str(nf)]["rmse_c_std"]  for nf in nfs]
ax.errorbar(nfs, rq, yerr=sq, fmt="o-", capsize=4,
            label="MerLin_QPINN_Plus", color="#d62728")
ax.errorbar(nfs, rc, yerr=sc, fmt="s-", capsize=4,
            label="Classical_Plus", color="#444")
ax.set_xlabel("interior collocation points n_f")
ax.set_ylabel("RMSE (mean +/- std)")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_title("(4) Sample efficiency — heat eq")
ax.legend(fontsize=8)

# (c) Exp 3 - Burgers' eq, paired per-seed
ax = fig.add_subplot(gs[1, 0])
seeds = [r["rmse"] for r in e3["photonic"]["per_seed"]]
seeds_c = [r["rmse"] for r in e3["classical"]["per_seed"]]
labels_s = ["seed 1234", "seed 2024", "seed 7"]
for i, lab in enumerate(labels_s):
    ax.plot([0, 1], [seeds[i], seeds_c[i]], "o-", alpha=0.7, label=lab)
ax.set_xticks([0, 1])
ax.set_xticklabels(["Photonic_Plus", "Classical_Plus"])
ax.set_yscale("log")
ax.set_ylabel("RMSE (Burgers, viscous shock)")
ax.set_title(f"(3) Burgers' eq nu=0.01/pi — geo ratio c/q = "
             f"{e3['ratio_classical_over_photonic']:.2f}x")
ax.legend(fontsize=8)

# (d) Exp 2 - Schrodinger, paired per-seed
ax = fig.add_subplot(gs[1, 1])
seeds = [r["rmse"] for r in e2["photonic"]["per_seed"]]
seeds_c = [r["rmse"] for r in e2["classical"]["per_seed"]]
for i, lab in enumerate(labels_s):
    ax.plot([0, 1], [seeds[i], seeds_c[i]], "o-", alpha=0.7, label=lab)
ax.set_xticks([0, 1])
ax.set_xticklabels(["Photonic_Plus", "Classical_Plus"])
ax.set_yscale("log")
ax.set_ylabel("RMSE on |psi|^2 (Schrodinger free particle)")
ax.set_title(f"(2) Schrodinger — geo ratio c/q = "
             f"{e2['ratio_classical_over_photonic']:.2f}x")
ax.legend(fontsize=8)

fig.suptitle("Does the photonic block provide an advantage? — four controlled tests",
             fontsize=13, y=0.995)
plt.savefig("consolidated_summary.png", dpi=140, bbox_inches="tight")
print("Wrote consolidated_summary.png")


# Text summary
with open("consolidated_summary.txt", "w") as f:
    f.write("Photonic-vs-classical advantage: four controlled tests\n")
    f.write("=" * 70 + "\n\n")

    f.write("(0) Headline ablation (matched arch, heat eq, 3 seeds)\n")
    f.write("-" * 70 + "\n")
    plus_r = abl["MerLin_QPINN_Plus"]["rmse_mean"]
    cls_r  = abl["Classical_Plus"]["rmse_mean"]
    fz_r   = abl["MerLin_FrozenPhotonic"]["rmse_mean"]
    f.write(f"  MerLin_QPINN_Plus       RMSE mean = {plus_r:.3e}\n")
    f.write(f"  Classical_Plus          RMSE mean = {cls_r:.3e}\n")
    f.write(f"  MerLin_FrozenPhotonic   RMSE mean = {fz_r:.3e}\n")
    f.write(f"  ratio classical/photonic = {cls_r/plus_r:.3f}x\n")
    f.write(f"  ratio frozen/trained     = {fz_r/plus_r:.3f}x\n\n")

    f.write("(1) Mode/photon scaling (heat eq)\n")
    f.write("-" * 70 + "\n")
    f.write(f"  {'config':18s} {'q_block':>8s} {'tot':>5s} {'seeds':>5s} "
            f"{'RMSE_q':>11s} {'RMSE_c':>11s} {'c/q':>6s}\n")
    for s in e1:
        f.write(f"  {s['label']:18s} {s['q_block_params']:>8d} {s['total_q']:>5d} "
                f"{s['n_seeds']:>5d} {s['rmse_q_mean']:>11.3e} "
                f"{s['rmse_c_mean']:>11.3e} {s['ratio_c_over_q']:>6.2f}\n")
    f.write("\n")

    f.write("(2) Schroedinger equation (free-particle wavepacket)\n")
    f.write("-" * 70 + "\n")
    f.write(f"  Photonic   |psi|^2 RMSE = {e2['photonic']['rmse_mean']:.3e}"
            f" (std {e2['photonic']['rmse_std']:.2e})\n")
    f.write(f"  Classical  |psi|^2 RMSE = {e2['classical']['rmse_mean']:.3e}"
            f" (std {e2['classical']['rmse_std']:.2e})\n")
    f.write(f"  geo ratio classical/photonic = "
            f"{e2['ratio_classical_over_photonic']:.3f}x\n\n")

    f.write("(3) Burgers' equation (viscous shock, nu=0.01/pi)\n")
    f.write("-" * 70 + "\n")
    f.write(f"  Photonic   RMSE = {e3['photonic']['rmse_mean']:.3e}"
            f" (std {e3['photonic']['rmse_std']:.2e})\n")
    f.write(f"  Classical  RMSE = {e3['classical']['rmse_mean']:.3e}"
            f" (std {e3['classical']['rmse_std']:.2e})\n")
    f.write(f"  geo ratio classical/photonic = "
            f"{e3['ratio_classical_over_photonic']:.3f}x\n\n")

    f.write("(4) Sample efficiency (n_f sweep, heat eq)\n")
    f.write("-" * 70 + "\n")
    f.write(f"  {'n_f':>5s} {'RMSE_q':>11s} {'RMSE_c':>11s} {'c/q':>6s}\n")
    for nf in nfs:
        s = e4[str(nf)]
        f.write(f"  {nf:>5d} {s['rmse_q_mean']:>11.3e} {s['rmse_c_mean']:>11.3e} "
                f"{s['ratio_c_over_q']:>6.2f}\n")
print("Wrote consolidated_summary.txt")
