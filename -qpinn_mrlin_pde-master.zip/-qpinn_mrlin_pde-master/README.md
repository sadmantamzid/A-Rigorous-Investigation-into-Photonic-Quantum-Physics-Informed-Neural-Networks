# QPINN — Quantum Physics-Informed Neural Networks

**Are photonic quantum circuits actually learning anything in PINNs?**
A rigorous multi-experiment investigation using MerLin/Perceval vs parameter-matched classical baselines.

---

## Findings

| Experiment | Setting | Classical RMSE | Photonic RMSE | Ratio |
|------------|---------|---------------|---------------|-------|
| Heat eq. ablation (3 seeds) | Matched params, 5m/2p | 2.471e-04 | 2.473e-04 | **1.00x** |
| Heat eq. — frozen circuit | Same circuit, weights fixed | — | 2.484e-04 | **1.004x vs trained** |
| Scaling — small (5m,2p,d1) | 84 quantum params | 2.537e-04 | 2.556e-04 | 0.99x |
| Scaling — medium (8m,3p,d2) | 396 quantum params | 2.743e-04 | 2.457e-04 | **1.12x** ← quantum wins |
| Scaling — large (10m,5p,d2) | 1282 quantum params | 2.552e-04 | 4.553e-04 | **0.62x** ← barren plateau |
| Schrödinger (wavepacket) | Free particle \|ψ\|² | 3.893e-03 | 4.772e-03 | 0.87x |
| Burgers (viscous shock) | ν=0.01/π | 1.139e-01 | 1.545e-01 | 0.73x |
| Sample efficiency (n_f sweep) | 16–256 colloc. pts | parity | parity | ~1.00x |

**Frozen circuit RMSE = trained circuit RMSE within 0.4%.** The quantum parameters are not contributing to learning; the random fixed kernel already spans the solution's frequency content.

**Larger circuits get *worse***: c/q ratio drops from 1.0 → 0.62 as circuit size grows — the barren-plateau signature predicted by Holmes et al. (2022): Var[∂L/∂θ] ≤ C/dim(H).

---

## Formal Explanation

The frozen=trained result is a prediction of the **data-encoding frequency theorem** (Schuld et al. 2021). With single phase encoding and n_photons=2, the circuit can only express:

```
f(x) = Σ_{|ω| ≤ n_photons} c_ω exp(iωx)    →  |Ω| = 5 accessible frequencies
```

The heat equation solution has dominant frequency ω₀ = π ≈ 3.14, which is inside |Ω|=5 even for a *random* circuit. No training is needed to represent it.

**Three-axis decomposition of error sources:**

| Axis | Problem | Fix | Formal basis |
|------|---------|-----|--------------|
| Preprocessing | Fixed σ=2 kernel mismatched to PDE frequencies | Learnable Fourier features (trainable B) | Bochner's theorem |
| Model | Single upload → |Ω|≤p; BP for large circuits | Data reuploading → |Ω|≤L·p; identity init | Schuld 2021 / Grant 2019 |
| Optimization | Fixed λ_ic=10 doesn't generalise | Online NTK-balanced loss weights | Wang et al. 2020 |

**Condition for genuine quantum advantage** (not yet met):
```
ω_PDE ∈ Ω_quantum \ Ω_classical  AND  Var[∂L/∂θ] >> 1/poly(n_modes)
```
Requires n_modes ≥ 12, circuit depth L ≥ 5, *and* hardware execution (classical simulation of n=12 modes costs O(2^12) = 4096× more than the quantum circuit).

---

## Repository Structure

```
QPINN_Hackathon_Solution_Final.ipynb   ← Main deliverable: all experiments + Phase 3 theory
notebooks/
  qpinn_theory_and_proposed_methods.ipynb   ← Full theory + proposed DataReuploadingQPINN
  merlin_dv_qpinn_paper_baseline.ipynb      ← Paper-faithful DV-photonic reproduction
  merlin_dv_qpinn_ablations.ipynb           ← Ablation studies (aux-deriv, frozen, weights)
  mlp_pinn_heat_equation.ipynb              ← Classical MLP baseline reference
experiments/
  benchmark_qpinn_vs_pinn.py    ← Runs Q1/Q2/Q3 vs C1/C2 on heat equation (paper-faithful)
  exp1_photon_scaling.py        ← Mode/photon scaling: 5m→8m→10m
  exp2_schrodinger.py           ← Free-particle Schrödinger wavepacket
  exp3_burgers.py               ← Burgers equation (viscous shock, ν=0.01/π)
  exp4_sample_efficiency.py     ← n_f sweep 16→256
  ablation_photonic_vs_classical.py  ← Frozen/trained/classical ablation
results/
  consolidated_summary.txt      ← All numbers in one place
  benchmark_results.json        ← Per-seed metrics for all benchmark variants
  exp1_photon_scaling.json      ← Scaling experiment full results
  ablation_photonic_results.json ← Frozen/trained ablation data
docs/
  ARCHITECTURE.md    ← Circuit design, encoding, measurement strategy
  QUICKSTART.md      ← Setup and first run
```

---

## Quick Start

```bash
pip install merlinquantum torch numpy scipy matplotlib
# Run ablation (fastest, ~3 min)
python experiments/ablation_photonic_vs_classical.py
# View consolidated results
cat results/consolidated_summary.txt
# Open main notebook
jupyter notebook QPINN_Hackathon_Solution_Final.ipynb
```

---

## References

- Panichi, Corli, Prati. *Quantum PINNs for multi-variable PDEs*. arXiv:2503.12244v2 (2025)
- Schuld et al. *Effect of data encoding on expressive power*. Phys. Rev. A 103, 032430 (2021)
- Holmes et al. *Connecting ansatz expressibility to gradient magnitudes*. PRX Quantum (2022)
- Cerezo et al. *Cost-function-dependent barren plateaus*. Nat. Commun. (2021)
- Wang et al. *When and why PINNs fail*. SIAM J. Sci. Comput. (2022)
- Grant et al. *Initialization strategy for QNNs*. Quantum 3, 214 (2019)
